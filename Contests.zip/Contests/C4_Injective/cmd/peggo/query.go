package main

import cli "github.com/jawher/mow.cli"

// queryCmdSubset contains actions that query stuff from Peggy module
// and the Ethereum contract
//
// $ peggo q
func queryCmdSubset(cmd *cli.Cmd) {

}
