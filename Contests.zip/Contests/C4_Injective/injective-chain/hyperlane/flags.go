package hyperlane

const (
	FlagEnabledTokens = "hyperlane-enabled-tokens"
)
