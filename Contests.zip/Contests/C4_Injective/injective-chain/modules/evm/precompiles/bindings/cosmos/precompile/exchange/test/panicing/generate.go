package panicing

//go:generate /bin/sh generate.sh
