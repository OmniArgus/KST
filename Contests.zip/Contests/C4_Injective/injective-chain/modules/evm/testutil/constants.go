package testutil

const (
	// TestnetChainID defines the chain ID for testnet
	TestnetChainID = "injective-999"
	// BaseDenom defines the Injective mainnet denomination
	BaseDenom = "inj"
)
