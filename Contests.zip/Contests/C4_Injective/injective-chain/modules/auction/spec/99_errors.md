# Error Codes

This document lists the error codes used in the module.


| Module | Error Code | description |
|--------|------------|-------------|
| auction |  1 | invalid bid denom |
| auction |  2 | invalid bid round |
