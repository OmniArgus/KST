# ERC20

## Abstract

The erc20 module allows for the associations of existing bank denoms with ERC-20 tokens.


## Contents

1. **[Concepts](01_concepts.md)**
2. **[State](02_state.md)**
3. **[Messages](03_messages.md)**
4. **[Events](04_events.md)**
