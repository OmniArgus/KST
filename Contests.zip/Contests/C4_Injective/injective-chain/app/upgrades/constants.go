package upgrades

const (
	MainnetChainID = "injective-1"
	TestnetChainID = "injective-888"
	DevnetChainID  = "injective-777"
)
