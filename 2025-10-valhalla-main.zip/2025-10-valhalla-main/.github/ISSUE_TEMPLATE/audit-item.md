---
name: Audit Item
about: Audit items that end up in the report
title: ""
labels: ""
assignees: ""
---

## Summary

## Vulnerability Detail

## Impact

## Code Snippet

## Tool Used

Manual Review

## Recommendation
