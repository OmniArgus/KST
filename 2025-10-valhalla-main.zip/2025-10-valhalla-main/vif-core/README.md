# Vif protocol

Project name-coded Vif is an ultra efficient, fully onchain order book protocol. It takes inspiration from current order book designs, DeFi protocols features. It combines and innovates to bring the most optimized experience to the users with optimal UX.

## The orderbook structure

The orderbook consits of 2 structures. One is the tick tree which is a 3 level 256 bitmap tree.

### The tick tree

The tick tree helps us locate the price points that are active in the orderbook. To find the first price (in green on the schema):

1. we find the least significant set bit in the root layer of the tree,
2. we go to the layer 1 bitmap with the corresponding index, and find the least significant set bit here,
3. we go to the layer 2 bitmap with the corresponding index, and find the least significant set bit here.

The best price point will be at index `(rootIndex<<16)|(level1Index<<8)|level2Index` or `(rootIndex*256*256)+level1Index*256+level2Index`.

To find the next best price (in blue on the schema):

1. we unset the current level2 index and find the next least significant set bit in the layer 2 bitmap.
2. if there is no next set bit, we find the next least significant set bit in the layer 1 bitmap.
3. if there is no next set bit, we find the next least significant set bit in the root bitmap.
4. we then go back down the tree to the next best price.

![Tick tree](./assets/tree.png)

In storage the tick tree is stored as a fixed size array of length `1+256+256*256`.

### index <=> tick <=> price

The index is an unsigned 24 bit integer that safely allows to have a strictly ascending binary number representation. To get the tick from the index, we just substract by the maximum tick value: `tick = index - MAX_TICK` where `MAX_TICK` is `8_388_607 = type(int24).max`.

**Warning**: The tick value `-8_388_608` is the only non valid tick value in the int24 range.

Tick represents the the log base 1.00001 (0.1 bps) of price where `price = inboundAmount/outboundAmount`. This choice is due to the fact the the higher the price, the higher the tick, the worse the price for the taker (thus higher in the tree).

Mathematically to get the price from the tick, simply compute `price = 1.00001 ** tick`. The price is not adjusted for decimals but is the absolute price.

In the code, the price is represented as a Q128.128 fixed point number. It is computed with binary exponents for `-|tick|`, and then adjusted if the tick is positive.

### The offer lists

Offer lists is a double linked list of offers for a single price point. The main structere stores the head and tail id, as well as additional metadata not used for the matching algorithm (total volume at price, number of offers, and the tick redundantly stored).

![Offer list](./assets/offer-list.png)

## Flash accounting

Vif allows users to batch operations (creating market orders, limit orders, claiming orders, cancelling order, etc.) in a single call. Taking this into account, we decided to delay all token transfers and only mutate trasient storage with debts/credits.

Operations that only mutates this transient storage are:

- market orders
- limit orders
- claiming orders
- cancelling orders
- cleaning expired offers

But then these debts/credits must be settled, so 2 additional operations both mutate the transient sorage and does the token transfers:

- settling debts
- taking credits

The main effect is that multiple operations can be batched without transferring a single token, and intermediary tokens in multi hop transactions are not needed, or more generally, all tokens operations that would be netted by further operations are not needed (eg. creating a new limit order with the claimed funds from a previous order, etc.)

A side effect is allowing for free flash loans.

## Operators

Operators are accounts that are allowed to act on user's behalf. They can call a set this set of functions:

- market orders
- limit orders
- claiming orders
- cancelling orders
- settling debts

⚠️: This means that operators can use all the allowances from the user towards the core contract, as well as the user's funds in the core contract.

The operator can be set/unset via a direct contract call or via an EIP-712 signature.

This is designed mostly for shared routers.

## Token units

To save storage space, amounts are expressed as units. The original idea is to pack an amount into 48 bits (around 281 trillion). To achieve that, we are expressing token amounts in units. Units should be choosen as a power of 10 for ease of readability.

When talking to the main contract, we can pass the absolute amounts as `uint256`. But they will be floored to `amount/units`. Let's take USDC as example:

We'll choose to have USDC expressed with `units=10`. Relative to decimals, this means that the unit is `0.0001 USDC`. if I maker a market order to buy `WETH` with `1.000011` USDC, I will only effectively use `1 USDC` assuming no fees. So when settling debt, you'll not be asked for the fully passed amount.

For reference if we have:

- USDC units = 1e2 or 0.0001, for limit orders we can offer up to `28B USDC` per offer, and market orders can snd up to `1.8e15 USDC`.
- WETH units = 1e10 or 0.00000001, for limit orders we can offer up to `2.8M WETH` per offer, and market orders can snd up to `184T WETH`.

Units on a market are imutable.

## Tick spacing

The tick spacing defines the tick delta between two consecutive indexes in the tree. A higher tick spacing could be used on valatile market to save gas while going thtough the tree, or even disincentivize penny jumping.

Tick spacing on a market is imutable.

## Ownership functions

The core contract can be paused by the owner, preventing all calls to the `lock` function, thus preventing all operations requiring a lock like `settle`, `take`, market orders, limit orders, claiming orders, cancelling orders, etc.

The core contract can also blacklist callers of the `lock` function. This can be done in case of a malicious router created gains operator role on users, or if a router vulnerability is discovered.

The owner is also the only once able to create markets, set fees, set minimum outbound units, set active status, set provisions, and withdraw governance fees.
