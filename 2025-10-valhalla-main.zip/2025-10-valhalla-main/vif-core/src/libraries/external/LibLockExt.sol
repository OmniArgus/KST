// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {LibExtLoader} from "./LibExtLoader.sol";

library LibLockExt {
  using LibExtLoader for address;

  /// @notice The slot of the lock of the target contract.
  uint256 private constant _LOCK_SEED = 0x6d6178656e636572622e6574682069732074686520736f6c6520617574686f72;

  /// @notice Returns whether the target contract is locked.
  /// @param target The target contract to check.
  /// @return result True if the target contract is locked.
  function isLocked(address target) internal view returns (bool) {
    return target.tload(_LOCK_SEED) > 0;
  }
}
