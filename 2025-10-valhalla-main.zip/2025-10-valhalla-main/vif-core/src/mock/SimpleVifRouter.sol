// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {IVif} from "../interfaces/IVif.sol";
import {ILockCallback} from "../interfaces/ILockCallback.sol";
import {LibDeltasExt} from "../libraries/external/LibDeltasExt.sol";
import {SafeTransferLib} from "lib/solady/src/utils/SafeTransferLib.sol";

contract SimpleVifRouter is ILockCallback {
  using LibDeltasExt for address;
  using SafeTransferLib for address;

  error InvalidCaller();
  error InvalidActionType();

  struct Market {
    address outboundToken;
    uint64 outboundUnits;
    address inboundToken;
    uint64 inboundUnits;
    uint16 tickSpacing;
  }

  enum ActionType {
    MarketOrder,
    LimitOrder,
    CancelOrder,
    ClaimOrder
  }

  IVif public immutable VIF;

  constructor(address _vif) {
    VIF = IVif(_vif);
  }

  function _marketId(Market memory market) internal pure returns (bytes32 marketId) {
    /// @solidity memory-safe-assembly
    assembly {
      marketId := keccak256(market, 0xa0)
    }
  }

  function _settleFullDelta(address token, address user) internal {
    int256 delta = address(VIF).deltaOf(token);
    if (delta > 0) {
      VIF.take(token, uint256(delta), user);
      return;
    }

    if (delta < 0) {
      uint256 amount = uint256(-delta);

      if (token == LibDeltasExt.NATIVE) {
        VIF.settle{value: amount}(token, amount, address(this));
        return;
      }
      VIF.settle(token, amount, user);
      return;
    }
  }

  function _marketOrder(bytes memory data, address user) internal returns (bytes memory result) {
    (Market memory market, address taker, int24 maxTick, uint256 fillVolume, bool fillWants, uint256 maxOffers) =
      abi.decode(data, (Market, address, int24, uint256, bool, uint256));

    (uint256 gave, uint256 got, uint256 fees, uint256 bounty) =
      VIF.consume(taker, _marketId(market), maxTick, fillVolume, fillWants, maxOffers);

    _settleFullDelta(market.outboundToken, user);
    _settleFullDelta(market.inboundToken, user);
    _settleFullDelta(LibDeltasExt.NATIVE, user);

    return abi.encode(gave, got, fees, bounty);
  }

  function _limitOrder(bytes memory data, address user) internal returns (bytes memory result) {
    (Market memory market, int24 tick, uint40 offerId, uint256 gives, uint32 expiry, uint24 provision) =
      abi.decode(data, (Market, int24, uint40, uint256, uint32, uint24));
    uint256 claimedReceived;
    (offerId, claimedReceived) = VIF.make(user, _marketId(market), offerId, gives, tick, expiry, provision);

    _settleFullDelta(market.outboundToken, user);
    _settleFullDelta(LibDeltasExt.NATIVE, user);
    _settleFullDelta(market.inboundToken, user);

    return abi.encode(offerId, claimedReceived);
  }

  function _cancelOrder(bytes memory data, address user) internal returns (bytes memory result) {
    (Market memory market, uint40 offerId) = abi.decode(data, (Market, uint40));
    (uint256 inbound, uint256 outbound, uint256 provision) = VIF.cancel(_marketId(market), offerId);
    _settleFullDelta(market.outboundToken, user);
    _settleFullDelta(market.inboundToken, user);
    _settleFullDelta(LibDeltasExt.NATIVE, user);

    return abi.encode(inbound, outbound, provision);
  }

  function _claimOrder(bytes memory data, address user) internal returns (bytes memory result) {
    (Market memory market, uint40 offerId) = abi.decode(data, (Market, uint40));
    (uint256 inbound, uint256 outbound, uint256 provision) = VIF.claim(_marketId(market), offerId);
    _settleFullDelta(market.outboundToken, user);
    _settleFullDelta(market.inboundToken, user);
    _settleFullDelta(LibDeltasExt.NATIVE, user);

    return abi.encode(inbound, outbound, provision);
  }

  function lockCallback(bytes calldata data) external returns (bytes memory result) {
    if (msg.sender != address(VIF)) {
      revert InvalidCaller();
    }
    (ActionType actionType, address user, bytes memory actionData) = abi.decode(data, (ActionType, address, bytes));
    if (actionType == ActionType.MarketOrder) {
      return _marketOrder(actionData, user);
    }
    if (actionType == ActionType.LimitOrder) {
      return _limitOrder(actionData, user);
    }
    if (actionType == ActionType.CancelOrder) {
      return _cancelOrder(actionData, user);
    }
    if (actionType == ActionType.ClaimOrder) {
      return _claimOrder(actionData, user);
    }
    revert InvalidActionType();
  }

  function marketOrder(Market memory market, int24 maxTick, uint256 fillVolume, bool fillWants, uint256 maxOffers)
    external
    payable
    returns (uint256 gave, uint256 got, uint256 fees, uint256 bounty)
  {
    bytes memory data = abi.encode(market, msg.sender, maxTick, fillVolume, fillWants, maxOffers);
    bytes memory action = abi.encode(ActionType.MarketOrder, msg.sender, data);
    bytes memory result = VIF.lock(action);
    (gave, got, fees, bounty) = abi.decode(result, (uint256, uint256, uint256, uint256));
    if (address(this).balance > 0) {
      msg.sender.safeTransferAllETH();
    }
  }

  function limitOrder(
    Market memory market,
    int24 tick,
    uint40 initialOfferId,
    uint256 gives,
    uint32 expiry,
    uint24 provision
  ) external payable returns (uint40 offerId, uint256 claimedReceived) {
    bytes memory data = abi.encode(market, tick, initialOfferId, gives, expiry, provision);
    bytes memory action = abi.encode(ActionType.LimitOrder, msg.sender, data);
    bytes memory result = VIF.lock(action);
    (offerId, claimedReceived) = abi.decode(result, (uint40, uint256));
    if (address(this).balance > 0) {
      msg.sender.safeTransferAllETH();
    }
  }

  function claim(Market memory market, uint40 offerId)
    external
    returns (uint256 inbound, uint256 outbound, uint256 provision)
  {
    bytes memory data = abi.encode(market, offerId);
    bytes memory action = abi.encode(ActionType.ClaimOrder, msg.sender, data);
    bytes memory result = VIF.lock(action);
    (inbound, outbound, provision) = abi.decode(result, (uint256, uint256, uint256));
    if (address(this).balance > 0) {
      msg.sender.safeTransferAllETH();
    }
  }

  function cancel(Market memory market, uint40 offerId)
    external
    returns (uint256 inbound, uint256 outbound, uint256 provision)
  {
    bytes memory data = abi.encode(market, offerId);
    bytes memory action = abi.encode(ActionType.CancelOrder, msg.sender, data);
    bytes memory result = VIF.lock(action);
    (inbound, outbound, provision) = abi.decode(result, (uint256, uint256, uint256));
    if (address(this).balance > 0) {
      msg.sender.safeTransferAllETH();
    }
  }
}
