// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Script} from "forge-std/Script.sol";
import {console} from "forge-std/console.sol";

import {Vif} from "../src/Vif.sol";
import {VifRouter} from "../src/periphery/VifRouter.sol";
import {VifReader} from "../src/periphery/VifReader.sol";

contract DeployImmutable is Script {
  function run() public {
    address weth = vm.envAddress("WETH");
    address owner = vm.envAddress("OWNER");
    uint24 provision = uint24(vm.envUint("PROVISION"));

    vm.startBroadcast();
    Vif vif = new Vif(owner, provision);
    VifRouter router = new VifRouter(address(vif), weth, owner);
    VifReader reader = new VifReader(address(vif));
    vm.stopBroadcast();

    console.log("Vif deployed to", address(vif));
    console.log("Router deployed to", address(router));
    console.log("Reader deployed to", address(reader));
  }
}
