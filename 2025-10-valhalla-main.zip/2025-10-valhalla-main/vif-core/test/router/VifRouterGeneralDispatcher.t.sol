// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Commands} from "../../src/libraries/periphery/Commands.sol";
import {BaseVifRouterTest} from "./BaseVifRouterTest.sol";
import {DispatchResult, SweepArgs} from "../../src/libraries/periphery/Types.sol";
import {MockToken} from "../../src/mock/MockToken.sol";

contract VifRouterGeneralDispatcherTest is BaseVifRouterTest {
  function setUp() public override {
    super.setUp();
  }

  function test_wrapUnwrapSweep() public {
    bytes memory commands =
      abi.encodePacked(Commands.WRAP_NATIVE, Commands.UNWRAP_NATIVE, Commands.SWEEP, Commands.SWEEP);
    bytes[] memory args = new bytes[](4);
    args[0] = abi.encode(2 ether);
    args[1] = abi.encode(1 ether);
    args[2] = abi.encode(SweepArgs({token: address(0), receiver: maker.addr}));
    args[3] = abi.encode(SweepArgs({token: weth, receiver: maker.addr}));

    vm.deal(maker.addr, 2 ether);

    vm.prank(maker.addr);
    DispatchResult[] memory results = router.execute{value: 2 ether}(commands, args);

    assertEq(results[0].success, true);
    assertEq(results[1].success, true);
    assertEq(results[2].success, true);
    assertEq(results[3].success, true);

    assertEq(maker.addr.balance, 1 ether);
    assertEq(MockToken(weth).balanceOf(maker.addr), 1 ether);
  }
}
