// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {VifRouter, Ownable} from "../../src/periphery/VifRouter.sol";
import {Authorization} from "../../src/interfaces/base/IVifAuthorizer.sol";
import {Commands} from "../../src/libraries/periphery/Commands.sol";
import {AuthorizeArgs} from "../../src/libraries/periphery/Types.sol";
import {LibAuthorizationExt} from "../../src/libraries/external/LibAuthorizationExt.sol";
import {LibPausable} from "../../src/libraries/LibPausable.sol";
import {LibBlackList} from "../../src/libraries/LibBlackList.sol";
import {BaseVifRouterTest} from "./BaseVifRouterTest.sol";

contract VifRouterAuthTest is BaseVifRouterTest {
  using LibAuthorizationExt for *;

  function setUp() public override {
    super.setUp();
  }

  function test_authorize() public {
    bool authorized = address(vif).authorized(maker.addr, address(router));
    assertFalse(authorized, "router should not be authorized yet");

    (Authorization memory auth, bytes memory signature) = _validAuthForRouter(maker);

    bytes memory commands = abi.encodePacked(Commands.AUTHORIZE);
    bytes[] memory args = new bytes[](1);
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));

    router.execute(commands, args);

    authorized = address(vif).authorized(maker.addr, address(router));
    assertTrue(authorized, "router should be authorized");
  }

  function test_cannotLockWhenCorePaused() public {
    // pause
    vif.setPaused(true);

    bytes memory commands = abi.encodePacked(Commands.SETTLE_ALL);
    bytes[] memory args = new bytes[](1);
    args[0] = abi.encode(weth);

    vm.expectRevert(LibPausable.Paused.selector);
    vm.prank(maker.addr);
    router.execute(commands, args);

    // unpause
    vif.setPaused(false);

    // should not fail
    vm.prank(maker.addr);
    router.execute(commands, args);
  }

  function testFuzz_cannotSetPausedWhenNotOwner(address caller) public {
    vm.assume(caller != owner.addr);

    vm.startPrank(caller);
    vm.expectRevert(Ownable.Unauthorized.selector);
    router.setPaused(true);
    vm.stopPrank();
  }

  function test_setPaused() public {
    // pause
    vm.expectEmit(true, true, true, true);
    emit LibPausable.SetPaused(true);
    vm.prank(owner.addr);
    router.setPaused(true);

    // should be paused
    assertTrue(router.isPaused());

    bytes memory commands = abi.encodePacked(Commands.SETTLE_ALL);
    bytes[] memory args = new bytes[](1);
    args[0] = abi.encode(weth);

    // should fail when calling execute
    vm.expectRevert(LibPausable.Paused.selector);
    vm.prank(maker.addr);
    router.execute(commands, args);

    // should fail when calling execute with a valid deadline
    vm.expectRevert(LibPausable.Paused.selector);
    vm.prank(maker.addr);
    router.execute(commands, args, block.timestamp + 1);

    // should fail on calling lockCallback
    vm.expectRevert(LibPausable.Paused.selector);
    vm.prank(address(vif));
    router.lockCallback(abi.encode(maker.addr, commands, args));

    // unpause
    vm.expectEmit(true, true, true, true);
    emit LibPausable.SetPaused(false);
    vm.prank(owner.addr);
    router.setPaused(false);

    // should not be paused
    assertFalse(router.isPaused());

    // should not fail
    vm.prank(maker.addr);
    router.execute(commands, args);
  }

  function testFuzz_failOnInvalidCaller(address caller, bytes memory data) public {
    vm.assume(caller != address(vif));

    vm.startPrank(caller);
    vm.expectRevert(VifRouter.InvalidCaller.selector);
    router.lockCallback(data);
    vm.stopPrank();
  }

  function test_cannotLockWhenBlacklisted() public {
    // set blacklisted
    vif.setBlacklisted(address(router), true);

    // should fail when calling execute
    bytes memory commands = abi.encodePacked(Commands.SETTLE_ALL);
    bytes[] memory args = new bytes[](1);
    args[0] = abi.encode(weth);

    // should fail when calling execute
    vm.expectRevert(LibBlackList.Blacklisted.selector);
    vm.prank(maker.addr);
    router.execute(commands, args);

    // should fail when calling execute with a valid deadline
    vm.expectRevert(LibBlackList.Blacklisted.selector);
    vm.prank(maker.addr);
    router.execute(commands, args, block.timestamp + 1);

    // unblacklist
    vif.setBlacklisted(address(router), false);

    // should not fail when calling execute
    vm.prank(maker.addr);
    router.execute(commands, args);

    // should not fail when calling execute with a valid deadline
    vm.prank(maker.addr);
    router.execute(commands, args, block.timestamp + 1);
  }
}
