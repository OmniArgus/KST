// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {MockToken} from "../../src/mock/MockToken.sol";
import {Authorization} from "../../src/interfaces/base/IVifAuthorizer.sol";
import {Commands} from "../../src/libraries/periphery/Commands.sol";
import {LibAuthorizationExt} from "../../src/libraries/external/LibAuthorizationExt.sol";
import {
  DispatchResult,
  AuthorizeArgs,
  LimitArgs,
  SweepArgs,
  ConsumeArgs,
  ConsumeResult,
  ClaimCancelArgs,
  ClaimCancelResult
} from "../../src/libraries/periphery/Types.sol";
import {BaseVifRouterTest} from "./BaseVifRouterTest.sol";
import {LibOfferExt, OfferUnpacked} from "../../src/libraries/external/LibOfferExt.sol";
import {IVifMaking} from "../../src/interfaces/base/IVifMaking.sol";
import {IVifTaking} from "../../src/interfaces/base/IVifTaking.sol";
import {ERC20} from "lib/solady/src/tokens/ERC20.sol";
import {LibAuthorization} from "../../src/libraries/LibAuthorization.sol";

contract VifRouterLimitTest is BaseVifRouterTest {
  using LibAuthorizationExt for *;
  using LibOfferExt for *;

  function setUp() public override {
    super.setUp();
  }

  function test_limitOrder() public {
    (Authorization memory auth, bytes memory signature) = _validAuthForRouter(maker);
    _mint(weth, maker.addr, 100 ether);

    // preparing the transaction
    bytes memory commands =
      abi.encodePacked(Commands.AUTHORIZE, Commands.LIMIT_SINGLE, Commands.LIMIT_SINGLE, Commands.SETTLE_ALL);
    bytes[] memory args = new bytes[](4);
    // populating the arguments
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));
    args[1] = abi.encode(
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_336, expiry: 0, provision: 0})
    );
    args[2] = abi.encode(
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_350, expiry: 0, provision: 0})
    );
    args[3] = abi.encode(weth);

    // giving approval and submit the tx
    vm.startPrank(maker.addr);
    MockToken(weth).approve(address(vif), 2 ether);

    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.NonceIncremented(maker.addr, 1);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.Authorized(maker.addr, address(router), true);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(asksMarketId, 1, maker.addr, 1 ether, -2_072_336, 0, 0);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(asksMarketId, 2, maker.addr, 1 ether, -2_072_350, 0, 0);
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(maker.addr, address(vif), 2 ether);
    DispatchResult[] memory results = router.execute(commands, args);
    vm.stopPrank();

    // Authorization
    assertTrue(results[0].success, "successful authorization");
    assertEq(results[0].returnData, "", "return data should be empty");

    // Limit order 1
    assertTrue(results[1].success, "successful limit order");
    assertEq(results[1].returnData, abi.encode(1, 0), "offer id 1 and received 0");

    // Limit order 2
    assertTrue(results[2].success, "successful limit order");
    assertEq(results[2].returnData, abi.encode(2, 0), "offer id 2 and received 0");

    // Settle all
    assertTrue(results[3].success, "successful settle all");
    assertEq(results[3].returnData, "", "return data should be empty");

    assertEq(MockToken(weth).balanceOf(maker.addr), 98 ether, "maker should have lost 2 WETH");
  }

  function test_limitOrder_native() public {
    (Authorization memory auth, bytes memory signature) = _validAuthForRouter(maker);

    // preparing the transaction
    bytes memory commands = abi.encodePacked(
      Commands.AUTHORIZE, Commands.LIMIT_SINGLE, Commands.LIMIT_SINGLE, Commands.WRAP_NATIVE, Commands.SETTLE_ALL
    );
    bytes[] memory args = new bytes[](5);
    // populating the arguments
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));
    args[1] = abi.encode(
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_336, expiry: 0, provision: 0})
    );
    args[2] = abi.encode(
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_350, expiry: 0, provision: 0})
    );
    args[3] = abi.encode(2 ether);
    args[4] = abi.encode(weth);

    vm.deal(maker.addr, 2 ether);

    // giving approval and submit the tx
    vm.prank(maker.addr);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.NonceIncremented(maker.addr, 1);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.Authorized(maker.addr, address(router), true);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(asksMarketId, 1, maker.addr, 1 ether, -2_072_336, 0, 0);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(asksMarketId, 2, maker.addr, 1 ether, -2_072_350, 0, 0);
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(address(0), address(router), 2 ether);
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(address(router), address(vif), 2 ether);
    DispatchResult[] memory results = router.execute{value: 2 ether}(commands, args);

    // Authorization
    assertTrue(results[0].success, "successful authorization");
    assertEq(results[0].returnData, "", "return data should be empty");

    // Limit order 1
    assertTrue(results[1].success, "successful limit order");
    assertEq(results[1].returnData, abi.encode(1, 0), "offer id 1 and received 0");

    // Limit order 2
    assertTrue(results[2].success, "successful limit order");
    assertEq(results[2].returnData, abi.encode(2, 0), "offer id 2 and received 0");

    // Settle all
    assertTrue(results[3].success, "successful settle all");
    assertEq(results[3].returnData, "", "return data should be empty");

    assertEq(maker.addr.balance, 0, "maker should have no ETH");
  }

  function test_limitOrder_with_provision() public {
    _mint(weth, maker.addr, 100 ether);
    vm.deal(maker.addr, 1 ether);

    (Authorization memory auth, bytes memory signature) = _validAuthForRouter(maker);

    // preparing the transaction
    bytes memory commands = abi.encodePacked(
      Commands.AUTHORIZE,
      Commands.LIMIT_SINGLE,
      Commands.LIMIT_SINGLE,
      Commands.SETTLE_ALL,
      Commands.SETTLE_ALL,
      Commands.SWEEP
    );
    bytes[] memory args = new bytes[](6);
    // populating the arguments
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));
    args[1] = abi.encode(
      LimitArgs({
        marketId: asksMarketId,
        initialOfferId: 0,
        gives: 1 ether,
        tick: -2_072_336,
        expiry: uint32(block.timestamp + 1000),
        provision: 0 // should floor to the global provision
      })
    );
    args[2] = abi.encode(
      LimitArgs({
        marketId: asksMarketId,
        initialOfferId: 0,
        gives: 1 ether,
        tick: -2_072_350,
        expiry: uint32(block.timestamp + 1000),
        provision: PROVISION * 2 // should not be ceiled to the global provision
      })
    );
    args[3] = abi.encode(weth);
    args[4] = abi.encode(address(0));
    args[5] = abi.encode(SweepArgs({token: address(0), receiver: maker.addr}));

    vm.startPrank(maker.addr);
    MockToken(weth).approve(address(vif), 2 ether);

    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.NonceIncremented(maker.addr, 1);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.Authorized(maker.addr, address(router), true);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(
      asksMarketId, 1, maker.addr, 1 ether, -2_072_336, uint32(block.timestamp + 1000), PROVISION
    );
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(
      asksMarketId, 2, maker.addr, 1 ether, -2_072_350, uint32(block.timestamp + 1000), PROVISION * 2
    );
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(maker.addr, address(vif), 2 ether);
    DispatchResult[] memory results = router.execute{value: 1 ether}(commands, args);
    vm.stopPrank();

    (uint40 offerId1, uint256 claimedReceived1) = abi.decode(results[1].returnData, (uint40, uint256));
    (uint40 offerId2, uint256 claimedReceived2) = abi.decode(results[2].returnData, (uint40, uint256));

    assertEq(offerId1, 1, "offer id should be 1");
    assertEq(offerId2, 2, "offer id should be 2");

    assertEq(claimedReceived1, 0, "claimed received should be 0");
    assertEq(claimedReceived2, 0, "claimed received should be 0");

    // balance of maker should be 1 ether - 3 * PROVISION
    assertEq(
      maker.addr.balance, uint256(1 ether) - uint256(3) * PROVISION * 1e9, "maker should have lost 3 * PROVISION WETH"
    );
    // balance of WETH should be 100 ether - 2 ether
    assertEq(MockToken(weth).balanceOf(maker.addr), 98 ether, "maker should have lost 2 WETH");

    OfferUnpacked memory offer1 = address(vif).offer(asksMarketId, offerId1);
    OfferUnpacked memory offer2 = address(vif).offer(asksMarketId, offerId2);

    assertEq(offer1.provision, PROVISION, "provision should be PROVISION");
    assertEq(offer2.provision, PROVISION * 2, "provision should be PROVISION * 2");

    vm.warp(block.timestamp + 1002);
    // offers are expired we should get back the provisions

    commands = abi.encodePacked(Commands.ORDER_SINGLE, Commands.TAKE_ALL);
    args = new bytes[](2);
    args[0] = abi.encode(
      ConsumeArgs({
        marketId: asksMarketId,
        maxTick: type(int24).max,
        fillVolume: 1 ether,
        fillWants: false,
        maxOffers: 10
      })
    );
    args[1] = abi.encode(address(0), maker.addr);

    vm.prank(maker.addr);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifTaking.MarketOrder(asksMarketId, maker.addr, 0, 0, 0, uint256(PROVISION) * 2 * 1e9, 1 ether, false);
    results = router.execute(commands, args);

    ConsumeResult memory result = abi.decode(results[0].returnData, (ConsumeResult));
    assertEq(result.gave, 0, "gave should be 0");
    assertEq(result.got, 0, "should get 0");
    assertEq(result.fee, 0, "should have 0 fee");
    assertEq(result.bounty, uint256(2) * PROVISION * 1e9, "bounty should be 2 * PROVISION since provisions are floored");

    offer1 = address(vif).offer(asksMarketId, offerId1);
    offer2 = address(vif).offer(asksMarketId, offerId2);

    assertEq(offer1.provision, 0, "provision should be 0");
    assertEq(offer2.provision, PROVISION, "provision should be PROVISION");

    // maker balance should be 1 ether - 1 * PROVISION
    assertEq(
      maker.addr.balance, uint256(1 ether) - uint256(1) * PROVISION * 1e9, "maker should have lost 1 * PROVISION WETH"
    );

    // cancel offer, claiming would work as well
    commands = abi.encodePacked(Commands.CANCEL, Commands.CANCEL, Commands.TAKE_ALL, Commands.TAKE_ALL);
    args = new bytes[](4);
    args[0] = abi.encode(ClaimCancelArgs({marketId: asksMarketId, offerId: offerId1}));
    args[1] = abi.encode(ClaimCancelArgs({marketId: asksMarketId, offerId: offerId2}));
    args[2] = abi.encode(weth, maker.addr);
    args[3] = abi.encode(address(0), maker.addr);

    vm.prank(maker.addr);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.OfferCancelled(asksMarketId, offerId1, 1 ether, 0, 0);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.OfferCancelled(asksMarketId, offerId2, 1 ether, 0, uint256(PROVISION) * 1e9);
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(address(vif), maker.addr, 2 ether);
    results = router.execute(commands, args);

    // balance of native and WETH should be back to 1 ether and 100 ether
    assertEq(maker.addr.balance, 1 ether, "maker should have 1 ETH");
    assertEq(MockToken(weth).balanceOf(maker.addr), 100 ether, "maker should have 100 WETH");

    offer1 = address(vif).offer(asksMarketId, offerId1);
    offer2 = address(vif).offer(asksMarketId, offerId2);

    assertEq(offer1.provision, 0, "provision should be 0");
    assertEq(offer2.provision, 0, "provision should be 0");
  }

  function test_claiming_order() public {
    _mint(weth, maker.addr, 1 ether);
    vm.deal(maker.addr, 1 ether);

    (Authorization memory auth, bytes memory signature) = _validAuthForRouter(maker);

    // preparing the transaction
    bytes memory commands =
      abi.encodePacked(Commands.AUTHORIZE, Commands.LIMIT_SINGLE, Commands.SETTLE_ALL, Commands.SETTLE_ALL);
    bytes[] memory args = new bytes[](4);
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));
    args[1] = abi.encode(
      LimitArgs({
        marketId: asksMarketId,
        initialOfferId: 0,
        gives: 1 ether,
        tick: -2_072_336,
        expiry: uint32(block.timestamp + 1000),
        provision: 0 // should floor to the global provision
      })
    );
    args[2] = abi.encode(weth);
    args[3] = abi.encode(address(0));

    vm.startPrank(maker.addr);
    MockToken(weth).approve(address(vif), 1 ether);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.NonceIncremented(maker.addr, 1);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.Authorized(maker.addr, address(router), true);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(
      asksMarketId, 1, maker.addr, 1 ether, -2_072_336, uint32(block.timestamp + 1000), PROVISION
    );
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(maker.addr, address(vif), 1 ether);
    DispatchResult[] memory results = router.execute{value: uint256(PROVISION) * 1e9}(commands, args);
    vm.stopPrank();

    (uint40 offerId, uint256 claimedReceived) = abi.decode(results[1].returnData, (uint40, uint256));
    assertEq(offerId, 1, "offer id should be 1");
    assertEq(claimedReceived, 0, "claimed received should be 0");

    // claiming now should not do anything
    commands = abi.encodePacked(Commands.CLAIM);
    args = new bytes[](1);
    args[0] = abi.encode(ClaimCancelArgs({marketId: asksMarketId, offerId: offerId}));

    vm.prank(maker.addr);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.OfferClaimed(asksMarketId, offerId, 0, 0, 0);
    results = router.execute(commands, args);

    assertEq(results[0].success, true, "successful claim");
    ClaimCancelResult memory result = abi.decode(results[0].returnData, (ClaimCancelResult));
    assertEq(result.inbound, 0, "inbound should be 0");
    assertEq(result.outbound, 0, "outbound should be 0");
    assertEq(result.provision, 0, "provision should be 0");

    // warp to expiry
    vm.warp(block.timestamp + 1001);
    // claiming now should do something
    commands = abi.encodePacked(Commands.CLAIM, Commands.TAKE_ALL, Commands.TAKE_ALL);
    args = new bytes[](3);
    args[0] = abi.encode(ClaimCancelArgs({marketId: asksMarketId, offerId: offerId}));
    args[1] = abi.encode(weth, maker.addr);
    args[2] = abi.encode(address(0), maker.addr);

    vm.prank(maker.addr);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.OfferClaimed(asksMarketId, offerId, 1 ether, 0, uint256(PROVISION) * 1e9);
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(address(vif), maker.addr, 1 ether);
    results = router.execute(commands, args);

    assertEq(results[0].success, true, "successful claim");
    result = abi.decode(results[0].returnData, (ClaimCancelResult));

    assertEq(result.inbound, 0, "inbound should be 0");
    assertEq(result.outbound, 1 ether, "outbound should be 1 ether");
    assertEq(result.provision, uint256(PROVISION) * 1e9, "provision should be PROVISION");
  }

  function test_claimingPartialFilledOrder() public {
    _mint(weth, maker.addr, 1 ether);

    (Authorization memory auth, bytes memory signature) = _validAuthForRouter(maker);

    // preparing the transaction
    bytes memory commands = abi.encodePacked(Commands.AUTHORIZE, Commands.LIMIT_SINGLE, Commands.SETTLE_ALL);
    bytes[] memory args = new bytes[](3);
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));
    args[1] = abi.encode(
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_336, expiry: 0, provision: 0})
    );
    args[2] = abi.encode(weth);

    vm.startPrank(maker.addr);
    MockToken(weth).approve(address(vif), 1 ether);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.NonceIncremented(maker.addr, 1);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.Authorized(maker.addr, address(router), true);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(asksMarketId, 1, maker.addr, 1 ether, -2_072_336, 0, 0);
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(maker.addr, address(vif), 1 ether);
    DispatchResult[] memory results = router.execute(commands, args);
    vm.stopPrank();

    (uint40 offerId, uint256 claimedReceived) = abi.decode(results[1].returnData, (uint40, uint256));
    assertEq(offerId, 1, "offer id should be 1");
    assertEq(claimedReceived, 0, "claimed received should be 0");

    _mint(usdc, taker.addr, 500e6);
    (auth, signature) = _validAuthForRouter(taker);

    commands = abi.encodePacked(Commands.AUTHORIZE, Commands.ORDER_SINGLE, Commands.SETTLE_ALL, Commands.TAKE_ALL);
    args = new bytes[](4);
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));
    args[1] = abi.encode(
      ConsumeArgs({marketId: asksMarketId, maxTick: type(int24).max, fillVolume: 500e6, fillWants: false, maxOffers: 10})
    );
    args[2] = abi.encode(usdc);
    args[3] = abi.encode(weth, taker.addr);

    vm.startPrank(taker.addr);
    MockToken(usdc).approve(address(vif), 500e6);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.NonceIncremented(taker.addr, 1);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.Authorized(taker.addr, address(router), true);
    vm.expectEmit(true, true, true, false, address(vif));
    emit IVifTaking.MarketOrder(asksMarketId, taker.addr, 0, 0, 0, 0, 500e6, false); // data incorrect
    vm.expectEmit(true, true, true, true, address(usdc));
    emit ERC20.Transfer(taker.addr, address(vif), 500e6);
    vm.expectEmit(true, true, true, false, address(weth));
    emit ERC20.Transfer(address(vif), taker.addr, 0); // data incorrect
    results = router.execute(commands, args);
    vm.stopPrank();

    ConsumeResult memory consumeResult = abi.decode(results[1].returnData, (ConsumeResult));
    assertEq(consumeResult.gave, 500e6, "gave should be 500e6");
    assertGt(consumeResult.got, 0, "got should be greater than 0");
    assertEq(consumeResult.bounty, 0, "bounty should be 0");

    OfferUnpacked memory offer = address(vif).offer(asksMarketId, offerId);
    assertEq(offer.gives, (1 ether - consumeResult.got) / WETH_UNITS, "gives should be 1 ether - consumeResult.got");
    assertEq(offer.received, 500e6 / USDC_UNITS, "received should be 500e6");
    assertEq(offer.isActive, true, "offer should be active");

    // claiming now should only claim the received amount and not cancel the offer
    commands = abi.encodePacked(Commands.CLAIM, Commands.TAKE_ALL);
    args = new bytes[](2);
    args[0] = abi.encode(ClaimCancelArgs({marketId: asksMarketId, offerId: offerId}));
    args[1] = abi.encode(usdc, maker.addr);

    vm.prank(maker.addr);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.OfferClaimed(asksMarketId, offerId, 0, 500e6, 0);
    vm.expectEmit(true, true, true, true, address(usdc));
    emit ERC20.Transfer(address(vif), maker.addr, 500e6);
    results = router.execute(commands, args);

    assertEq(results[0].success, true, "successful claim");
    ClaimCancelResult memory claimResult = abi.decode(results[0].returnData, (ClaimCancelResult));
    assertEq(claimResult.inbound, 500e6, "inbound should be 500e6");
    assertEq(claimResult.outbound, 0, "outbound should be 0");
    assertEq(claimResult.provision, 0, "provision should be 0");

    offer = address(vif).offer(asksMarketId, offerId);
    assertEq(offer.gives, (1 ether - consumeResult.got) / WETH_UNITS, "gives should be 1 ether - consumeResult.got");
    assertEq(offer.received, 0, "received should be 0");
    assertEq(offer.isActive, true, "offer should be active");

    // set market to inactive
    vif.setActive(asksMarketId, false);

    // claiming should now cancel the offer anc claim the remaining amount
    commands = abi.encodePacked(Commands.CLAIM, Commands.TAKE_ALL);
    args = new bytes[](2);
    args[0] = abi.encode(ClaimCancelArgs({marketId: asksMarketId, offerId: offerId}));
    args[1] = abi.encode(weth, maker.addr);

    vm.prank(maker.addr);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.OfferClaimed(asksMarketId, offerId, 1 ether - consumeResult.got, 0, 0);
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(address(vif), maker.addr, 1 ether - consumeResult.got);
    results = router.execute(commands, args);

    assertEq(results[0].success, true, "successful claim");
    claimResult = abi.decode(results[0].returnData, (ClaimCancelResult));
    assertEq(claimResult.inbound, 0, "inbound should be 0");
    assertEq(claimResult.outbound, 1 ether - consumeResult.got, "outbound should be 1 ether - consumeResult.got");
    assertEq(claimResult.provision, 0, "provision should be 0");

    offer = address(vif).offer(asksMarketId, offerId);
    assertEq(offer.gives, 0, "gives should be 0");
    assertEq(offer.received, 0, "received should be 0");
    assertEq(offer.isActive, false, "offer should be inactive");
  }

  function test_cancellingPartialFilledOrder() public {
    _mint(weth, maker.addr, 1 ether);
    vm.deal(maker.addr, uint256(PROVISION) * 1e9);

    (Authorization memory auth, bytes memory signature) = _validAuthForRouter(maker);

    // preparing the transaction
    bytes memory commands =
      abi.encodePacked(Commands.AUTHORIZE, Commands.LIMIT_SINGLE, Commands.SETTLE_ALL, Commands.SETTLE_ALL);
    bytes[] memory args = new bytes[](4);
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));
    args[1] = abi.encode(
      LimitArgs({
        marketId: asksMarketId,
        initialOfferId: 0,
        gives: 1 ether,
        tick: -2_072_336,
        expiry: uint32(block.timestamp + 1000),
        provision: 0
      })
    );
    args[2] = abi.encode(weth);
    args[3] = abi.encode(address(0));

    vm.startPrank(maker.addr);
    MockToken(weth).approve(address(vif), 1 ether);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.NonceIncremented(maker.addr, 1);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.Authorized(maker.addr, address(router), true);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.NewOffer(
      asksMarketId, 1, maker.addr, 1 ether, -2_072_336, uint32(block.timestamp + 1000), PROVISION
    );
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(maker.addr, address(vif), 1 ether);
    DispatchResult[] memory results = router.execute{value: uint256(PROVISION) * 1e9}(commands, args);
    vm.stopPrank();

    (uint40 offerId, uint256 claimedReceived) = abi.decode(results[1].returnData, (uint40, uint256));
    assertEq(claimedReceived, 0, "claimed received should be 0");
    assertEq(offerId, 1, "offer id should be 1");

    _mint(usdc, taker.addr, 500e6);
    (auth, signature) = _validAuthForRouter(taker);

    commands = abi.encodePacked(Commands.AUTHORIZE, Commands.ORDER_SINGLE, Commands.SETTLE_ALL, Commands.TAKE_ALL);
    args = new bytes[](4);
    args[0] = abi.encode(AuthorizeArgs({authorization: auth, signature: signature}));
    args[1] = abi.encode(
      ConsumeArgs({marketId: asksMarketId, maxTick: type(int24).max, fillVolume: 500e6, fillWants: false, maxOffers: 10})
    );
    args[2] = abi.encode(usdc);
    args[3] = abi.encode(weth, taker.addr);

    vm.startPrank(taker.addr);
    MockToken(usdc).approve(address(vif), 500e6);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.NonceIncremented(taker.addr, 1);
    vm.expectEmit(true, true, true, true, address(vif));
    emit LibAuthorization.Authorized(taker.addr, address(router), true);
    vm.expectEmit(true, true, true, false, address(vif));
    emit IVifTaking.MarketOrder(asksMarketId, taker.addr, 0, 0, 0, 0, 500e6, false); // data incorrect
    vm.expectEmit(true, true, true, true, address(usdc));
    emit ERC20.Transfer(taker.addr, address(vif), 500e6);
    vm.expectEmit(true, true, true, false, address(weth));
    emit ERC20.Transfer(address(vif), taker.addr, 0); // data incorrect
    results = router.execute(commands, args);
    vm.stopPrank();

    ConsumeResult memory consumeResult = abi.decode(results[1].returnData, (ConsumeResult));
    assertEq(consumeResult.gave, 500e6, "gave should be 500e6");
    assertGt(consumeResult.got, 0, "got should be greater than 0");
    assertEq(consumeResult.bounty, 0, "bounty should be 0");

    OfferUnpacked memory offer = address(vif).offer(asksMarketId, offerId);
    assertEq(offer.gives, (1 ether - consumeResult.got) / WETH_UNITS, "gives should be 1 ether - consumeResult.got");
    assertEq(offer.received, 500e6 / USDC_UNITS, "received should be 500e6");
    assertEq(offer.isActive, true, "offer should be active");

    commands = abi.encodePacked(Commands.CANCEL, Commands.TAKE_ALL, Commands.TAKE_ALL, Commands.TAKE_ALL);
    args = new bytes[](4);
    args[0] = abi.encode(ClaimCancelArgs({marketId: asksMarketId, offerId: offerId}));
    args[1] = abi.encode(weth, maker.addr);
    args[2] = abi.encode(usdc, maker.addr);
    args[3] = abi.encode(address(0), maker.addr);

    vm.prank(maker.addr);
    vm.expectEmit(true, true, true, true, address(vif));
    emit IVifMaking.OfferCancelled(
      asksMarketId, offerId, 1 ether - consumeResult.got, consumeResult.gave, uint256(PROVISION) * 1e9
    );
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(address(vif), maker.addr, 1 ether - consumeResult.got);
    vm.expectEmit(true, true, true, true, address(usdc));
    emit ERC20.Transfer(address(vif), maker.addr, consumeResult.gave);
    results = router.execute(commands, args);

    ClaimCancelResult memory claimResult = abi.decode(results[0].returnData, (ClaimCancelResult));
    assertEq(claimResult.inbound, consumeResult.gave, "inbound should be consumeResult.gave");
    assertEq(claimResult.outbound, 1 ether - consumeResult.got, "outbound should be 1 ether - consumeResult.got");
    assertEq(claimResult.provision, uint256(PROVISION) * 1e9, "provision should be PROVISION");

    offer = address(vif).offer(asksMarketId, offerId);
    assertEq(offer.gives, 0, "gives should be 0");
    assertEq(offer.received, 0, "received should be 0");
    assertEq(offer.isActive, false, "offer should be inactive");
  }
}
