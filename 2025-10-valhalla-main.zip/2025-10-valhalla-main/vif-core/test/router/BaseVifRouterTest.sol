// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test, Vm} from "forge-std/Test.sol";
import {VifRouter} from "../../src/periphery/VifRouter.sol";
import {Vif} from "../../src/Vif.sol";
import {WETH} from "lib/solady/src/tokens/WETH.sol";
import {MockToken} from "../../src/mock/MockToken.sol";
import {Authorization} from "../../src/interfaces/base/IVifAuthorizer.sol";
import {LibAuthorizationExt} from "../../src/libraries/external/LibAuthorizationExt.sol";

contract BaseVifRouterTest is Test {
  using LibAuthorizationExt for *;

  Vif public vif;
  VifRouter public router;

  address public weth;
  address public usdc;

  uint64 internal constant WETH_UNITS = 1e13;
  uint64 internal constant USDC_UNITS = 1e4;

  uint24 internal constant MIN_WETH_UNITS = 1000;
  uint24 internal constant MIN_USDC_UNITS = 1000;

  uint24 internal constant PROVISION = 100;

  uint16 internal constant TICK_SPACING = 1;

  Vm.Wallet public maker;
  Vm.Wallet public taker;
  Vm.Wallet public owner;

  /// @dev keccak256("Authorization(address authorizer,address authorized,bool isAuthorized,uint256 nonce,uint256 deadline)")
  uint256 private constant _AUTHORIZATION_TYPEHASH = 0x81d0284fb0e2cde18d0553b06189d6f7613c96a01bb5b5e7828eade6a0dcac91;

  /// @dev `keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)")`.
  bytes32 internal constant _DOMAIN_TYPEHASH = 0x8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f;

  bytes32 asksMarketId;
  bytes32 bidsMarketId;

  function setUp() public virtual {
    maker = vm.createWallet("maker");
    taker = vm.createWallet("taker");
    owner = vm.createWallet("owner");

    vif = new Vif(address(this), PROVISION);
    weth = address(new WETH());
    usdc = address(new MockToken("USD Coin", "USDC", 6));
    router = new VifRouter(address(vif), address(weth), owner.addr);

    asksMarketId = vif.openMarket(weth, usdc, WETH_UNITS, USDC_UNITS, TICK_SPACING, 0, MIN_WETH_UNITS);
    bidsMarketId = vif.openMarket(usdc, weth, USDC_UNITS, WETH_UNITS, TICK_SPACING, 0, MIN_USDC_UNITS);

    vm.label(address(weth), "WETH");
    vm.label(address(usdc), "USDC");
    vm.label(address(vif), "VIF");
    vm.label(address(router), "ROUTER");
  }

  function _mint(address token, address user, uint256 amount) public {
    if (token == address(weth)) {
      vm.deal(user, user.balance + amount);
      vm.prank(user);
      WETH(payable(weth)).deposit{value: amount}();
    } else {
      MockToken(token).mint(user, amount);
    }
  }

  function _signAuth(Vm.Wallet memory wallet, bool isAuthorized, uint256 nonce, uint256 deadline)
    internal
    view
    returns (Authorization memory auth, bytes memory signature)
  {
    auth = Authorization({
      authorizer: wallet.addr,
      authorized: address(router),
      isAuthorized: isAuthorized,
      nonce: nonce,
      deadline: deadline
    });

    bytes32 domainSeparator;

    {
      (, string memory name, string memory version, uint256 chainId, address verifyingContract,,) = vif.eip712Domain();

      domainSeparator = keccak256(
        abi.encode(_DOMAIN_TYPEHASH, keccak256(bytes(name)), keccak256(bytes(version)), chainId, verifyingContract)
      );
    }

    bytes32 structHash = keccak256(abi.encode(_AUTHORIZATION_TYPEHASH, auth));

    bytes32 digest = keccak256(abi.encodePacked("\x19\x01", domainSeparator, structHash));

    (uint8 v, bytes32 r, bytes32 s) = vm.sign(wallet.privateKey, digest);
    signature = abi.encodePacked(r, s, v);
  }

  function _validAuthForRouter(Vm.Wallet memory wallet)
    internal
    view
    returns (Authorization memory auth, bytes memory signature)
  {
    uint256 nonce = LibAuthorizationExt.authorizerNonce(address(vif), wallet.addr);
    (auth, signature) = _signAuth(wallet, true, nonce, type(uint256).max);
  }
}
