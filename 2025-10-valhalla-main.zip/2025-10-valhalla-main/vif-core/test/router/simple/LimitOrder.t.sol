// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Vm} from "forge-std/Vm.sol";
import {BaseVifRouterSimpleTest} from "./BaseVifRouterSimpleTest.sol";
import {LimitArgs, ClaimCancelArgs, ConsumeArgs, ConsumeResult} from "../../../src/libraries/periphery/Types.sol";
import {LibOffer, OfferUnpacked} from "../../../src/libraries/LibOffer.sol";
import {Commands} from "../../../src/libraries/periphery/Commands.sol";
import {Ownable} from "lib/solady/src/auth/Ownable.sol";
import {LibAuthorization} from "../../../src/libraries/LibAuthorization.sol";
import {IVifTaking} from "../../../src/interfaces/base/IVifTaking.sol";

contract LimitOrderTest is BaseVifRouterSimpleTest {
  using LibOffer for *;

  error InvalidExpiry();

  function setUp() public override {
    super.setUp();
  }

  function test_limitOrderEdit() public {
    (uint40 offerId,) = _limitOrder(
      maker.addr,
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_336, expiry: 0, provision: 0})
    );

    (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners) =
      _book(asksMarketId);

    OfferUnpacked memory offer;

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 1);
    assertEq(offerIds[0], offerId);
    assertEq(owners[0], maker.addr);

    offer.from(offers[0]);
    assertEq(offer.tick, -2_072_336);
    assertEq(offer.gives, 1 ether / WETH_UNITS);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);

    // edit order
    (uint40 newOfferId, uint256 claimedReceived) = _limitOrder(
      maker.addr,
      LimitArgs({
        marketId: asksMarketId,
        initialOfferId: offerId,
        gives: 2 ether,
        tick: -2_072_300,
        expiry: 0,
        provision: 0
      })
    );

    assertEq(newOfferId, offerId);
    assertEq(claimedReceived, 0);

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 1);
    assertEq(offerIds[0], offerId);
    assertEq(owners[0], maker.addr);

    offer.from(offers[0]);
    assertEq(offer.tick, -2_072_300);
    assertEq(offer.gives, 2 ether / WETH_UNITS);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);
  }

  function test_cleaningLimitOrder() public {
    (uint40 offerId, uint256 claimedReceived) = _limitOrder(
      maker.addr,
      LimitArgs({
        marketId: asksMarketId,
        initialOfferId: 0,
        gives: 1 ether,
        tick: -2_072_336,
        expiry: uint32(block.timestamp + 1 days),
        provision: 0
      })
    );
    assertEq(claimedReceived, 0);

    vm.record();
    (uint256 bounty, bool success) = _cleanOrder(maker.addr, asksMarketId, offerId);
    Vm.Log[] memory logs = vm.getRecordedLogs();

    assertEq(logs.length, 0);
    assertEq(bounty, 0);
    assertEq(success, false);

    vm.warp(block.timestamp + 2 days);

    vm.expectEmit(true, true, true, true);
    emit IVifTaking.OfferCleaned(asksMarketId, offerId, uint256(PROVISION) * 1e9);
    (bounty, success) = _cleanOrder(maker.addr, asksMarketId, offerId);

    assertEq(bounty, uint256(PROVISION) * 1e9);
    assertEq(success, true);
  }

  function test_cannotEditOthersOrders() public {
    (uint40 offerId, uint256 claimedReceived) = _limitOrder(
      maker.addr,
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_336, expiry: 0, provision: 0})
    );
    assertEq(claimedReceived, 0);

    bytes memory commands = abi.encodePacked(Commands.CANCEL);
    bytes[] memory args = new bytes[](1);
    args[0] = abi.encode(ClaimCancelArgs({marketId: asksMarketId, offerId: offerId}));

    vm.startPrank(taker.addr);
    vif.authorize(address(router), true);
    vm.expectRevert(Ownable.Unauthorized.selector);
    router.execute(commands, args);
    vm.stopPrank();

    commands = abi.encodePacked(Commands.CLAIM);

    vm.startPrank(taker.addr);
    vm.expectRevert(Ownable.Unauthorized.selector);
    router.execute(commands, args);
    vm.stopPrank();

    commands = abi.encodePacked(Commands.LIMIT_SINGLE);
    args = new bytes[](1);
    args[0] = abi.encode(
      LimitArgs({
        marketId: asksMarketId,
        initialOfferId: offerId,
        gives: 1 ether,
        tick: -2_072_335,
        expiry: 0,
        provision: 0
      })
    );

    vm.startPrank(taker.addr);
    vm.expectRevert(LibAuthorization.NotAuthorized.selector);
    router.execute(commands, args);
    vm.stopPrank();
  }

  function test_cannotCreateExpiredOrder() public {
    vm.warp(100);
    _limitOrder(
      maker.addr,
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_336, expiry: 99, provision: 0}),
      abi.encodeWithSelector(InvalidExpiry.selector)
    );
  }

  function test_editPartialFillOrderShouldClaimReceived() public {
    (uint40 offerId,) = _limitOrder(
      maker.addr,
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_336, expiry: 0, provision: 0})
    );

    ConsumeResult memory result = _marketOrder(
      taker.addr,
      1000e6,
      ConsumeArgs({marketId: asksMarketId, maxTick: 0, fillVolume: 0.5 ether, fillWants: true, maxOffers: 10})
    );
    assertGt(result.gave, 0);
    assertEq(result.got, 0.5 ether);
    assertEq(result.bounty, 0);

    // edit the order should claim the received amount
    (uint40 newOfferId, uint256 claimedReceived) = _limitOrder(
      maker.addr,
      LimitArgs({
        marketId: asksMarketId,
        initialOfferId: offerId,
        gives: 2 ether,
        tick: -2_072_300,
        expiry: 0,
        provision: 0
      })
    );

    assertEq(newOfferId, offerId);
    assertEq(claimedReceived, result.gave);
  }
}
