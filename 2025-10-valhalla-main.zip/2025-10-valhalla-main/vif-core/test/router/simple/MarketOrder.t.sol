// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {BaseVifRouterSimpleTest} from "./BaseVifRouterSimpleTest.sol";
import {LimitArgs, ConsumeArgs, ConsumeResult, ConsumeMultiArgs} from "../../../src/libraries/periphery/Types.sol";
import {OfferUnpacked, LibOffer} from "../../../src/libraries/LibOffer.sol";
import {LibOfferExt} from "../../../src/libraries/external/LibOfferExt.sol";
import {MockToken} from "../../../src/mock/MockToken.sol";
import {LibFeesExt} from "../../../src/libraries/external/LibFeesExt.sol";

contract MarketOrderTest is BaseVifRouterSimpleTest {
  using LibOffer for *;
  using LibOfferExt for address;
  using LibFeesExt for address;

  uint64 internal constant WBTC_UNITS = 1;
  uint24 internal constant MIN_WBTC_UNITS = 1000;

  bytes32 asksMarketIdWbtc;
  bytes32 bidsMarketIdWbtc;

  MockToken public wbtc;

  error SlippageTooHigh();

  function setUp() public override {
    super.setUp();
    wbtc = new MockToken("Wrapped Bitcoin", "WBTC", 8);
    vm.label(address(wbtc), "WBTC");

    asksMarketIdWbtc =
      vif.openMarket(address(wbtc), address(usdc), WBTC_UNITS, USDC_UNITS, TICK_SPACING, 0, MIN_WBTC_UNITS);
    bidsMarketIdWbtc =
      vif.openMarket(address(usdc), address(wbtc), USDC_UNITS, WBTC_UNITS, TICK_SPACING, 0, MIN_USDC_UNITS);
  }

  function test_singleOrderExactInWithFee() public {
    vif.setFees(asksMarketId, 100); // 0.01% fee

    LimitArgs memory limitArgs =
      LimitArgs({marketId: asksMarketId, gives: 1 ether, tick: -2_000_400, expiry: 0, provision: 0, initialOfferId: 0});
    (uint40 bestOfferId,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = -2_000_200;
    limitArgs.expiry = uint32(block.timestamp + 1);
    (uint40 expiringOfferId,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = -2_000_000;
    limitArgs.expiry = 0;
    (uint40 worstOfferId,) = _limitOrder(maker.addr, limitArgs);

    (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners) =
      _book(asksMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferId);
    assertEq(offerIds[1], expiringOfferId);
    assertEq(offerIds[2], worstOfferId);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    // make the offer expire
    vm.warp(block.timestamp + 2);

    ConsumeResult memory result = _marketOrder(
      maker.addr,
      1.5 ether,
      ConsumeArgs({
        marketId: asksMarketId,
        maxTick: type(int24).max,
        fillVolume: 3000e6,
        fillWants: false,
        maxOffers: 100
      })
    );

    assertEq(result.gave + result.fee, 3000e6);
    assertEq(result.bounty, uint256(PROVISION) * 1e9);
    assertGt(result.got, 0);
    assertEq(result.fee, 3000e6 * 100 / 1e6);

    // check that the fees are owed to the owner on the correct amount
    assertEq(address(vif).fees(address(usdc)), 3000e6 * 100 / 1e6, "fees should be correct");

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 1);
    assertEq(offerIds[0], worstOfferId);
    assertEq(owners[0], maker.addr);

    OfferUnpacked memory offer;
    offer.from(offers[0]);

    assertEq(offer.tick, -2_000_000);
    assertGt(offer.gives, 0);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);
    assertGt(offer.received, 0);

    offer = address(vif).offer(asksMarketId, bestOfferId);
    assertEq(offer.gives, 0);
    assertGt(offer.received, 0);

    offer = address(vif).offer(asksMarketId, expiringOfferId);
    assertEq(offer.gives, 1 ether / WETH_UNITS);
    assertEq(offer.received, 0);
    assertEq(offer.provision, 0);

    offer = address(vif).offer(asksMarketId, worstOfferId);
    assertGt(offer.gives, 0);
    assertGt(offer.received, 0);
  }

  function test_singleOrderExactOutWithFee() public {
    vif.setFees(asksMarketId, 100); // 0.01% fee

    LimitArgs memory limitArgs =
      LimitArgs({marketId: asksMarketId, gives: 1 ether, tick: -2_000_400, expiry: 0, provision: 0, initialOfferId: 0});
    (uint40 bestOfferId,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = -2_000_200;
    limitArgs.expiry = uint32(block.timestamp + 1);
    (uint40 expiringOfferId,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = -2_000_000;
    limitArgs.expiry = 0;
    (uint40 worstOfferId,) = _limitOrder(maker.addr, limitArgs);

    (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners) =
      _book(asksMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferId);
    assertEq(offerIds[1], expiringOfferId);
    assertEq(offerIds[2], worstOfferId);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    // make the offer expire
    vm.warp(block.timestamp + 2);

    ConsumeResult memory result = _marketOrder(
      maker.addr,
      4000e6,
      ConsumeArgs({
        marketId: asksMarketId,
        maxTick: type(int24).max,
        fillVolume: 1.5 ether,
        fillWants: true,
        maxOffers: 100
      })
    );

    assertEq(result.got, 1.5 ether);
    assertGt(result.gave, 0);
    assertGt(result.fee, 0);
    assertEq(result.bounty, uint256(PROVISION) * 1e9);

    // check that the fees are owed to the owner on the correct amount
    assertGt(address(vif).fees(address(usdc)), 0, "fees should be correct");

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 1);
    assertEq(offerIds[0], worstOfferId);
    assertEq(owners[0], maker.addr);

    OfferUnpacked memory offer;
    offer.from(offers[0]);

    assertEq(offer.tick, -2_000_000);
    assertGt(offer.gives, 0);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);
    assertGt(offer.received, 0);

    offer = address(vif).offer(asksMarketId, bestOfferId);
    assertEq(offer.gives, 0);
    assertGt(offer.received, 0);

    offer = address(vif).offer(asksMarketId, expiringOfferId);
    assertEq(offer.gives, 1 ether / WETH_UNITS);
    assertEq(offer.received, 0);
    assertEq(offer.provision, 0);

    offer = address(vif).offer(asksMarketId, worstOfferId);
    assertGt(offer.gives, 0);
    assertGt(offer.received, 0);
  }

  function test_multiOrderExactInWithFee() public {
    // WETH => USDC => WBTC
    vif.setFees(bidsMarketId, 100); // 0.01% fee
    vif.setFees(asksMarketIdWbtc, 100); // 0.01% fee

    // creating offers on the market WETH => USDC

    LimitArgs memory limitArgs =
      LimitArgs({marketId: bidsMarketId, gives: 2000e6, tick: 2_000_000, expiry: 0, provision: 0, initialOfferId: 0});
    (uint40 bestOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.expiry = uint32(block.timestamp + 1);
    limitArgs.tick = 2_000_200;
    (uint40 expiringOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 2_000_400;
    limitArgs.expiry = 0;
    (uint40 worstOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    // creating offers on the market USDC => WBTC
    limitArgs.marketId = asksMarketIdWbtc;
    limitArgs.gives = 0.02e8;
    limitArgs.tick = 700_000;

    (uint40 bestOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 700_200;
    limitArgs.expiry = uint32(block.timestamp + 1);
    (uint40 expiringOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 700_400;
    limitArgs.expiry = 0;
    (uint40 worstOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners) =
      _book(bidsMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferIdMarket1);
    assertEq(offerIds[1], expiringOfferIdMarket1);
    assertEq(offerIds[2], worstOfferIdMarket1);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketIdWbtc);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferIdMarket2);
    assertEq(offerIds[1], expiringOfferIdMarket2);
    assertEq(offerIds[2], worstOfferIdMarket2);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    // make the offers expire
    vm.warp(block.timestamp + 2);

    ConsumeMultiArgs memory consumeArgs;
    consumeArgs.marketIds = new bytes32[](2);
    consumeArgs.marketIds[0] = bidsMarketId;
    consumeArgs.marketIds[1] = asksMarketIdWbtc;
    consumeArgs.fillVolume = 1.5 ether;
    consumeArgs.fillWants = false;
    consumeArgs.maxOffers = 100;

    uint256 output = _consumeMulti(taker.addr, 1.5 ether, consumeArgs);

    // check that the fees are owed to the owner on the correct amount
    assertEq(address(vif).fees(address(weth)), 1.5 ether * 100 / 1e6, "fees on weth should be 0.01% of 1.5 ether");
    assertGt(address(vif).fees(address(usdc)), 0, "fees on USDC should be more than 0");
    assertEq(address(vif).fees(address(wbtc)), 0, "fees on WBTC should be 0");

    assertEq(output, MockToken(address(wbtc)).balanceOf(taker.addr));
    assertGt(output, 0);
  }

  function test_multiOrderExactOutWithFee() public {
    // WETH => USDC => WBTC
    vif.setFees(bidsMarketId, 100); // 0.01% fee
    vif.setFees(asksMarketIdWbtc, 100); // 0.01% fee

    // creating offers on the market WETH => USDC

    LimitArgs memory limitArgs =
      LimitArgs({marketId: bidsMarketId, gives: 2000e6, tick: 2_000_000, expiry: 0, provision: 0, initialOfferId: 0});
    (uint40 bestOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.expiry = uint32(block.timestamp + 1);
    limitArgs.tick = 2_000_200;
    (uint40 expiringOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 2_000_400;
    limitArgs.expiry = 0;
    (uint40 worstOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    // creating offers on the market USDC => WBTC
    limitArgs.marketId = asksMarketIdWbtc;
    limitArgs.gives = 0.02e8;
    limitArgs.tick = 700_000;

    (uint40 bestOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 700_200;
    limitArgs.expiry = uint32(block.timestamp + 1);
    (uint40 expiringOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 700_400;
    limitArgs.expiry = 0;
    (uint40 worstOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners) =
      _book(bidsMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferIdMarket1);
    assertEq(offerIds[1], expiringOfferIdMarket1);
    assertEq(offerIds[2], worstOfferIdMarket1);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketIdWbtc);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferIdMarket2);
    assertEq(offerIds[1], expiringOfferIdMarket2);
    assertEq(offerIds[2], worstOfferIdMarket2);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    // make the offers expire
    vm.warp(block.timestamp + 2);

    ConsumeMultiArgs memory consumeArgs;
    consumeArgs.marketIds = new bytes32[](2);
    consumeArgs.marketIds[0] = bidsMarketId;
    consumeArgs.marketIds[1] = asksMarketIdWbtc;
    consumeArgs.fillVolume = 0.03e8;
    consumeArgs.fillWants = true;
    consumeArgs.maxOffers = 100;
    // no slippage protection
    consumeArgs.limitVolume = type(uint256).max;

    uint256 input = _consumeMulti(taker.addr, 2 ether, consumeArgs);

    // check that the fees are owed to the owner on the correct amount
    assertGt(address(vif).fees(address(weth)), 0, "fees on weth should be more than 0");
    assertGt(address(vif).fees(address(usdc)), 0, "fees on USDC should be more than 0");
    assertEq(address(vif).fees(address(wbtc)), 0, "fees on WBTC should be 0");

    assertGt(input, 0);
  }

  function test_multiOrderExactInWithFeeAndSlippageProtection() public {
    // WETH => USDC => WBTC
    vif.setFees(bidsMarketId, 100); // 0.01% fee
    vif.setFees(asksMarketIdWbtc, 100); // 0.01% fee

    // creating offers on the market WETH => USDC

    LimitArgs memory limitArgs =
      LimitArgs({marketId: bidsMarketId, gives: 2000e6, tick: 2_000_000, expiry: 0, provision: 0, initialOfferId: 0});
    (uint40 bestOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.expiry = uint32(block.timestamp + 1);
    limitArgs.tick = 2_000_200;
    (uint40 expiringOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 2_000_400;
    limitArgs.expiry = 0;
    (uint40 worstOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    // creating offers on the market USDC => WBTC
    limitArgs.marketId = asksMarketIdWbtc;
    limitArgs.gives = 0.02e8;
    limitArgs.tick = 700_000;

    (uint40 bestOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 700_200;
    limitArgs.expiry = uint32(block.timestamp + 1);
    (uint40 expiringOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 700_400;
    limitArgs.expiry = 0;
    (uint40 worstOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners) =
      _book(bidsMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferIdMarket1);
    assertEq(offerIds[1], expiringOfferIdMarket1);
    assertEq(offerIds[2], worstOfferIdMarket1);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketIdWbtc);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferIdMarket2);
    assertEq(offerIds[1], expiringOfferIdMarket2);
    assertEq(offerIds[2], worstOfferIdMarket2);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    // make the offers expire
    vm.warp(block.timestamp + 2);

    ConsumeMultiArgs memory consumeArgs;
    consumeArgs.marketIds = new bytes32[](2);
    consumeArgs.marketIds[0] = bidsMarketId;
    consumeArgs.marketIds[1] = asksMarketIdWbtc;
    consumeArgs.fillVolume = 1.5 ether;
    consumeArgs.fillWants = false;
    consumeArgs.maxOffers = 100;
    // ask for a min of 0.03 BTC (we will only get a bit more than 0.02)
    consumeArgs.limitVolume = 0.03e8;

    // expect a failure due to slippage
    uint256 output = _consumeMulti(taker.addr, 1.5 ether, consumeArgs, abi.encodeWithSelector(SlippageTooHigh.selector));

    assertEq(output, 0);
  }

  function test_multiOrderExactOutWithFeeAndSlippageProtection() public {
    // WETH => USDC => WBTC
    vif.setFees(bidsMarketId, 100); // 0.01% fee
    vif.setFees(asksMarketIdWbtc, 100); // 0.01% fee

    // creating offers on the market WETH => USDC

    LimitArgs memory limitArgs =
      LimitArgs({marketId: bidsMarketId, gives: 2000e6, tick: 2_000_000, expiry: 0, provision: 0, initialOfferId: 0});
    (uint40 bestOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.expiry = uint32(block.timestamp + 1);
    limitArgs.tick = 2_000_200;
    (uint40 expiringOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 2_000_400;
    limitArgs.expiry = 0;
    (uint40 worstOfferIdMarket1,) = _limitOrder(maker.addr, limitArgs);

    // creating offers on the market USDC => WBTC
    limitArgs.marketId = asksMarketIdWbtc;
    limitArgs.gives = 0.02e8;
    limitArgs.tick = 700_000;

    (uint40 bestOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 700_200;
    limitArgs.expiry = uint32(block.timestamp + 1);
    (uint40 expiringOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    limitArgs.tick = 700_400;
    limitArgs.expiry = 0;
    (uint40 worstOfferIdMarket2,) = _limitOrder(maker.addr, limitArgs);

    (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners) =
      _book(bidsMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferIdMarket1);
    assertEq(offerIds[1], expiringOfferIdMarket1);
    assertEq(offerIds[2], worstOfferIdMarket1);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketIdWbtc);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], bestOfferIdMarket2);
    assertEq(offerIds[1], expiringOfferIdMarket2);
    assertEq(offerIds[2], worstOfferIdMarket2);
    assertEq(owners[0], maker.addr);
    assertEq(owners[1], maker.addr);
    assertEq(owners[2], maker.addr);

    // make the offers expire
    vm.warp(block.timestamp + 2);

    ConsumeMultiArgs memory consumeArgs;
    consumeArgs.marketIds = new bytes32[](2);
    consumeArgs.marketIds[0] = bidsMarketId;
    consumeArgs.marketIds[1] = asksMarketIdWbtc;
    consumeArgs.fillVolume = 0.03e8;
    consumeArgs.fillWants = true;
    consumeArgs.maxOffers = 100;
    // send a max of 1.5 ether (we will need to send more than that)
    consumeArgs.limitVolume = 1.5 ether;

    // expect a failure due to slippage
    uint256 input = _consumeMulti(taker.addr, 2 ether, consumeArgs, abi.encodeWithSelector(SlippageTooHigh.selector));

    assertEq(input, 0);
  }
}
