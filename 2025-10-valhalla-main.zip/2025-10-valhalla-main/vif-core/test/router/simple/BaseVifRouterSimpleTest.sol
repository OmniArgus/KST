// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {BaseVifRouterTest} from "../BaseVifRouterTest.sol";
import {LibMarketExt, Market} from "../../../src/libraries/external/LibMarketExt.sol";
import {
  ConsumeArgs,
  ConsumeResult,
  DispatchResult,
  LimitArgs,
  ClaimCancelArgs,
  ClaimCancelResult,
  ConsumeMultiArgs
} from "../../../src/libraries/periphery/Types.sol";
import {Commands} from "../../../src/libraries/periphery/Commands.sol";
import {ILockCallback} from "../../../src/interfaces/ILockCallback.sol";
import {IVif} from "../../../src/interfaces/IVif.sol";
import {LibDeltas} from "../../../src/libraries/LibDeltas.sol";
import {MockToken} from "../../../src/mock/MockToken.sol";
import {VifReader} from "../../../src/periphery/VifReader.sol";
import {LibOfferExt, OfferUnpacked} from "../../../src/libraries/external/LibOfferExt.sol";
import {DynamicArrayLib} from "lib/solady/src/utils/DynamicArrayLib.sol";

contract SimpleCleaner is ILockCallback {
  IVif public immutable VIF;

  constructor(address _vif) {
    VIF = IVif(_vif);
  }

  function clean(bytes32 marketId, uint40 offerId, address recipient) external returns (uint256 bounty, bool success) {
    (bounty, success) = abi.decode(VIF.lock(abi.encode(marketId, offerId, recipient)), (uint256, bool));
  }

  function lockCallback(bytes calldata data) external returns (bytes memory result) {
    (bytes32 marketId, uint40 offerId, address recipient) = abi.decode(data, (bytes32, uint40, address));
    (uint256 bounty, bool success) = VIF.clean(marketId, offerId);
    if (success) {
      VIF.take(LibDeltas.NATIVE, bounty, recipient);
    }
    return abi.encode(bounty, success);
  }
}

contract BaseVifRouterSimpleTest is BaseVifRouterTest {
  using LibMarketExt for *;
  using LibOfferExt for *;
  using DynamicArrayLib for *;

  SimpleCleaner public simpleCleaner;
  VifReader public reader;

  function setUp() public virtual override {
    super.setUp();
    simpleCleaner = new SimpleCleaner(address(vif));
    reader = new VifReader(address(vif));
    reader.updateMarkets(address(weth), address(usdc), WETH_UNITS, USDC_UNITS, TICK_SPACING);
  }

  function _marketOrder(address taker, uint256 sendMint, ConsumeArgs memory consumeArgs)
    internal
    returns (ConsumeResult memory result)
  {
    Market memory market = address(vif).market(consumeArgs.marketId);
    assertTrue(market.active, "market is not active");

    _mint(market.inboundToken, taker, sendMint);

    bytes memory commands =
      abi.encodePacked(Commands.ORDER_SINGLE, Commands.SETTLE_ALL, Commands.TAKE_ALL, Commands.TAKE_ALL);
    bytes[] memory args = new bytes[](4);
    args[0] = abi.encode(consumeArgs);
    args[1] = abi.encode(market.inboundToken);
    args[2] = abi.encode(market.outboundToken, taker);
    args[3] = abi.encode(address(0), taker);

    vm.startPrank(taker);
    MockToken(market.inboundToken).approve(address(vif), sendMint);
    vif.authorize(address(router), true);
    DispatchResult[] memory results = router.execute(commands, args);
    vm.stopPrank();

    result = abi.decode(results[0].returnData, (ConsumeResult));
  }

  function _consumeMulti(address taker, uint256 sendMint, ConsumeMultiArgs memory consumeMultiArgs)
    internal
    returns (uint256 output)
  {
    return _consumeMulti(taker, sendMint, consumeMultiArgs, "");
  }

  function _consumeMulti(
    address taker,
    uint256 sendMint,
    ConsumeMultiArgs memory consumeMultiArgs,
    bytes memory revertData
  ) internal returns (uint256 output) {
    assertGt(consumeMultiArgs.marketIds.length, 0, "market ids length must be greater than 0");
    DynamicArrayLib.DynamicArray memory tokens;
    for (uint256 i = 0; i < consumeMultiArgs.marketIds.length; i++) {
      Market memory _market = address(vif).market(consumeMultiArgs.marketIds[i]);
      tokens.p(_market.outboundToken);
      assertTrue(_market.active, "market is not active");
    }
    address inputToken = address(vif).market(consumeMultiArgs.marketIds[0]).inboundToken;

    address[] memory tokensArray = tokens.data.asAddressArray();

    bytes[] memory args = new bytes[](3 + tokensArray.length);
    bytes memory commands = abi.encodePacked(Commands.ORDER_MULTI, Commands.SETTLE_ALL, Commands.TAKE_ALL);
    args[0] = abi.encode(consumeMultiArgs);
    args[1] = abi.encode(inputToken);
    args[2] = abi.encode(address(0), taker);

    for (uint256 i = 0; i < tokensArray.length; i++) {
      commands = abi.encodePacked(commands, Commands.TAKE_ALL);
      args[3 + i] = abi.encode(tokensArray[i], taker);
    }

    _mint(inputToken, taker, sendMint);

    vm.startPrank(taker);
    MockToken(inputToken).approve(address(vif), sendMint);
    vif.authorize(address(router), true);
    if (revertData.length > 0) {
      vm.expectRevert(revertData);
    }
    DispatchResult[] memory results = router.execute(commands, args);
    vm.stopPrank();

    if (revertData.length == 0) {
      output = abi.decode(results[0].returnData, (uint256));
    }
  }

  function _limitOrder(address maker, LimitArgs memory limitArgs)
    internal
    returns (uint40 offerId, uint256 claimedReceived)
  {
    return _limitOrder(maker, limitArgs, "");
  }

  function _limitOrder(address maker, LimitArgs memory limitArgs, bytes memory revertData)
    internal
    returns (uint40 offerId, uint256 claimedReceived)
  {
    Market memory market = address(vif).market(limitArgs.marketId);
    assertTrue(market.active, "market is not active");

    uint256 minProvision = uint256(PROVISION) * 1e9;
    uint256 provision = limitArgs.expiry > 0
      ? limitArgs.provision < minProvision ? minProvision : limitArgs.provision
      : limitArgs.provision;

    uint256 toMint = limitArgs.gives;
    uint256 provisionToMint = provision;

    if (limitArgs.initialOfferId > 0) {
      OfferUnpacked memory offer = address(vif).offer(limitArgs.marketId, limitArgs.initialOfferId);
      toMint = offer.gives > limitArgs.gives ? 0 : limitArgs.gives - offer.gives;
      provisionToMint = offer.provision > provision ? 0 : provision - offer.provision;
    }

    if (toMint > 0) {
      _mint(market.outboundToken, maker, toMint);
    }

    if (maker.balance < provisionToMint) {
      vm.deal(maker, provisionToMint);
    }

    bytes memory commands = abi.encodePacked(
      Commands.LIMIT_SINGLE,
      Commands.SETTLE_ALL,
      Commands.SETTLE_ALL,
      Commands.TAKE_ALL,
      Commands.TAKE_ALL,
      Commands.TAKE_ALL
    );
    bytes[] memory args = new bytes[](6);
    args[0] = abi.encode(limitArgs);
    args[1] = abi.encode(market.outboundToken);
    args[2] = abi.encode(address(0));
    args[3] = abi.encode(market.outboundToken, maker); // in case we withdraw more
    args[4] = abi.encode(address(0), maker); // in case we withdraw more
    args[5] = abi.encode(market.inboundToken, maker); // in case there is an amount received to claim

    vm.startPrank(maker);
    MockToken(market.outboundToken).approve(address(vif), toMint);
    vif.authorize(address(router), true);
    if (revertData.length > 0) {
      vm.expectRevert(revertData);
    }
    DispatchResult[] memory results = router.execute{value: provisionToMint}(commands, args);
    vm.stopPrank();

    if (revertData.length == 0) {
      (offerId, claimedReceived) = abi.decode(results[0].returnData, (uint40, uint256));
    }
  }

  function _claimOrder(address maker, ClaimCancelArgs memory claimCancelArgs)
    internal
    returns (ClaimCancelResult memory result)
  {
    Market memory market = address(vif).market(claimCancelArgs.marketId);

    bytes memory commands = abi.encodePacked(Commands.CLAIM, Commands.TAKE_ALL, Commands.TAKE_ALL, Commands.TAKE_ALL);
    bytes[] memory args = new bytes[](3);
    args[0] = abi.encode(claimCancelArgs);
    args[1] = abi.encode(market.outboundToken, maker);
    args[2] = abi.encode(market.inboundToken, maker);
    args[3] = abi.encode(address(0), maker);

    vm.startPrank(maker);
    vif.authorize(address(router), true);
    DispatchResult[] memory results = router.execute(commands, args);
    vm.stopPrank();

    result = abi.decode(results[0].returnData, (ClaimCancelResult));
  }

  function _cancelOrder(address maker, ClaimCancelArgs memory claimCancelArgs)
    internal
    returns (ClaimCancelResult memory result)
  {
    Market memory market = address(vif).market(claimCancelArgs.marketId);

    bytes memory commands = abi.encodePacked(Commands.CANCEL, Commands.TAKE_ALL, Commands.TAKE_ALL, Commands.TAKE_ALL);
    bytes[] memory args = new bytes[](4);
    args[0] = abi.encode(claimCancelArgs);
    args[1] = abi.encode(market.outboundToken, maker);
    args[2] = abi.encode(market.inboundToken, maker);
    args[3] = abi.encode(address(0), maker);

    vm.startPrank(maker);
    vif.authorize(address(router), true);
    DispatchResult[] memory results = router.execute(commands, args);
    vm.stopPrank();

    result = abi.decode(results[0].returnData, (ClaimCancelResult));
  }

  function _cleanOrder(address recipient, bytes32 marketId, uint40 offerId)
    internal
    returns (uint256 bounty, bool success)
  {
    (bounty, success) = simpleCleaner.clean(marketId, offerId, recipient);
  }

  function _book(bytes32 marketId, uint256 maxOffers)
    internal
    view
    returns (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners)
  {
    return reader.packedOfferList(marketId, 0, maxOffers);
  }

  function _book(bytes32 marketId)
    internal
    view
    returns (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners)
  {
    return reader.packedOfferList(marketId, 0, 100);
  }
}
