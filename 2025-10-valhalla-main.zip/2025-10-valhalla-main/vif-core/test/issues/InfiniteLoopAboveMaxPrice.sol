// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {BaseVifRouterSimpleTest} from "../router/simple/BaseVifRouterSimpleTest.sol";
import {LimitArgs, ConsumeArgs, ConsumeResult} from "../../src/libraries/periphery/Types.sol";

contract InfiniteLoopAboveMaxPrice is BaseVifRouterSimpleTest {
  function test_infiniteLoopAboveMaxtick() public {
    _limitOrder(
      maker.addr,
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: -2_072_336, expiry: 0, provision: 0})
    );

    // this should not consume any offers, and not revert
    ConsumeResult memory result = _marketOrder(
      taker.addr,
      1 ether,
      ConsumeArgs({marketId: asksMarketId, maxTick: -2_072_337, fillVolume: 1 ether, fillWants: false, maxOffers: 100})
    );

    assertEq(result.gave, 0);
    assertEq(result.got, 0);
    assertEq(result.fee, 0);
    assertEq(result.bounty, 0);
  }
}
