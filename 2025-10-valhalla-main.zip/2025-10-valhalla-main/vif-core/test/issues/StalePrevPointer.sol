// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {BaseVifRouterSimpleTest} from "../router/simple/BaseVifRouterSimpleTest.sol";
import {LimitArgs, ConsumeResult, ConsumeArgs, ClaimCancelArgs} from "../../src/libraries/periphery/Types.sol";
import {OfferUnpacked, LibOffer} from "../../src/libraries/external/LibOfferExt.sol";

contract StalePrevPointerTest is BaseVifRouterSimpleTest {
  using LibOffer for *;

  function test_stalePrevPointer() public {
    address makerA = makeAddr("makerA");
    address makerB = makeAddr("makerB");
    address makerC = makeAddr("makerC");

    int24 tick = -2_072_336;

    (uint40 offerIdA,) = _limitOrder(
      makerA,
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: tick, expiry: 0, provision: 0})
    );
    (uint40 offerIdB,) = _limitOrder(
      makerB,
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: tick, expiry: 0, provision: 0})
    );
    (uint40 offerIdC,) = _limitOrder(
      makerC,
      LimitArgs({marketId: asksMarketId, initialOfferId: 0, gives: 1 ether, tick: tick, expiry: 0, provision: 0})
    );

    (uint40 nextOfferId, uint40[] memory offerIds, uint256[] memory offers, address[] memory owners) =
      _book(asksMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 3);
    assertEq(offerIds[0], offerIdA);
    assertEq(offerIds[1], offerIdB);
    assertEq(offerIds[2], offerIdC);

    OfferUnpacked memory offer;

    offer.from(offers[0]);
    assertEq(offer.prev, 0);
    assertEq(offer.next, offerIdB);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.gives, 1 ether / WETH_UNITS);
    assertEq(offer.received, 0);

    offer.from(offers[1]);
    assertEq(offer.prev, offerIdA);
    assertEq(offer.next, offerIdC);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.gives, 1 ether / WETH_UNITS);
    assertEq(offer.received, 0);

    offer.from(offers[2]);
    assertEq(offer.prev, offerIdB);
    assertEq(offer.next, 0);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.gives, 1 ether / WETH_UNITS);
    assertEq(offer.received, 0);

    // consume the fully offer A
    _marketOrder(
      taker.addr,
      5000e6,
      ConsumeArgs({
        marketId: asksMarketId,
        maxTick: type(int24).max,
        fillVolume: 1 ether,
        fillWants: true,
        maxOffers: 100
      })
    );

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 2);
    assertEq(offerIds[0], offerIdB);
    assertEq(offerIds[1], offerIdC);

    offer.from(offers[0]);
    assertEq(offer.prev, 0, "prev should be 0"); // error here
    assertEq(offer.next, offerIdC);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.gives, 1 ether / WETH_UNITS);
    assertEq(offer.received, 0);

    offer.from(offers[1]);
    assertEq(offer.prev, offerIdB);
    assertEq(offer.next, 0);
    assertEq(offer.isActive, true);
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.gives, 1 ether / WETH_UNITS);
    assertEq(offer.received, 0);

    // cancel order B
    _cancelOrder(makerB, ClaimCancelArgs({marketId: asksMarketId, offerId: offerIdB}));

    (nextOfferId, offerIds, offers, owners) = _book(asksMarketId);

    assertEq(nextOfferId, 0);
    assertEq(offerIds.length, 1);
    assertEq(offerIds[0], offerIdC, "remaining offer should be C"); // error here

    offer.from(offers[0]);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);
    assertEq(offer.isActive, true, "offer in offer list should be active"); // error here
    assertEq(offer.expiry, 0);
    assertEq(offer.provision, 0);
    assertEq(offer.gives, 1 ether / WETH_UNITS, "offer in offer list should have gives"); // error here
    assertEq(offer.received, 0);

    ConsumeResult memory result = _marketOrder(
      taker.addr,
      5000e6,
      ConsumeArgs({
        marketId: asksMarketId,
        maxTick: type(int24).max,
        fillVolume: 0.5 ether,
        fillWants: true,
        maxOffers: 100
      })
    );

    assertEq(result.got, 0.5 ether); // error here
  }
}
