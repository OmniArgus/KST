// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {SimpleVifRouter} from "../../src/mock/SimpleVifRouter.sol";
import {MockToken} from "../../src/mock/MockToken.sol";
import {Vif} from "../../src/Vif.sol";
import {LibTreeExt} from "../../src/libraries/external/LibTreeExt.sol";
import {LibTick} from "../../src/libraries/LibTick.sol";
import {OfferUnpacked, LibOfferExt} from "../../src/libraries/external/LibOfferExt.sol";

contract SimpleVifRouterTest is Test {
  using LibTreeExt for *;
  using LibTick for *;
  using LibOfferExt for *;

  Vif public vif;
  SimpleVifRouter public router;

  address public maker = makeAddr("maker");
  address public taker = makeAddr("taker");

  MockToken public weth;
  MockToken public usdc;

  uint64 internal constant WETH_UNITS = 1e13;
  uint64 internal constant USDC_UNITS = 1e4;

  uint24 internal constant PROVISION = 100;

  uint24 internal constant MIN_WETH_UNITS = 1000;
  uint24 internal constant MIN_USDC_UNITS = 1000;

  uint16 internal constant TICK_SPACING = 1;

  SimpleVifRouter.Market public asks;
  SimpleVifRouter.Market public bids;

  bytes32 asksMarketId;
  bytes32 bidsMarketId;

  function setUp() public {
    vif = new Vif(address(this), PROVISION);
    router = new SimpleVifRouter(address(vif));

    weth = new MockToken("Wrapped Ether", "WETH", 18);
    usdc = new MockToken("USD Coin", "USDC", 6);

    vm.label(address(weth), "WETH");
    vm.label(address(usdc), "USDC");

    asksMarketId = vif.openMarket(address(weth), address(usdc), WETH_UNITS, USDC_UNITS, TICK_SPACING, 0, MIN_WETH_UNITS);
    bidsMarketId = vif.openMarket(address(usdc), address(weth), USDC_UNITS, WETH_UNITS, TICK_SPACING, 0, MIN_USDC_UNITS);

    asks = SimpleVifRouter.Market({
      outboundToken: address(weth),
      inboundToken: address(usdc),
      outboundUnits: WETH_UNITS,
      inboundUnits: USDC_UNITS,
      tickSpacing: TICK_SPACING
    });

    bids = SimpleVifRouter.Market({
      outboundToken: address(usdc),
      inboundToken: address(weth),
      outboundUnits: USDC_UNITS,
      inboundUnits: WETH_UNITS,
      tickSpacing: TICK_SPACING
    });
  }

  function _authorizeRouterFor(address user) internal {
    vm.prank(user);
    vif.authorize(address(router), true);
  }

  function test_limitOrder() public {
    _authorizeRouterFor(maker);

    weth.mint(maker, 100 ether);

    vm.startPrank(maker);
    weth.approve(address(vif), type(uint256).max);
    vm.cool(address(vif));
    vm.cool(address(weth));
    router.limitOrder(
      asks,
      -2_072_336, // price of 1000 USDC per WETH
      0,
      1 ether,
      0,
      0
    );
    vm.cool(address(vif));
    vm.cool(address(weth));
    router.limitOrder(asks, -2_070_000, 0, 1 ether, 0, 0);
    vm.cool(address(vif));
    vm.cool(address(weth));
    router.limitOrder(
      asks,
      -2_005_000, // price of 1000 USDC per WETH
      0,
      1 ether,
      0,
      0
    );
    vm.stopPrank();

    LibTreeExt.Tree memory asksTree = address(vif).treeFor(asksMarketId);
    LibTreeExt.Cursor memory cursor;
    bool found;
    (cursor, found) = asksTree.first();
    assertEq(cursor.index().tick(1), -2_072_336);
    assertEq(found, true);

    found = cursor.next(asksTree);
    assertEq(cursor.index().tick(1), -2_070_000);
    assertEq(found, true);

    found = cursor.next(asksTree);
    assertEq(cursor.index().tick(1), -2_005_000);
    assertEq(found, true);

    found = cursor.next(asksTree);
    assertEq(found, false);
  }

  function test_marketOrder() public {
    _authorizeRouterFor(maker);
    _authorizeRouterFor(taker);

    weth.mint(maker, 100 ether);

    vm.startPrank(maker);
    weth.approve(address(vif), type(uint256).max);
    (uint40 offerId1, uint256 claimedReceived1) = router.limitOrder(
      asks,
      -2_072_336, // price of 1000 USDC per WETH
      0,
      1 ether,
      0,
      0
    );
    (uint40 offerId2, uint256 claimedReceived2) = router.limitOrder(
      asks,
      -2_000_000, // price of 2000 USDC per WETH
      0,
      1 ether,
      0,
      0
    );
    vm.stopPrank();

    assertEq(claimedReceived1, 0);
    assertEq(claimedReceived2, 0);

    usdc.mint(taker, 10_000e6);

    vm.startPrank(taker);
    usdc.approve(address(vif), type(uint256).max);
    vm.cool(address(vif));
    vm.cool(address(usdc));
    (uint256 gave, uint256 got,,) = router.marketOrder(asks, 0, 1.5 ether, true, 100);
    vm.stopPrank();

    assertEq(got, 1.5 ether);
    assertGt(gave, 0); // should give around 2_000 USDC

    // offer Id should not be active and have all gives consumed
    OfferUnpacked memory offer = address(vif).offer(asksMarketId, offerId1);

    assertEq(offer.isActive, false);
    assertEq(offer.gives, 0);
    assertGt(offer.received, 0);

    offer = address(vif).offer(asksMarketId, offerId2);

    assertEq(offer.isActive, true);
    assertEq(offer.gives * WETH_UNITS, 0.5 ether); // 1 ether - 0.5 ether (already taken)
    assertGt(offer.received, 0);
  }

  function test_insertAtCorrectIndex() public {
    _authorizeRouterFor(maker);

    asks.tickSpacing = 10;
    uint16 tickSpacing2 = 10;
    bytes32 market2 =
      vif.openMarket(address(weth), address(usdc), WETH_UNITS, USDC_UNITS, tickSpacing2, 0, MIN_WETH_UNITS);

    weth.mint(maker, 100 ether);

    vm.startPrank(maker);
    weth.approve(address(vif), type(uint256).max);
    (uint40 offerId1, uint256 claimedReceived1) = router.limitOrder(
      asks,
      -2_072_336, // price of 1000 USDC per WETH
      0,
      1 ether,
      0,
      0
    );
    vm.stopPrank();
    assertEq(claimedReceived1, 0);

    OfferUnpacked memory offer = address(vif).offer(market2, offerId1);
    assertEq(offer.tick, -2_072_330);
    assertEq(offer.isActive, true);
    assertEq(offer.gives * WETH_UNITS, 1 ether);
    assertEq(offer.received, 0);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);
  }
}
