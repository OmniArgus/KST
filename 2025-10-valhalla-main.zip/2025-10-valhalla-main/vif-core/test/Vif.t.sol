// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {Vif} from "../src/Vif.sol";
import {Ownable} from "lib/solady/src/auth/Ownable.sol";
import {LibClone} from "lib/solady/src/utils/LibClone.sol";
import {LibProvision} from "../src/libraries/LibProvision.sol";

contract VifTest is Test {
  using LibClone for address;

  function test_cannotInitializeTwice() public {
    Vif vif = new Vif(address(this), 100);
    vm.expectRevert(Ownable.AlreadyInitialized.selector);
    vif.initialize(address(this), 100);
  }

  function test_proxyCanCallInitialize() public {
    Vif vif = new Vif(address(this), 100);

    Vif proxy = Vif(address(vif).clone());

    // should not revert
    proxy.initialize(address(this), 100);

    // should now revert
    vm.expectRevert(Ownable.AlreadyInitialized.selector);
    proxy.initialize(address(this), 100);
  }

  function testFuzz_setProvisionsTooLarge(uint24 provisions) public {
    provisions = uint24(bound(provisions, 0x7fffff + 1, type(uint24).max));

    vm.expectRevert(LibProvision.ProvisionTooLarge.selector);
    new Vif(address(this), provisions);
  }

  function testFuzz_setProvisionsTooLargeProxy(uint24 provisions) public {
    provisions = uint24(bound(provisions, 0x7fffff + 1, type(uint24).max));

    Vif vif = new Vif(address(this), 1);

    Vif proxy = Vif(address(vif).clone());

    vm.expectRevert(LibProvision.ProvisionTooLarge.selector);
    proxy.initialize(address(this), provisions);
  }
}
