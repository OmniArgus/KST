// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {VifReader} from "../../src/periphery/VifReader.sol";
import {Vif} from "../../src/Vif.sol";
import {SimpleVifRouter} from "../../src/mock/SimpleVifRouter.sol";
import {MockToken} from "../../src/mock/MockToken.sol";
import {LibOffer} from "../../src/libraries/LibOffer.sol";
import {LibSort} from "lib/solady/src/utils/LibSort.sol";
import {LibOfferExt} from "../../src/libraries/external/LibOfferExt.sol";
import {LibOfferListExt} from "../../src/libraries/external/LibOfferListExt.sol";
import {LibOfferList, OfferListUnpacked} from "../../src/libraries/LibOfferList.sol";
import {LibOffer, OfferUnpacked} from "../../src/libraries/LibOffer.sol";
import {LibTick} from "../../src/libraries/LibTick.sol";
import {LibString} from "lib/solady/src/utils/LibString.sol";
import {Market, LibMarket} from "../../src/libraries/LibMarket.sol";

contract VifReaderTest is Test {
  using LibOfferExt for address;
  using LibOfferListExt for address;
  using LibMarket for Market;
  using LibOfferList for *;
  using LibTick for *;
  using LibString for *;
  using LibOffer for *;

  VifReader public reader;
  Vif public vif;
  SimpleVifRouter public router;

  MockToken public weth;
  MockToken public usdc;

  bytes32 public asksMarketId;
  bytes32 public bidsMarketId;

  uint64 internal constant WETH_UNITS = 1e10;
  uint64 internal constant USDC_UNITS = 1e2;

  uint24 internal constant PROVISION = 1e3;

  uint24 internal constant MIN_WETH_UNITS = 1000;
  uint24 internal constant MIN_USDC_UNITS = 1000;

  uint16 internal constant TICK_SPACING = 1;

  address public maker = makeAddr("maker");
  address public taker = makeAddr("taker");

  SimpleVifRouter.Market public asks;
  SimpleVifRouter.Market public bids;

  function setUp() public {
    vif = new Vif(address(this), PROVISION);
    reader = new VifReader(address(vif));
    router = new SimpleVifRouter(address(vif));

    weth = new MockToken("Wrapped Ether", "WETH", 18);
    usdc = new MockToken("USD Coin", "USDC", 6);

    vm.label(address(weth), "WETH");
    vm.label(address(usdc), "USDC");
    vm.label(address(vif), "VIF");
    vm.label(address(reader), "READER");
    vm.label(address(router), "ROUTER");

    asksMarketId = vif.openMarket(address(weth), address(usdc), WETH_UNITS, USDC_UNITS, TICK_SPACING, 0, MIN_WETH_UNITS);
    bidsMarketId = vif.openMarket(address(usdc), address(weth), USDC_UNITS, WETH_UNITS, TICK_SPACING, 0, MIN_USDC_UNITS);

    asks = SimpleVifRouter.Market({
      outboundToken: address(weth),
      inboundToken: address(usdc),
      outboundUnits: WETH_UNITS,
      inboundUnits: USDC_UNITS,
      tickSpacing: TICK_SPACING
    });

    bids = SimpleVifRouter.Market({
      outboundToken: address(usdc),
      inboundToken: address(weth),
      outboundUnits: USDC_UNITS,
      inboundUnits: WETH_UNITS,
      tickSpacing: TICK_SPACING
    });
  }

  function _authorizeRouterFor(address user) internal {
    vm.prank(user);
    vif.authorize(address(router), true);
  }

  function _limitOrder(SimpleVifRouter.Market memory market, address user, int24 tick, uint256 gives)
    internal
    returns (uint40 offerId)
  {
    _authorizeRouterFor(user);

    MockToken(market.outboundToken).mint(user, gives);

    vm.startPrank(user);
    MockToken(market.outboundToken).approve(address(vif), gives);
    (offerId,) = router.limitOrder(market, tick, 0, gives, 0, 0);
    vm.stopPrank();
  }

  function test_packedOfferList() public {
    uint40[] memory offerIds = new uint40[](5);

    offerIds[0] = _limitOrder(asks, maker, -8_000_000, 1 ether);
    offerIds[1] = _limitOrder(asks, maker, -2_070_000, 1 ether);
    offerIds[2] = _limitOrder(asks, maker, -2_070_000, 1 ether);
    offerIds[3] = _limitOrder(asks, maker, -2_005_000, 1 ether);
    offerIds[4] = _limitOrder(asks, maker, -1_000_000, 1 ether);

    (uint40 nextOfferId, uint40[] memory packedOfferIds, uint256[] memory offers, address[] memory owners) =
      reader.packedOfferList(asksMarketId, 0, 100);

    assertEq(nextOfferId, 0, "no offers left");

    assertEq(packedOfferIds.length, offerIds.length, "offerIds length");

    for (uint256 i = 0; i < offerIds.length; i++) {
      assertEq(packedOfferIds[i], offerIds[i], "offerIds[i]");
      assertEq(owners[i], maker, "owners[i]");
      assertEq(offers[i], address(vif).offerPacked(asksMarketId, offerIds[i]), "offers[i]");
    }
  }

  function test_offerListInactive() public {
    vm.expectRevert(VifReader.OfferNotActive.selector);
    reader.packedOfferList(asksMarketId, 10, 100);
  }

  struct Offer {
    address maker;
    int24 tick;
    uint256 gives;
    uint40 offerId;
  }

  function testFuzz_packedOfferList(int256[] memory ticks, uint256 seed) public {
    vm.assume(ticks.length < 100);
    vm.setSeed(seed);

    for (uint256 i = 0; i < ticks.length; i++) {
      ticks[i] = bound(ticks[i], -8_000_000, -1_000_000);
    }

    LibSort.sort(ticks);
    Offer[] memory offers = new Offer[](ticks.length);
    for (uint256 i = 0; i < ticks.length; i++) {
      offers[i].tick = int24(ticks[i]);
      offers[i].gives = vm.randomUint(0.01 ether, 50 ether);
      offers[i].maker = vm.randomAddress();
      offers[i].offerId = _limitOrder(asks, offers[i].maker, offers[i].tick, offers[i].gives);
    }

    (uint40 nextOfferId, uint40[] memory packedOfferIds, uint256[] memory packedOffers, address[] memory owners) =
      reader.packedOfferList(asksMarketId, 0, offers.length);

    assertEq(nextOfferId, 0, "no offers left");

    for (uint256 i = 0; i < offers.length; i++) {
      assertEq(packedOfferIds[i], offers[i].offerId, "packedOfferIds[i]");
      assertEq(owners[i], offers[i].maker, "owners[i]");
      assertEq(packedOffers[i], address(vif).offerPacked(asksMarketId, offers[i].offerId), "packedOffers[i]");
    }
  }

  function testFuzz_packedBook(int256[] memory ticks, uint256 seed) public {
    vm.assume(ticks.length < 100);
    vm.setSeed(seed);

    for (uint256 i = 0; i < ticks.length; i++) {
      ticks[i] = bound(ticks[i], -8_000_000, -1_000_000);
    }

    LibSort.sort(ticks);
    Offer[] memory offers = new Offer[](ticks.length);
    for (uint256 i = 0; i < ticks.length; i++) {
      offers[i].tick = int24(ticks[i]);
      offers[i].gives = vm.randomUint(0.01 ether, 50 ether);
      offers[i].maker = vm.randomAddress();
      offers[i].offerId = _limitOrder(asks, offers[i].maker, offers[i].tick, offers[i].gives);
    }

    (uint24 nextPricePoint, uint256[] memory packedOfferLists) = reader.packedBook(asksMarketId, 0, 10_000);

    assertEq(nextPricePoint, 0, "no price points left");

    LibSort.uniquifySorted(ticks);
    OfferListUnpacked memory offerList;

    for (uint256 i = 0; i < packedOfferLists.length; i++) {
      offerList.from(packedOfferLists[i]);
      assertEq(offerList.index, int24(ticks[i]).index(1), string.concat("offerList tick: ", i.toString()));
    }
  }

  function testFuzz_offer(address _maker, int24 tick, uint256 gives) public {
    OfferUnpacked memory offer;
    offer.tick = int24(bound(tick, -8_388_607, -1_000_000));
    gives = bound(gives, 0.01 ether, 50 ether);

    uint40 offerId = _limitOrder(asks, _maker, offer.tick, gives);

    offer.isActive = true;
    offer.gives = uint48(gives / WETH_UNITS);

    uint256 packedOffer = offer.pack();

    // test offerPacked
    (uint256 _offer, address owner) = reader.offerPacked(asksMarketId, offerId);
    assertEq(_offer, packedOffer);
    assertEq(owner, _maker);

    // test offer
    (OfferUnpacked memory _offer2, address owner2) = reader.offer(asksMarketId, offerId);
    assertEq(_offer2.tick, offer.tick);
    assertEq(_offer2.gives, offer.gives);
    assertEq(_offer2.isActive, offer.isActive);
    assertEq(owner2, _maker);
  }

  function test_market() public view {
    Market memory market = reader.market(asksMarketId);
    assertEq(market.outboundToken, address(weth));
    assertEq(market.inboundToken, address(usdc));
    assertEq(market.outboundUnits, WETH_UNITS);
    assertEq(market.inboundUnits, USDC_UNITS);
    assertEq(market.minOutboundUnits, MIN_WETH_UNITS);
    assertEq(market.active, true);
    assertEq(market.fees, 0);

    market = reader.market(bidsMarketId);
    assertEq(market.outboundToken, address(usdc));
    assertEq(market.inboundToken, address(weth));
    assertEq(market.outboundUnits, USDC_UNITS);
    assertEq(market.inboundUnits, WETH_UNITS);
    assertEq(market.minOutboundUnits, MIN_USDC_UNITS);
    assertEq(market.active, true);
    assertEq(market.fees, 0);
  }

  function test_openMarkets() public {
    VifReader.OpenMarketsResult[] memory markets = reader.openMarkets();
    assertEq(markets.length, 0);

    reader.updateMarkets(address(weth), address(usdc), WETH_UNITS, USDC_UNITS, TICK_SPACING);
    markets = reader.openMarkets();
    assertEq(markets.length, 1);

    if (address(weth) < address(usdc)) {
      assertEq(markets[0].market01.id(), asksMarketId);
      assertEq(markets[0].market10.id(), bidsMarketId);
    } else {
      assertEq(markets[0].market01.id(), bidsMarketId);
      assertEq(markets[0].market10.id(), asksMarketId);
    }

    // sets the asks market to inactive
    vif.setActive(asksMarketId, false);

    reader.updateMarkets(address(weth), address(usdc), WETH_UNITS, USDC_UNITS, TICK_SPACING);
    markets = reader.openMarkets();
    assertEq(markets.length, 1); // should still be 1

    // sets the bids market to inactive
    vif.setActive(bidsMarketId, false);

    reader.updateMarkets(address(weth), address(usdc), WETH_UNITS, USDC_UNITS, TICK_SPACING);
    markets = reader.openMarkets();
    assertEq(markets.length, 0);
  }

  struct Tokens {
    address token0;
    address token1;
  }

  function testFuzz_openMarkets(uint256 nCreate, uint256 nRemove, uint256 seed) public {
    nCreate = bound(nCreate, 1, 100);
    nRemove = bound(nRemove, 0, nCreate);

    VifReader.Markets[] memory markets = new VifReader.Markets[](nCreate);
    Tokens[] memory tokens = new Tokens[](nCreate);

    vm.setSeed(seed);

    for (uint256 i = 0; i < nCreate; i++) {
      address token0 = vm.randomAddress();
      address token1 = vm.randomAddress();
      while (token0 == token1) {
        token1 = vm.randomAddress();
      }
      if (token0 > token1) {
        (token0, token1) = (token1, token0);
      }
      tokens[i].token0 = token0;
      tokens[i].token1 = token1;
      markets[i].market01 = vif.openMarket(token0, token1, WETH_UNITS, USDC_UNITS, TICK_SPACING, 0, MIN_WETH_UNITS);
      markets[i].market10 = vif.openMarket(token1, token0, USDC_UNITS, WETH_UNITS, TICK_SPACING, 0, MIN_USDC_UNITS);

      reader.updateMarkets(token0, token1, WETH_UNITS, USDC_UNITS, TICK_SPACING);
    }

    VifReader.OpenMarketsResult[] memory fromContract = reader.openMarkets();
    assertEq(fromContract.length, nCreate);

    for (uint256 i = 0; i < nRemove; i++) {
      vif.setActive(markets[i].market01, false);
      vif.setActive(markets[i].market10, false);
      reader.updateMarkets(tokens[i].token0, tokens[i].token1, WETH_UNITS, USDC_UNITS, TICK_SPACING);
    }

    fromContract = reader.openMarkets();
    assertEq(fromContract.length, nCreate - nRemove);

    for (uint256 i = 0; i < fromContract.length; i++) {
      assertTrue(fromContract[i].market01.active);
      assertTrue(fromContract[i].market10.active);
    }
  }

  function test_isPaused() public {
    assertFalse(reader.isPaused());
    vif.setPaused(true);
    assertTrue(reader.isPaused());
  }

  function testFuzz_isBlacklisted(address user) public {
    assertFalse(reader.isBlacklisted(user));
    vif.setBlacklisted(user, true);
    assertTrue(reader.isBlacklisted(user));
  }
}
