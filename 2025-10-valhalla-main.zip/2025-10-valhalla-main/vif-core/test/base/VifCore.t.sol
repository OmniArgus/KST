// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {VifCore} from "../../src/base/VifCore.sol";
import {ExtLoader} from "../../src/integrations/ExtLoader.sol";
import {ILockCallback} from "../../src/interfaces/ILockCallback.sol";
import {LibBlackList} from "../../src/libraries/LibBlackList.sol";
import {LibPausable} from "../../src/libraries/LibPausable.sol";
import {LibDeltas} from "../../src/libraries/LibDeltas.sol";
import {LibAuthorization} from "../../src/libraries/LibAuthorization.sol";
import {LibLock} from "../../src/libraries/LibLock.sol";
import {MockToken} from "../../src/mock/MockToken.sol";

contract VifCoreSubject is VifCore, ExtLoader {
  function blacklist(address user) external {
    LibBlackList.setBlacklisted(user, true);
  }

  function pause() external {
    LibPausable.setPaused(true);
  }

  function authorize(address user, address operator, bool authorized) external {
    LibAuthorization.setAuthorized(user, operator, authorized);
  }
}

contract MinimalLockCallback is ILockCallback {
  bytes public data;

  function lockCallback(bytes calldata _data) external returns (bytes memory) {
    data = _data;
    return "";
  }
}

contract CallbackTaking is ILockCallback {
  function lockCallback(bytes calldata _data) external returns (bytes memory) {
    (address token, uint256 amount, address receiver) = abi.decode(_data, (address, uint256, address));
    VifCore(msg.sender).take(token, amount, receiver);
    return "";
  }
}

contract CallbackSettleNAtiveMistmatch is ILockCallback {
  function lockCallback(bytes calldata _data) external returns (bytes memory) {
    (address token, uint256 amount, uint256 amountPassed, address from) =
      abi.decode(_data, (address, uint256, uint256, address));
    VifCore(msg.sender).settle{value: amountPassed}(token, amount, from);
    return "";
  }
}

contract ReentrantLockCallback is ILockCallback {
  function lockCallback(bytes calldata _data) external returns (bytes memory) {
    VifCore(msg.sender).lock(_data);
    return "";
  }
}

contract CallbackSettle is ILockCallback {
  function lockCallback(bytes calldata _data) external returns (bytes memory) {
    (address token, uint256 amount, address from) = abi.decode(_data, (address, uint256, address));
    VifCore(msg.sender).settle(token, amount, from);
    VifCore(msg.sender).take(token, amount, from);
    return "";
  }
}

contract VifCoreTest is Test {
  VifCoreSubject public subject;
  MinimalLockCallback public callback;
  CallbackTaking public callbackTaking;
  ReentrantLockCallback public callbackReentrant;
  CallbackSettleNAtiveMistmatch public callbackSettleNativeMistmatch;
  CallbackSettle public callbackSettle;

  MockToken public weth;

  address public user = makeAddr("user");

  function setUp() public {
    subject = new VifCoreSubject();
    callback = new MinimalLockCallback();
    callbackTaking = new CallbackTaking();
    callbackReentrant = new ReentrantLockCallback();
    callbackSettleNativeMistmatch = new CallbackSettleNAtiveMistmatch();
    callbackSettle = new CallbackSettle();

    weth = new MockToken("Wrapped Ether", "WETH", 18);
  }

  function testFuzz_lock(bytes memory data) public {
    vm.prank(address(callback));
    subject.lock(data);

    assertEq(callback.data(), data);
  }

  function testFuzz_cannotLockWhenBlacklisted(address _user) public {
    subject.blacklist(_user);

    vm.prank(_user);
    vm.expectRevert(LibBlackList.Blacklisted.selector);
    subject.lock("");
  }

  function test_cannotLockWhenPaused() public {
    subject.pause();

    vm.expectRevert(LibPausable.Paused.selector);
    subject.lock("");
  }

  function test_cannotUnlockWhenNotSettled() public {
    vm.deal(address(subject), 1 ether);

    vm.prank(address(callbackTaking));
    vm.expectRevert(LibDeltas.DeltasNotSettled.selector);
    subject.lock(abi.encode(address(0), 1 ether, user));
  }

  function test_cannotSettleNativeWithMistmatchValue() public {
    vm.deal(address(callbackSettleNativeMistmatch), 2 ether);

    vm.prank(address(callbackSettleNativeMistmatch));
    vm.expectRevert(VifCore.UnableToSettleNative.selector);
    subject.lock(abi.encode(address(0), 1 ether, 2 ether, address(callbackSettleNativeMistmatch)));
  }

  function test_cannotReenterLockCallback() public {
    vm.prank(address(callbackReentrant));
    vm.expectRevert(LibLock.Locked.selector);
    subject.lock("");
  }

  function test_cannotCallLockedFunctions() public {
    vm.expectRevert(LibLock.NotLocked.selector);
    subject.settle(address(0), 1 ether, user);

    vm.expectRevert(LibLock.NotLocked.selector);
    subject.take(address(0), 1 ether, user);
  }

  function test_settleOnlyWhenAuthorized() public {
    weth.mint(user, 1 ether);
    vm.prank(user);
    weth.approve(address(subject), 1 ether);

    vm.prank(address(callbackSettle));
    vm.expectRevert(LibAuthorization.NotAuthorized.selector);
    subject.lock(abi.encode(address(weth), 1 ether, user));

    subject.authorize(user, address(callbackSettle), true);

    vm.prank(address(callbackSettle));
    subject.lock(abi.encode(address(weth), 1 ether, user));
  }
}
