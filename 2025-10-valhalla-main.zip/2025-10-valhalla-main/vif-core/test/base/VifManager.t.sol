// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";

import {VifManager, Ownable} from "../../src/base/VifManager.sol";
import {ExtLoader} from "../../src/integrations/ExtLoader.sol";

import {LibMarketExt} from "../../src/libraries/external/LibMarketExt.sol";
import {Market, LibMarket} from "../../src/libraries/LibMarket.sol";
import {LibProvisionExt} from "../../src/libraries/external/LibProvisionExt.sol";
import {LibFeesExt} from "../../src/libraries/external/LibFeesExt.sol";
import {LibProvision} from "../../src/libraries/LibProvision.sol";
import {LibFees} from "../../src/libraries/LibFees.sol";
import {LibPausable} from "../../src/libraries/LibPausable.sol";
import {LibPausableExt} from "../../src/libraries/external/LibPausableExt.sol";
import {LibBlackListExt} from "../../src/libraries/external/LibBlackListExt.sol";
import {LibBlackList} from "../../src/libraries/LibBlackList.sol";

import {MockToken, ERC20} from "../../src/mock/MockToken.sol";

contract VifManagerSubject is VifManager, ExtLoader {
  function initialize(address owner, uint24 provision) external {
    _initializeVifManager(owner, provision);
  }
}

contract VifManagerTest is Test {
  using LibMarketExt for address;
  using LibMarket for Market;
  using LibProvisionExt for address;
  using LibFeesExt for address;
  using LibPausableExt for address;
  using LibBlackListExt for address;

  VifManagerSubject public subject;
  address public owner = makeAddr("owner");

  MockToken public weth;

  function setUp() public {
    subject = new VifManagerSubject();
    subject.initialize(owner, 100);

    weth = new MockToken("Wrapped Ether", "WETH", 18);
  }

  function test_cannotInitializeTwice() public {
    vm.expectRevert(Ownable.AlreadyInitialized.selector);
    subject.initialize(address(this), 100);
  }

  function testFuzz_guardedFunctions(address caller) public {
    vm.assume(caller != owner);

    vm.startPrank(caller);

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.openMarket(address(0), address(0), 100, 100, 100, 100, 100);

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.setFees(bytes32(0), 100);

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.setMinOutboundUnits(bytes32(0), 100);

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.setActive(bytes32(0), true);

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.setProvisions(100);

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.withdrawFees(address(0), 100, address(0));

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.renounceOwnership();

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.transferOwnership(address(0));

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.completeOwnershipHandover(address(0));

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.setPaused(true);

    vm.expectRevert(Ownable.Unauthorized.selector);
    subject.setBlacklisted(address(0), true);

    vm.stopPrank();
  }

  function feesFixture() public pure returns (uint24[] memory fees) {
    fees = new uint24[](1);
    fees[0] = 9;
  }

  function testFuzz_openMarket(
    address outboundToken,
    address inboundToken,
    uint64 outboundUnits,
    uint64 inboundUnits,
    uint16 tickSpacing,
    uint16 fees,
    uint32 minOutboundUnits
  ) public {
    vm.assume(outboundUnits > 0 && inboundUnits > 0);
    vm.assume(minOutboundUnits & 0x7fffffff == minOutboundUnits);
    vm.assume(tickSpacing > 0);
    vm.assume(minOutboundUnits > 0);

    Market memory market = Market({
      outboundToken: outboundToken,
      outboundUnits: outboundUnits,
      minOutboundUnits: minOutboundUnits,
      inboundToken: inboundToken,
      inboundUnits: inboundUnits,
      tickSpacing: tickSpacing,
      fees: fees,
      active: true
    });

    vm.expectEmit(true, true, true, true);
    emit LibMarket.NewMarket(
      market.id(), outboundToken, inboundToken, outboundUnits, minOutboundUnits, inboundUnits, tickSpacing, fees
    );

    vm.prank(owner);
    bytes32 marketId =
      subject.openMarket(outboundToken, inboundToken, outboundUnits, inboundUnits, tickSpacing, fees, minOutboundUnits);

    assertNotEq(marketId, bytes32(0));
    market = address(subject).market(marketId);

    assertEq(market.outboundToken, outboundToken);
    assertEq(market.outboundUnits, outboundUnits);
    assertEq(market.minOutboundUnits, minOutboundUnits);
    assertEq(market.inboundToken, inboundToken);
    assertEq(market.inboundUnits, inboundUnits);
    assertEq(market.tickSpacing, tickSpacing);
    assertEq(market.fees, fees);
    assertEq(market.active, true);

    assertEq(market.id(), marketId);

    // cannot create twice
    vm.expectRevert(LibMarket.AlreadyCreated.selector);
    vm.prank(owner);
    subject.openMarket(outboundToken, inboundToken, outboundUnits, inboundUnits, tickSpacing, fees, minOutboundUnits);
  }

  function test_openMarket_invalidUnits() public {
    vm.expectRevert(LibMarket.InvalidUnits.selector);
    vm.prank(owner);
    subject.openMarket(address(0), address(0), 0, 100, 100, 100, 100);

    vm.expectRevert(LibMarket.InvalidUnits.selector);
    vm.prank(owner);
    subject.openMarket(address(0), address(0), 100, 0, 100, 100, 100);

    vm.expectRevert(LibMarket.InvalidUnits.selector);
    vm.prank(owner);
    subject.openMarket(address(0), address(0), 0, 0, 100, 100, 100);
  }

  function testFuzz_setFees(
    address outboundToken,
    address inboundToken,
    uint64 outboundUnits,
    uint64 inboundUnits,
    uint16 tickSpacing,
    uint16 fees,
    uint32 minOutboundUnits,
    uint16 newFees
  ) public {
    vm.assume(outboundUnits > 0 && inboundUnits > 0);
    vm.assume(tickSpacing > 0);
    vm.assume(minOutboundUnits & 0x7fffffff == minOutboundUnits);
    vm.assume(minOutboundUnits > 0);

    Market memory market = Market({
      outboundToken: outboundToken,
      outboundUnits: outboundUnits,
      minOutboundUnits: minOutboundUnits,
      inboundToken: inboundToken,
      inboundUnits: inboundUnits,
      tickSpacing: tickSpacing,
      fees: fees,
      active: true
    });

    vm.expectEmit(true, true, true, true);
    emit LibMarket.NewMarket(
      market.id(), outboundToken, inboundToken, outboundUnits, minOutboundUnits, inboundUnits, tickSpacing, fees
    );

    vm.prank(owner);
    bytes32 marketId =
      subject.openMarket(outboundToken, inboundToken, outboundUnits, inboundUnits, tickSpacing, fees, minOutboundUnits);

    market = address(subject).market(marketId);
    assertEq(market.fees, fees);

    vm.expectEmit(true, true, true, true);
    emit LibMarket.SetFees(marketId, newFees);

    vm.prank(owner);
    subject.setFees(marketId, newFees);

    market = address(subject).market(marketId);
    assertEq(market.fees, newFees);
  }

  function testFuzz_setMinOutboundUnits(
    address outboundToken,
    address inboundToken,
    uint64 outboundUnits,
    uint64 inboundUnits,
    uint16 tickSpacing,
    uint16 fees,
    uint32 minOutboundUnits,
    uint32 newMinOutboundUnits
  ) public {
    vm.assume(outboundUnits > 0 && inboundUnits > 0);
    vm.assume(tickSpacing > 0);
    vm.assume(minOutboundUnits & 0x7fffffff == minOutboundUnits);
    vm.assume(newMinOutboundUnits & 0x7fffffff == newMinOutboundUnits);
    vm.assume(minOutboundUnits > 0);
    vm.assume(newMinOutboundUnits > 0);

    Market memory market = Market({
      outboundToken: outboundToken,
      outboundUnits: outboundUnits,
      minOutboundUnits: minOutboundUnits,
      inboundToken: inboundToken,
      inboundUnits: inboundUnits,
      tickSpacing: tickSpacing,
      fees: fees,
      active: true
    });

    vm.expectEmit(true, true, true, true);
    emit LibMarket.NewMarket(
      market.id(), outboundToken, inboundToken, outboundUnits, minOutboundUnits, inboundUnits, tickSpacing, fees
    );

    vm.prank(owner);
    bytes32 marketId =
      subject.openMarket(outboundToken, inboundToken, outboundUnits, inboundUnits, tickSpacing, fees, minOutboundUnits);

    market = address(subject).market(marketId);
    assertEq(market.minOutboundUnits, minOutboundUnits);

    vm.expectEmit(true, true, true, true);
    emit LibMarket.SetMinOutboundUnits(marketId, newMinOutboundUnits);

    vm.prank(owner);
    subject.setMinOutboundUnits(marketId, newMinOutboundUnits);

    market = address(subject).market(marketId);
    assertEq(market.minOutboundUnits, newMinOutboundUnits);
  }

  function testFuzz_setActive(
    address outboundToken,
    address inboundToken,
    uint64 outboundUnits,
    uint64 inboundUnits,
    uint16 tickSpacing,
    uint16 fees,
    uint32 minOutboundUnits,
    bool newActive
  ) public {
    vm.assume(outboundUnits > 0 && inboundUnits > 0);
    vm.assume(tickSpacing > 0);
    vm.assume(minOutboundUnits & 0x7fffffff == minOutboundUnits);
    vm.assume(minOutboundUnits > 0);

    Market memory market = Market({
      outboundToken: outboundToken,
      outboundUnits: outboundUnits,
      minOutboundUnits: minOutboundUnits,
      inboundToken: inboundToken,
      inboundUnits: inboundUnits,
      tickSpacing: tickSpacing,
      fees: fees,
      active: true
    });

    vm.expectEmit(true, true, true, true);
    emit LibMarket.NewMarket(
      market.id(), outboundToken, inboundToken, outboundUnits, minOutboundUnits, inboundUnits, tickSpacing, fees
    );

    vm.prank(owner);
    bytes32 marketId =
      subject.openMarket(outboundToken, inboundToken, outboundUnits, inboundUnits, tickSpacing, fees, minOutboundUnits);

    market = address(subject).market(marketId);
    assertEq(market.active, true);

    vm.expectEmit(true, true, true, true);
    emit LibMarket.SetActive(marketId, newActive);
    vm.prank(owner);
    subject.setActive(marketId, newActive);

    market = address(subject).market(marketId);
    assertEq(market.active, newActive);
  }

  function testFuzz_setProvisions(uint24 newProvision) public {
    vm.assume(newProvision <= 0x7fffff);

    vm.expectEmit(true, true, true, true);
    emit LibProvision.SetProvision(newProvision);
    vm.prank(owner);
    subject.setProvisions(newProvision);

    assertEq(address(subject).provision(), newProvision);
  }

  function testFuzz_setProvisionsTooLarge(uint24 newProvision) public {
    newProvision = uint24(bound(newProvision, 0x7fffff + 1, type(uint24).max));

    vm.expectRevert(LibProvision.ProvisionTooLarge.selector);
    vm.prank(owner);
    subject.setProvisions(newProvision);
  }

  function testFuzz_withdrawFees(uint256 amount, address receiver) public {
    vm.assume(amount > 0);
    vm.assume(receiver != address(0));
    weth.mint(address(subject), amount);

    vm.record();
    address(subject).fees(address(weth));

    (bytes32[] memory reads,) = vm.accesses(address(subject));
    assertEq(reads.length, 1);
    vm.store(address(subject), reads[0], bytes32(amount));

    assertEq(address(subject).fees(address(weth)), amount);

    vm.expectEmit(true, true, true, true, address(subject));
    emit LibFees.FeesClaimed(address(weth), amount);
    vm.expectEmit(true, true, true, true, address(weth));
    emit ERC20.Transfer(address(subject), receiver, amount);
    vm.prank(owner);
    subject.withdrawFees(address(weth), amount, receiver);

    assertEq(weth.balanceOf(receiver), amount);
    assertEq(address(subject).fees(address(weth)), 0);
  }

  function test_setPaused() public {
    // should not be paused
    assertFalse(address(subject).isPaused());

    // pause
    vm.expectEmit(true, true, true, true);
    emit LibPausable.SetPaused(true);
    vm.prank(owner);
    subject.setPaused(true);

    // should be paused
    assertTrue(address(subject).isPaused());

    // unpause
    vm.expectEmit(true, true, true, true);
    emit LibPausable.SetPaused(false);
    vm.prank(owner);
    subject.setPaused(false);

    // should not be paused
    assertFalse(address(subject).isPaused());
  }

  function testFuzz_setBlacklisted(address user) public {
    assertFalse(address(subject).isBlacklisted(user));

    vm.expectEmit(true, true, true, true);
    emit LibBlackList.SetBlacklisted(user, true);
    vm.prank(owner);
    subject.setBlacklisted(user, true);

    assertTrue(address(subject).isBlacklisted(user));

    vm.expectEmit(true, true, true, true);
    emit LibBlackList.SetBlacklisted(user, false);
    vm.prank(owner);
    subject.setBlacklisted(user, false);

    assertFalse(address(subject).isBlacklisted(user));
  }
}
