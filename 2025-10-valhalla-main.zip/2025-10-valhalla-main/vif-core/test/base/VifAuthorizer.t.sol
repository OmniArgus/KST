// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test, Vm} from "forge-std/Test.sol";

import {VifAuthorizer, Authorization} from "../../src/base/VifAuthorizer.sol";
import {ExtLoader} from "../../src/integrations/ExtLoader.sol";

import {LibAuthorizationExt} from "../../src/libraries/external/LibAuthorizationExt.sol";
import {LibAuthorization} from "../../src/libraries/LibAuthorization.sol";

contract VifAuthorizerSubject is VifAuthorizer, ExtLoader {}

contract VifAuthorizerTest is Test {
  using LibAuthorizationExt for address;

  VifAuthorizerSubject public subject;
  Vm.Wallet internal alice = vm.createWallet("alice");
  Vm.Wallet internal bob = vm.createWallet("bob");

  /// @dev keccak256("Authorization(address authorizer,address authorized,bool isAuthorized,uint256 nonce,uint256 deadline)")
  uint256 private constant _AUTHORIZATION_TYPEHASH = 0x81d0284fb0e2cde18d0553b06189d6f7613c96a01bb5b5e7828eade6a0dcac91;

  /// @dev `keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)")`.
  bytes32 internal constant _DOMAIN_TYPEHASH = 0x8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f;

  function setUp() public {
    subject = new VifAuthorizerSubject();
  }

  function _signAuth(Vm.Wallet memory wallet, address authorized, bool isAuthorized, uint256 nonce, uint256 deadline)
    internal
    view
    returns (Authorization memory auth, bytes memory signature)
  {
    auth = Authorization({
      authorizer: wallet.addr,
      authorized: authorized,
      isAuthorized: isAuthorized,
      nonce: nonce,
      deadline: deadline
    });

    bytes32 domainSeparator;

    {
      (, string memory name, string memory version, uint256 chainId, address verifyingContract,,) =
        subject.eip712Domain();

      domainSeparator = keccak256(
        abi.encode(_DOMAIN_TYPEHASH, keccak256(bytes(name)), keccak256(bytes(version)), chainId, verifyingContract)
      );
    }

    bytes32 structHash = keccak256(abi.encode(_AUTHORIZATION_TYPEHASH, auth));

    bytes32 digest = keccak256(abi.encodePacked("\x19\x01", domainSeparator, structHash));

    (uint8 v, bytes32 r, bytes32 s) = vm.sign(wallet.privateKey, digest);
    signature = abi.encodePacked(r, s, v);
  }

  function test_domain() public view {
    (, string memory name, string memory version,, address verifyingContract,,) = subject.eip712Domain();

    assertEq(name, "Vif");
    assertEq(version, "1.0.0");
    assertEq(verifyingContract, address(subject));
  }

  function test_authorize() public {
    assertFalse(address(subject).authorized(alice.addr, bob.addr));

    vm.expectEmit(true, true, false, true);
    emit LibAuthorization.Authorized(alice.addr, bob.addr, true);
    vm.prank(alice.addr);
    subject.authorize(bob.addr, true);
    assertTrue(address(subject).authorized(alice.addr, bob.addr));

    vm.expectEmit(true, true, false, true);
    emit LibAuthorization.Authorized(alice.addr, bob.addr, false);
    vm.prank(alice.addr);
    subject.authorize(bob.addr, false);
    assertFalse(address(subject).authorized(alice.addr, bob.addr));
  }

  function test_authorizeWithSig() public {
    assertFalse(address(subject).authorized(alice.addr, bob.addr));

    (Authorization memory auth, bytes memory signature) = _signAuth(alice, bob.addr, true, 0, type(uint256).max);
    vm.expectEmit(true, true, false, true);
    emit LibAuthorization.Authorized(alice.addr, bob.addr, true);
    subject.authorizeWithSig(auth, signature);
    assertTrue(address(subject).authorized(alice.addr, bob.addr));

    (auth, signature) = _signAuth(alice, bob.addr, false, 1, type(uint256).max);
    vm.expectEmit(true, true, false, true);
    emit LibAuthorization.Authorized(alice.addr, bob.addr, false);
    subject.authorizeWithSig(auth, signature);
  }

  function test_signatureExpired() public {
    (Authorization memory auth, bytes memory signature) = _signAuth(alice, bob.addr, true, 0, block.timestamp);
    vm.warp(block.timestamp + 1);

    vm.expectRevert(VifAuthorizer.AuthorizationExpired.selector);
    subject.authorizeWithSig(auth, signature);
  }

  function test_signatureInvalidNonce() public {
    (Authorization memory auth, bytes memory signature) = _signAuth(alice, bob.addr, true, 0, type(uint256).max);

    vm.expectEmit(true, true, false, true);
    emit LibAuthorization.Authorized(alice.addr, bob.addr, true);
    subject.authorizeWithSig(auth, signature);
    assertTrue(address(subject).authorized(alice.addr, bob.addr));

    // cannot reuse signature
    vm.expectRevert(LibAuthorization.InvalidNonce.selector);
    subject.authorizeWithSig(auth, signature);
  }

  function test_wrongSigner() public {
    (Authorization memory auth, bytes memory signature) = _signAuth(bob, bob.addr, true, 0, type(uint256).max);
    auth.authorizer = alice.addr;

    vm.expectRevert(LibAuthorization.NotAuthorized.selector);
    subject.authorizeWithSig(auth, signature);
  }
}
