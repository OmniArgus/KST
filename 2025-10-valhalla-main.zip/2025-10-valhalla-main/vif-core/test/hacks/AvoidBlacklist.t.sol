// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {Vif} from "../../src/Vif.sol";
import {LibDeltasExt} from "../../src/libraries/external/LibDeltasExt.sol";
import {LibMarketExt, Market} from "../../src/libraries/external/LibMarketExt.sol";
import {MockToken} from "../../src/mock/MockToken.sol";
import {VifRouter} from "../../src/periphery/VifRouter.sol";
import {Commands} from "../../src/libraries/periphery/Commands.sol";
import {LimitArgs, SweepArgs, DispatchResult} from "../../src/libraries/periphery/Types.sol";
import {SafeTransferLib} from "lib/solady/src/utils/SafeTransferLib.sol";

// test a scenario where a contract avoids blacklist

// context: this hack was possible before since when acquiring the lock,
// the caller of the locked function was not restricted to the unlocker.

contract HackContract {
  using LibDeltasExt for address;
  using LibMarketExt for address;
  using SafeTransferLib for address;

  Vif public vif;

  bytes32 market;
  uint40 offerId;

  address receiver;

  constructor(address _vif, bytes32 _market, uint40 _offerId, address _receiver) {
    vif = Vif(_vif);
    market = _market;
    offerId = _offerId;
    receiver = _receiver;
  }

  function _exploit() internal {
    Market memory _market = address(vif).market(market);

    // cancel the offer
    vif.cancel(market, offerId);

    // take all the funds
    vif.take(_market.outboundToken, uint256(address(vif).deltaOf(_market.outboundToken)), receiver);
    vif.take(_market.inboundToken, uint256(address(vif).deltaOf(_market.inboundToken)), receiver);
    vif.take(LibDeltasExt.NATIVE, uint256(address(vif).deltaOf(LibDeltasExt.NATIVE)), receiver);

    receiver.safeTransferAllETH();
  }

  receive() external payable {
    _exploit();
  }
}

contract AvoidBlacklistTest is Test {
  Vif public vif;
  VifRouter public router;

  address public maker = makeAddr("maker");
  address public hacker = makeAddr("hacker");

  MockToken public weth;
  MockToken public usdc;

  uint64 internal constant WETH_UNITS = 1e13;
  uint64 internal constant USDC_UNITS = 1e4;

  uint24 internal constant MIN_WETH_UNITS = 1000;
  uint24 internal constant MIN_USDC_UNITS = 1000;

  uint24 internal constant PROVISION = 100;

  uint16 internal constant TICK_SPACING = 1;

  bytes32 public market;

  function setUp() public {
    weth = new MockToken("Wrapped Ether", "WETH", 18);
    usdc = new MockToken("USD Coin", "USDC", 6);

    vif = new Vif(address(this), PROVISION);
    router = new VifRouter(address(vif), address(weth), address(this)); // invalid weth, but we don't care
    market = vif.openMarket(address(weth), address(usdc), WETH_UNITS, USDC_UNITS, TICK_SPACING, 0, MIN_WETH_UNITS);
  }

  function test_hackAvoidBlacklist() public {
    // genuine maker creates a limit order
    bytes memory commands =
      abi.encodePacked(Commands.LIMIT_SINGLE, Commands.SETTLE_ALL, Commands.SETTLE_ALL, Commands.SWEEP);
    bytes[] memory args = new bytes[](4);
    args[0] = abi.encode(
      LimitArgs({
        marketId: market,
        initialOfferId: 0,
        gives: 1 ether,
        tick: -2_072_336,
        expiry: uint32(block.timestamp + 1000),
        provision: 0
      })
    );
    args[1] = abi.encode(weth);
    args[2] = abi.encode(address(0)); // send the native tokens for provision
    args[3] = abi.encode(SweepArgs({token: address(0), receiver: maker}));

    vm.deal(maker, 1 ether);
    weth.mint(maker, 1 ether);

    vm.startPrank(maker);
    weth.approve(address(vif), 1 ether);
    vif.authorize(address(router), true);
    DispatchResult[] memory results = router.execute{value: 1 ether}(commands, args);
    vm.stopPrank();

    uint40 offerId = abi.decode(results[0].returnData, (uint40));
    assertTrue(results[0].success, "limit order should be successful");
    assertEq(offerId, 1, "offer id should be 1");

    // define the hacker contract
    HackContract hackContract = new HackContract(address(vif), market, offerId, hacker);

    // maker approves the hacker contract
    vm.prank(maker);
    vif.authorize(address(hackContract), true);

    // The protocol blacklists the hacker contract
    vif.setBlacklisted(address(hackContract), true);

    // hacker calls the genuine router contract to unlock
    // the call will send a native transfer calling back the blacklisted contract that can then operate
    commands = abi.encodePacked(Commands.SETTLE, Commands.TAKE_ALL);
    args = new bytes[](2);
    args[0] = abi.encode(address(0), 0.0001 ether);
    args[1] = abi.encode(address(0), address(hackContract));

    vm.deal(hacker, 0.0001 ether);

    vm.prank(hacker);
    // should revert because the hacker contract is not the one acquiring the locks
    vm.expectRevert(SafeTransferLib.ETHTransferFailed.selector);
    router.execute{value: 0.0001 ether}(commands, args);
  }
}
