// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {Vif} from "../../src/Vif.sol";
import {MockToken} from "../../src/mock/MockToken.sol";

contract HackContract {
  Vif public vif;
  MockToken public token;

  constructor(Vif _vif, MockToken _token) {
    vif = _vif;
    token = _token;
  }

  function callExploit() external {
    vif.lock("");
  }

  function _exploit() internal {
    // balance to exploit
    uint256 B = token.balanceOf(address(vif));

    uint256 max = 2 ** 255;

    // mint tokens to contract
    token.mint(address(vif), max + 1);

    // ask for the minted tokens back
    vif.take(address(token), max + 1, address(this));

    // transfer funds to contract
    bool success = token.transfer(address(vif), max - 1 - B);
    require(success, "Transfer failed");

    // ask for more tokens than sent
    vif.take(address(token), max - 1, address(this));

    // burn initial flash mint
    token.burn(address(this), max + 1);
  }

  fallback() external {
    _exploit();
    /// @solidity memory-safe-assembly
    assembly {
      mstore(0x00, 0x20)
      mstore(0x20, 0x00)
      return(0x00, 0x40)
    }
  }
}

contract TokenOverflowTest is Test {
  Vif public vif;
  MockToken public token;
  HackContract public hack;

  error AmountOverflow();

  function setUp() public {
    vif = new Vif(address(this), 100);
    token = new MockToken("Test Token", "TT", 18);
    hack = new HackContract(vif, token);
  }

  function test_exploit() public {
    // send initial balance to vif
    token.mint(address(vif), 1 ether);

    // call the exploit
    vm.expectRevert(AmountOverflow.selector);
    hack.callExploit();

    uint256 endBalance = token.balanceOf(address(vif));
    assertEq(endBalance, 1 ether);
  }
}
