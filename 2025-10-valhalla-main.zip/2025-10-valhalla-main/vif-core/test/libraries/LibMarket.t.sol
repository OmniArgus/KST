// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibMarket, Market} from "../../src/libraries/LibMarket.sol";

contract LibMarketHarness {
  using LibMarket for Market;
  using LibMarket for bytes32;

  function callCreate(Market memory m) external returns (bytes32 id) {
    id = m.create();
  }

  function callMarket(bytes32 id) external view returns (Market memory) {
    return LibMarket.market(id);
  }

  function callSetFees(bytes32 id, uint16 fees) external {
    LibMarket.setFees(id, fees);
  }

  function callSetMinOutboundUnits(bytes32 id, uint32 minOutboundUnits) external {
    LibMarket.setMinOutboundUnits(id, minOutboundUnits);
  }

  function callSetActive(bytes32 id, bool active) external {
    LibMarket.setActive(id, active);
  }

  function callCheckActive(bytes32 id) external view {
    LibMarket.checkActive(id.market());
  }

  function callCheckVolume(bytes32 id, uint48 volume) external view {
    LibMarket.checkVolume(id.market(), volume);
  }

  function callNormalizeVolume(Market memory m, uint256 volume, bool fillWants) external pure returns (uint64) {
    return LibMarket.normalizeVolume(m, volume, fillWants);
  }

  function callNormalizeGives(Market memory m, uint256 gives) external pure returns (uint48) {
    return LibMarket.normalizeGives(m, gives);
  }
}

contract LibMarketTest is Test {
  using LibMarket for Market;
  using LibMarket for bytes32;

  LibMarketHarness internal harness;

  address internal tokenA = address(0xA);
  address internal tokenB = address(0xB);

  function setUp() public {
    harness = new LibMarketHarness();
  }

  function _sampleMarket(bool active) internal view returns (Market memory m) {
    m = Market({
      outboundToken: tokenA,
      outboundUnits: 1_000,
      minOutboundUnits: 10,
      inboundToken: tokenB,
      inboundUnits: 2_000,
      fees: 12_345, // fits in 16 bits
      tickSpacing: 10,
      active: active
    });
  }

  function test_create_emits_and_stores() public {
    Market memory m = _sampleMarket(true);

    // Expect NewMarket event
    // event NewMarket(bytes32 indexed market, address indexed outboundToken, address indexed inboundToken, uint64 outboundUnits, uint64 inboundUnits)
    bytes32 expectedId = m.id();
    vm.expectEmit(true, true, true, true);
    emit LibMarket.NewMarket(
      expectedId, tokenA, tokenB, m.outboundUnits, m.minOutboundUnits, m.inboundUnits, m.tickSpacing, m.fees
    );

    bytes32 id = harness.callCreate(m);

    // Read back and compare all fields
    Market memory stored = harness.callMarket(id);
    assertEq(stored.outboundToken, tokenA);
    assertEq(stored.inboundToken, tokenB);
    assertEq(stored.outboundUnits, m.outboundUnits);
    assertEq(stored.inboundUnits, m.inboundUnits);
    assertEq(stored.minOutboundUnits, m.minOutboundUnits);
    assertEq(stored.tickSpacing, m.tickSpacing);
    assertEq(stored.fees, m.fees);
    assertTrue(stored.active);
  }

  function test_setFees_updates_and_emits() public {
    bytes32 id = harness.callCreate(_sampleMarket(true));

    uint16 newFees = 25_000; // still within 16 bits
    vm.expectEmit(true, false, false, true);
    emit LibMarket.SetFees(id, newFees);
    harness.callSetFees(id, newFees);

    Market memory stored = harness.callMarket(id);
    assertEq(stored.fees, newFees);
  }

  function test_setMinOutboundUnits_updates_and_emits() public {
    bytes32 id = harness.callCreate(_sampleMarket(true));

    uint32 newMin = 777;
    vm.expectEmit(true, false, false, true);
    emit LibMarket.SetMinOutboundUnits(id, newMin);
    harness.callSetMinOutboundUnits(id, newMin);

    Market memory stored = harness.callMarket(id);
    assertEq(stored.minOutboundUnits, newMin);
  }

  function test_setActive_updates_and_emits() public {
    bytes32 id = harness.callCreate(_sampleMarket(false));

    vm.expectEmit(true, false, false, true);
    emit LibMarket.SetActive(id, true);
    harness.callSetActive(id, true);

    Market memory stored = harness.callMarket(id);
    assertTrue(stored.active);
  }

  function test_checkActive_and_checkVolume_happy_paths() public view {
    Market memory m = _sampleMarket(true);
    LibMarket.checkActive(m);
    LibMarket.checkVolume(m, 10);
    LibMarket.checkVolume(m, 100);
  }

  function testFuzz_setFees(uint16 fees) public {
    bytes32 id = harness.callCreate(_sampleMarket(true));

    vm.expectEmit(true, false, false, true);
    emit LibMarket.SetFees(id, fees);
    harness.callSetFees(id, fees);

    Market memory stored = harness.callMarket(id);
    assertEq(stored.fees, fees);
  }

  function testFuzz_setMinOutboundUnits(uint32 minOutboundUnits) public {
    vm.assume(minOutboundUnits & 0x7fffffff == minOutboundUnits);
    vm.assume(minOutboundUnits > 0);
    bytes32 id = harness.callCreate(_sampleMarket(true));

    vm.expectEmit(true, false, false, true);
    emit LibMarket.SetMinOutboundUnits(id, minOutboundUnits);
    harness.callSetMinOutboundUnits(id, minOutboundUnits);

    Market memory stored = harness.callMarket(id);
    assertEq(stored.minOutboundUnits, minOutboundUnits);
  }

  function testFuzz_setMinOutboundUnitsOverflow(uint32 minOutboundUnits) public {
    minOutboundUnits = uint32(bound(minOutboundUnits, 0x7fffffff + 1, type(uint32).max));
    bytes32 id = harness.callCreate(_sampleMarket(true));

    uint32 expected = minOutboundUnits & 0x7fffffff;
    vm.assume(expected > 0);

    vm.expectEmit(true, false, false, true);
    emit LibMarket.SetMinOutboundUnits(id, expected);
    harness.callSetMinOutboundUnits(id, expected);

    Market memory stored = harness.callMarket(id);
    assertEq(stored.minOutboundUnits, expected);
  }

  function test_alreadyCreatedRevertsStartActive() public {
    harness.callCreate(_sampleMarket(true));

    vm.expectRevert(LibMarket.AlreadyCreated.selector);
    harness.callCreate(_sampleMarket(true));

    vm.expectRevert(LibMarket.AlreadyCreated.selector);
    harness.callCreate(_sampleMarket(false));
  }

  function test_alreadyCreatedRevertsStartInactive() public {
    harness.callCreate(_sampleMarket(false));

    vm.expectRevert(LibMarket.AlreadyCreated.selector);
    harness.callCreate(_sampleMarket(true));

    vm.expectRevert(LibMarket.AlreadyCreated.selector);
    harness.callCreate(_sampleMarket(false));
  }

  function testFuzz_notCreatedMarketReverts(bytes32 id) public {
    vm.expectRevert(LibMarket.NotCreated.selector);
    harness.callSetFees(id, 10_000);

    vm.expectRevert(LibMarket.NotCreated.selector);
    harness.callSetMinOutboundUnits(id, 10);

    vm.expectRevert(LibMarket.NotCreated.selector);
    harness.callSetActive(id, true);
  }

  function test_checkActive() public {
    bytes32 id = harness.callCreate(_sampleMarket(true));
    harness.callCheckActive(id);
  }

  function test_checkActiveReverts() public {
    bytes32 id = harness.callCreate(_sampleMarket(false));
    vm.expectRevert(LibMarket.NotActive.selector);
    harness.callCheckActive(id);
  }

  function test_checkVolume() public {
    Market memory m = _sampleMarket(true);
    bytes32 id = harness.callCreate(m);
    harness.callCheckVolume(id, m.minOutboundUnits);
  }

  function test_checkVolumeReverts() public {
    Market memory m = _sampleMarket(true);
    bytes32 id = harness.callCreate(m);
    vm.expectRevert(LibMarket.DensityTooLow.selector);
    harness.callCheckVolume(id, m.minOutboundUnits - 1);
  }

  function test_normalizeVolume() public view {
    Market memory m = _sampleMarket(true);
    m.outboundUnits = 100;
    m.inboundUnits = 10;
    uint256 amount = 1000;

    uint64 normalized = LibMarket.normalizeVolume(m, amount, true);
    assertEq(normalized, 10);

    normalized = LibMarket.normalizeVolume(m, amount, false);
    assertEq(normalized, 100);
  }

  function test_normalizeVolumeReverts() public {
    Market memory m = _sampleMarket(true);
    m.outboundUnits = 1;
    m.inboundUnits = 1;
    uint256 amount = uint256(type(uint64).max) + 1;

    vm.expectRevert(LibMarket.AmountOverflow.selector);
    harness.callNormalizeVolume(m, amount, true);

    vm.expectRevert(LibMarket.AmountOverflow.selector);
    harness.callNormalizeVolume(m, amount, false);
  }

  function test_normalizeGives() public view {
    Market memory m = _sampleMarket(true);
    m.outboundUnits = 100;
    uint256 gives = 1000;

    uint48 normalized = LibMarket.normalizeGives(m, gives);
    assertEq(normalized, 10);
  }

  function test_normalizeGivesReverts() public {
    Market memory m = _sampleMarket(true);
    m.outboundUnits = 1;
    uint256 gives = uint256(type(uint48).max) + 1;

    vm.expectRevert(LibMarket.AmountOverflow.selector);
    harness.callNormalizeGives(m, gives);
  }

  function test_invalidUnitsReverts() public {
    Market memory m = _sampleMarket(true);
    m.outboundUnits = 0;
    m.inboundUnits = 1;
    vm.expectRevert(LibMarket.InvalidUnits.selector);
    harness.callCreate(m);

    m.outboundUnits = 1;
    m.inboundUnits = 0;
    vm.expectRevert(LibMarket.InvalidUnits.selector);
    harness.callCreate(m);

    m.outboundUnits = 0;
    m.inboundUnits = 0;
    vm.expectRevert(LibMarket.InvalidUnits.selector);
    harness.callCreate(m);
  }

  function test_invalidTickSpacingReverts() public {
    Market memory m = _sampleMarket(true);
    m.tickSpacing = 0;
    vm.expectRevert(LibMarket.InvalidTickSpacing.selector);
    harness.callCreate(m);
  }

  function testFuzz_packUnpack(Market memory m) public {
    vm.assume(m.outboundUnits > 0);
    vm.assume(m.inboundUnits > 0);
    vm.assume(m.tickSpacing > 0);
    vm.assume(m.minOutboundUnits > 0);
    vm.assume(m.minOutboundUnits & 0x7fffffff == m.minOutboundUnits);

    bytes32 id = harness.callCreate(m);
    Market memory unpacked = harness.callMarket(id);

    assertEq(unpacked.outboundUnits, m.outboundUnits);
    assertEq(unpacked.inboundUnits, m.inboundUnits);
    assertEq(unpacked.minOutboundUnits, m.minOutboundUnits);
    assertEq(unpacked.tickSpacing, m.tickSpacing);
    assertEq(unpacked.fees, m.fees);
    assertEq(unpacked.active, m.active);
    assertEq(unpacked.outboundToken, m.outboundToken);
    assertEq(unpacked.inboundToken, m.inboundToken);
  }

  function test_invalidMinOutboundUnitsReverts() public {
    Market memory m = _sampleMarket(true);
    m.minOutboundUnits = 0;
    vm.expectRevert(LibMarket.InvalidMinOutboundUnits.selector);
    harness.callCreate(m);

    m.minOutboundUnits = 1;
    harness.callCreate(m);

    vm.expectRevert(LibMarket.InvalidMinOutboundUnits.selector);
    harness.callSetMinOutboundUnits(m.id(), 0);
  }
}
