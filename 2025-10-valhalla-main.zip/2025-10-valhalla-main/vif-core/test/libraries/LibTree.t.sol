// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibTree} from "../../src/libraries/tree/LibTree.sol";
import {LibBit} from "../../src/libraries/LibBit.sol";
import {LibFlags} from "../../src/libraries/tree/LibFlags.sol";
import {LibSort} from "../../lib/solady/src/utils/LibSort.sol";
import {DynamicArrayLib} from "../../lib/solady/src/utils/DynamicArrayLib.sol";
import {ExtLoader} from "../../src/integrations/ExtLoader.sol";
import {LibTreeExt} from "../../src/libraries/external/LibTreeExt.sol";

contract LibTreeSubject is ExtLoader {
  using LibTree for *;
  using DynamicArrayLib for DynamicArrayLib.DynamicArray;

  function first(bytes32 marketId) external view returns (LibTree.Cursor memory, bool) {
    LibTree.Tree storage tree = marketId.treeFor();
    return LibTree.first(tree);
  }

  function next(LibTree.Cursor memory cursor, bytes32 marketId) external returns (bool, LibTree.Cursor memory) {
    LibTree.Tree storage tree = marketId.treeFor();
    bool found = LibTree.next(cursor, tree);
    return (found, cursor);
  }

  function flush(LibTree.Cursor memory cursor, bytes32 marketId) external {
    LibTree.Tree storage tree = marketId.treeFor();
    cursor.flush(tree);
  }

  function setIndexActive(bytes32 marketId, uint24 index) external {
    LibTree.Tree storage tree = marketId.treeFor();
    tree.setIndexActive(index);
  }

  function removeIndex(bytes32 marketId, uint24 index) external {
    LibTree.Tree storage tree = marketId.treeFor();
    tree.removeIndex(index);
  }

  function root(bytes32 marketId) external view returns (uint256) {
    LibTree.Tree storage tree = marketId.treeFor();
    return tree.root();
  }

  function level1(bytes32 marketId, uint8 rootIndex) external view returns (uint256) {
    LibTree.Tree storage tree = marketId.treeFor();
    return tree.level1(rootIndex);
  }

  function level2(bytes32 marketId, uint8 rootIndex, uint8 level1Index) external view returns (uint256) {
    LibTree.Tree storage tree = marketId.treeFor();
    return tree.level2(rootIndex, level1Index);
  }

  function setRoot(bytes32 marketId, uint256 _root) external {
    LibTree.Tree storage tree = marketId.treeFor();
    tree.setRoot(_root);
  }

  function setLevel1(bytes32 marketId, uint8 rootIndex, uint256 _level1) external {
    LibTree.Tree storage tree = marketId.treeFor();
    tree.setLevel1(rootIndex, _level1);
  }

  function setLevel2(bytes32 marketId, uint8 rootIndex, uint8 level1Index, uint256 _level2) external {
    LibTree.Tree storage tree = marketId.treeFor();
    tree.setLevel2(rootIndex, level1Index, _level2);
  }

  function allActive(bytes32 marketId) external view returns (uint24[] memory data) {
    DynamicArrayLib.DynamicArray memory indexes;
    LibTreeExt.Tree memory tree = LibTreeExt.treeFor(address(this), marketId);
    (LibTreeExt.Cursor memory cursor, bool found) = LibTreeExt.first(tree);
    while (found) {
      indexes.p(LibTreeExt.index(cursor));
      found = LibTreeExt.next(cursor, tree);
    }
    /// @solidity memory-safe-assembly
    assembly {
      data := mload(indexes)
    }
  }
}

contract LibTreeTest is Test {
  using LibTree for *;
  using LibBit for uint256;
  using LibFlags for uint256;

  LibTreeSubject public subject;

  function setUp() public {
    subject = new LibTreeSubject();
  }

  function testFuzz_index(uint24 index) public {
    uint8 rootIndex = uint8(index >> 16);
    uint8 level1Index = uint8((index >> 8) & 0xff);
    uint8 level2Index = uint8(index & 0xff);

    bytes32 marketId = keccak256("MARKET-1");

    subject.setIndexActive(marketId, index);

    uint256 root = subject.root(marketId);
    uint256 level1 = subject.level1(marketId, rootIndex);
    uint256 level2 = subject.level2(marketId, rootIndex, level1Index);

    assertEq(root.ctz(), rootIndex);
    assertEq(root.isActive(rootIndex), true);
    assertEq(root.flipBit(rootIndex), 0);

    assertEq(level1.ctz(), level1Index);
    assertEq(level1.isActive(level1Index), true);
    assertEq(level1.flipBit(level1Index), 0);

    assertEq(level2.ctz(), level2Index);
    assertEq(level2.isActive(level2Index), true);
    assertEq(level2.flipBit(level2Index), 0);
  }

  function testFuzz_setLevels(uint8 rootIndex, uint8 level1Index, uint256 root, uint256 level1, uint256 level2) public {
    bytes32 marketId = keccak256("MARKET-1");

    subject.setRoot(marketId, root);
    subject.setLevel1(marketId, rootIndex, level1);
    subject.setLevel2(marketId, rootIndex, level1Index, level2);

    assertEq(subject.root(marketId), root);
    assertEq(subject.level1(marketId, rootIndex), level1);
    assertEq(subject.level2(marketId, rootIndex, level1Index), level2);
  }

  function testFuzz_singleIndexTraversal(uint24 index) public {
    bytes32 marketId = keccak256("MARKET-1");

    (uint8 rootIndex, uint8 level1Index,) = uint256(index).indexes();

    subject.setIndexActive(marketId, index);

    uint256 root = subject.root(marketId);
    uint256 level1 = subject.level1(marketId, rootIndex);
    uint256 level2 = subject.level2(marketId, rootIndex, level1Index);

    (LibTree.Cursor memory cursor, bool found) = subject.first(marketId);
    assertEq(cursor.flags, index); // no dirty bits yet
    assertEq(cursor.index(), index);
    assertEq(found, true);

    assertEq(root, cursor.root);
    assertEq(level1, cursor.level1);
    assertEq(level2, cursor.level2);

    (bool rootDirty, bool level1Dirty, bool level2Dirty) = cursor.flags.dirtyIndexes();
    assertFalse(rootDirty);
    assertFalse(level1Dirty);
    assertFalse(level2Dirty);

    (found, cursor) = subject.next(cursor, marketId);

    assertFalse(found);
    assertEq(cursor.index(), index);

    (rootDirty, level1Dirty, level2Dirty) = cursor.flags.dirtyIndexes();
    root = subject.root(marketId);
    level1 = subject.level1(marketId, rootIndex);
    level2 = subject.level2(marketId, rootIndex, level1Index);

    assertTrue(rootDirty, "root not written to yet");
    assertFalse(level1Dirty, "level1 written to already");
    assertFalse(level2Dirty, "level2 written to already");

    assertNotEq(root, cursor.root);
    assertEq(root.flipBit(rootIndex), cursor.root);
    assertEq(level1, cursor.level1);
    assertEq(level2, cursor.level2);

    subject.flush(cursor, marketId);

    root = subject.root(marketId);
    level1 = subject.level1(marketId, rootIndex);
    level2 = subject.level2(marketId, rootIndex, level1Index);

    assertEq(root, cursor.root);
    assertEq(level1, cursor.level1);
    assertEq(level2, cursor.level2);
  }

  function testFuzz_removeIndexSingle(uint24 index) public {
    bytes32 marketId = keccak256("MARKET-1");

    subject.setIndexActive(marketId, index);

    (LibTree.Cursor memory cursor, bool found) = subject.first(marketId);

    assertTrue(found);
    assertEq(cursor.index(), index);

    subject.removeIndex(marketId, index);

    (, found) = subject.first(marketId);
    assertFalse(found);
  }

  function testFuzz_noClash(bytes32 marketId1, bytes32 marketId2, uint24 index1, uint24 index2) public {
    vm.assume(marketId1 != marketId2);

    subject.setIndexActive(marketId1, index1);
    subject.setIndexActive(marketId2, index2);

    (LibTree.Cursor memory cursor1, bool found1) = subject.first(marketId1);
    (LibTree.Cursor memory cursor2, bool found2) = subject.first(marketId2);

    assertTrue(found1);
    assertTrue(found2);
    assertEq(cursor1.index(), index1);
    assertEq(cursor2.index(), index2);
  }

  function _sortAndUniquify(uint24[] memory indices) internal pure {
    uint256[] memory indices256;
    /// @solidity memory-safe-assembly
    assembly {
      indices256 := indices
    }
    LibSort.sort(indices256);
    LibSort.uniquifySorted(indices256);
  }

  function _randomSubset(uint24[] memory indices, uint256 n) internal returns (uint24[] memory subsetSorted) {
    uint256[] memory indices256;
    /// @solidity memory-safe-assembly
    assembly {
      indices256 := indices
    }
    uint256[] memory subset = new uint256[](n);
    indices256 = vm.shuffle(indices256);
    for (uint256 i = 0; i < n; i++) {
      subset[i] = indices256[i];
    }
    LibSort.sort(subset);
    /// @solidity memory-safe-assembly
    assembly {
      subsetSorted := subset
    }
  }

  function _contains(uint24[] memory indices, uint24 index) internal pure returns (bool found) {
    uint256[] memory indices256;
    /// @solidity memory-safe-assembly
    assembly {
      indices256 := indices
    }
    (found,) = LibSort.searchSorted(indices256, index);
  }

  function testFuzz_createMany(uint24[] memory indices) public {
    bytes32 marketId = keccak256("MARKET-1");

    _sortAndUniquify(indices);

    for (uint256 i = 0; i < indices.length; i++) {
      subject.setIndexActive(marketId, indices[i]);
    }

    uint24[] memory allActive = subject.allActive(marketId);

    assertEq(allActive.length, indices.length);
    for (uint256 i = 0; i < indices.length; i++) {
      assertEq(allActive[i], indices[i]);
    }
  }

  function testFuzz_createAndRemoveMany(uint24[] memory indices, uint256 nRemove) public {
    bytes32 marketId = keccak256("MARKET-1");

    _sortAndUniquify(indices);

    for (uint256 i = 0; i < indices.length; i++) {
      subject.setIndexActive(marketId, indices[i]);
    }

    uint24[] memory allActive = subject.allActive(marketId);
    assertEq(allActive.length, indices.length);
    for (uint256 i = 0; i < indices.length; i++) {
      assertEq(allActive[i], indices[i]);
    }

    nRemove = bound(nRemove, 0, indices.length);

    uint24[] memory toRemove = _randomSubset(indices, nRemove);
    for (uint256 i = 0; i < toRemove.length; i++) {
      subject.removeIndex(marketId, toRemove[i]);
    }

    allActive = subject.allActive(marketId);
    assertEq(allActive.length, indices.length - nRemove);
    for (uint256 i = 0; i < indices.length; i++) {
      bool inActive = _contains(allActive, indices[i]);
      bool inToRemove = _contains(toRemove, indices[i]);
      assertTrue(inActive || inToRemove, "should be in active or to remove");
      assertFalse(inActive && inToRemove, "should not be in active and to remove");
    }
  }

  function test_removeIndexNotActive() public {
    bytes32 marketId = keccak256("MARKET-1");
    uint256 index = 100;
    subject.removeIndex(marketId, uint24(index));

    (uint8 rootIndex, uint8 level1Index,) = index.indexes();
    assertEq(subject.root(marketId), 0);
    assertEq(subject.level1(marketId, rootIndex), 0);
    assertEq(subject.level2(marketId, rootIndex, level1Index), 0);
  }
}
