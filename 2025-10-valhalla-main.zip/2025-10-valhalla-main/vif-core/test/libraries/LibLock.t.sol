// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibLock} from "../../src/libraries/LibLock.sol";

contract LibLockSubject {
  using LibLock for *;

  function lock() external {
    LibLock.lock();
  }

  function unlock() external {
    LibLock.unlock();
  }

  function checkLocked() external view {
    LibLock.checkLocked();
  }
}

contract LibLockTest is Test {
  using LibLock for *;

  LibLockSubject internal subject;

  function setUp() public {
    subject = new LibLockSubject();
  }

  function test_lock_unlock() public {
    subject.lock();
    subject.unlock();
  }

  function test_checkLocked() public {
    subject.lock();
    subject.checkLocked();
    subject.unlock();

    vm.expectRevert(LibLock.NotLocked.selector);
    subject.checkLocked();
  }

  function test_relock() public {
    subject.lock();
    vm.expectRevert(LibLock.Locked.selector);
    subject.lock();
  }

  function test_unlock_when_not_locked() public {
    vm.expectRevert(LibLock.NotLocked.selector);
    subject.unlock();
  }
}
