// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibPausableExt} from "../../../src/libraries/external/LibPausableExt.sol";
import {LibPausable} from "../../../src/libraries/LibPausable.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibPausableSubject is ExtLoader {
  using LibPausable for *;

  function setPaused(bool paused) external {
    LibPausable.setPaused(paused);
  }

  function checkNotPaused() external view {
    LibPausable.checkNotPaused();
  }
}

contract LibPausableExtTest is Test {
  using LibPausableExt for *;

  LibPausableSubject internal subject;

  function setUp() public {
    subject = new LibPausableSubject();
  }

  function test_isNotPaused() public view {
    subject.checkNotPaused();
    assertFalse(address(subject).isPaused());
  }

  function test_isPaused() public {
    subject.setPaused(true);
    vm.expectRevert(LibPausable.Paused.selector);
    subject.checkNotPaused();
    assertTrue(address(subject).isPaused());
  }
}
