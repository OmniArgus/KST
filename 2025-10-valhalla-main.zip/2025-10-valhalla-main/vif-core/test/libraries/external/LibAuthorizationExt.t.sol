// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibAuthorizationExt} from "../../../src/libraries/external/LibAuthorizationExt.sol";
import {LibAuthorization} from "../../../src/libraries/LibAuthorization.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibAuthSubject is ExtLoader {
  using LibAuthorization for *;

  function authorize(address _authorizer, address _authorized, bool value) external {
    LibAuthorization.setAuthorized(_authorizer, _authorized, value);
  }

  function authorized(address _authorizer, address _authorized) external view returns (bool) {
    return LibAuthorization.authorized(_authorizer, _authorized);
  }

  function validateNonce(address _authorizer, uint256 _nonce) external {
    LibAuthorization.validateNonce(_authorizer, _nonce);
  }
}

contract LibAuthorizationExtTest is Test {
  using LibAuthorizationExt for *;

  LibAuthSubject public subject;

  function setUp() public {
    subject = new LibAuthSubject();
  }

  function authorizerInvariants(address _authorizer, address _authorized) public view {
    assertEq(address(subject).authorized(_authorizer, _authorized), subject.authorized(_authorizer, _authorized));
  }

  function testFuzz_authorize(address _authorizer, address _authorized, bool _value) public {
    subject.authorize(_authorizer, _authorized, _value);
    authorizerInvariants(_authorizer, _authorized);
    assertEq(address(subject).authorized(_authorizer, _authorized), _value);
  }

  function testFuzz_validateNonce(address _authorizer, uint256 _nonce) public {
    vm.record();
    subject.validateNonce(_authorizer, 0);
    (, bytes32[] memory writeSlots) = vm.accesses(address(subject));
    assertEq(writeSlots.length, 1, "should write 1 slot only");
    bytes32 slot = writeSlots[0];
    vm.store(address(subject), slot, bytes32(_nonce));

    assertEq(address(subject).authorizerNonce(_authorizer), _nonce);
  }
}
