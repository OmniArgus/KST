// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibOfferListExt} from "../../../src/libraries/external/LibOfferListExt.sol";
import {LibOfferList, OfferListUnpacked} from "../../../src/libraries/LibOfferList.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibOfferListSubject is ExtLoader {
  using LibOfferList for *;

  function offerList(bytes32 market, uint24 index) external view returns (uint256) {
    return LibOfferList.offerList(market, index);
  }

  function setOfferList(bytes32 market, uint24 index, uint256 _offerList) external {
    LibOfferList.setOfferList(market, index, _offerList);
  }
}

contract LibOfferListTest is Test {
  using LibOfferListExt for *;
  using LibOfferList for *;

  LibOfferListSubject internal subject;

  function setUp() public {
    subject = new LibOfferListSubject();
  }

  function testFuzz_offerList(bytes32 market, uint24 index, uint256 offerList) public {
    subject.setOfferList(market, index, offerList);
    assertEq(subject.offerList(market, index), offerList);
    assertEq(address(subject).offerListPacked(market, index), offerList);
  }

  function testFuzz_offerListUnpacked(
    bytes32 market,
    uint24 index,
    uint40 head,
    uint40 tail,
    uint40 offerCount,
    uint64 totalGives
  ) public {
    OfferListUnpacked memory offerList =
      OfferListUnpacked({head: head, tail: tail, offerCount: offerCount, totalGives: totalGives, index: index});
    subject.setOfferList(market, index, offerList.pack());
    OfferListUnpacked memory unpacked = address(subject).offerList(market, index);
    assertEq(unpacked.index, index, "index");
    assertEq(unpacked.head, head, "head");
    assertEq(unpacked.tail, tail, "tail");
    assertEq(unpacked.offerCount, offerCount, "offerCount");
    assertEq(unpacked.totalGives, totalGives, "totalGives");
  }
}
