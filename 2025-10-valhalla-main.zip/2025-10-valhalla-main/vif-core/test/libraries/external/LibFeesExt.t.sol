// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibFeesExt} from "../../../src/libraries/external/LibFeesExt.sol";
import {LibFees} from "../../../src/libraries/LibFees.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibFeesSubject is ExtLoader {
  using LibFees for *;

  function addFees(address token, uint256 fees) external {
    LibFees.addFees(token, fees);
  }

  function claimFees(address token, uint256 amount) external {
    LibFees.claimFees(token, amount);
  }
}

contract LibFeesExtTest is Test {
  using LibFeesExt for *;

  LibFeesSubject internal subject;

  function setUp() public {
    subject = new LibFeesSubject();
  }

  function testFuzz_addFees(address token, uint256 fees) public {
    subject.addFees(token, fees);
    assertEq(address(subject).fees(token), fees);
  }

  function testFuzz_claimFees(address token, uint256 amount, uint256 claim) public {
    claim = bound(claim, 0, amount);
    subject.addFees(token, amount);
    assertEq(address(subject).fees(token), amount);

    subject.claimFees(token, claim);
    assertEq(address(subject).fees(token), amount - claim);
  }
}
