// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibProvisionExt} from "../../../src/libraries/external/LibProvisionExt.sol";
import {LibProvision} from "../../../src/libraries/LibProvision.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibProvisionSubject is ExtLoader {
  using LibProvision for *;

  function provision() external view returns (uint24) {
    return LibProvision.provision();
  }

  function setProvision(uint24 _provision) external {
    _provision.setProvision();
  }
}

contract LibProvisionExtTest is Test {
  using LibProvisionExt for *;
  using LibProvision for *;

  LibProvisionSubject internal subject;

  function setUp() public {
    subject = new LibProvisionSubject();
  }

  function testFuzz_provision(uint24 _provision) public {
    vm.assume(_provision <= 0x7fffff);

    subject.setProvision(_provision);
    assertEq(address(subject).provision(), _provision);
  }
}
