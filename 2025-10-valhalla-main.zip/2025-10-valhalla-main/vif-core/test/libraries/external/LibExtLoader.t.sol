// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibExtLoader} from "../../../src/libraries/external/LibExtLoader.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibExtLoaderSubject is ExtLoader {
  using LibExtLoader for *;

  function tstore(uint256 slot, uint256 value) external {
    /// @solidity memory-safe-assembly
    assembly {
      tstore(slot, value)
    }
  }
}

contract LibExtLoaderTest is Test {
  using LibExtLoader for *;

  LibExtLoaderSubject internal subject;

  function setUp() public {
    subject = new LibExtLoaderSubject();
  }

  function testFuzz_tload(uint256 slot, uint256 value) public {
    subject.tstore(slot, value);
    assertEq(address(subject).tload(slot), value);
  }

  function testFuzz_sload(uint256 slot, uint256 value) public {
    vm.store(address(subject), bytes32(slot), bytes32(value));
    assertEq(address(subject).sload(slot), value);
  }
}
