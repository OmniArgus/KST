// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibMarketExt} from "../../../src/libraries/external/LibMarketExt.sol";
import {LibMarket, Market} from "../../../src/libraries/LibMarket.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibMarketSubject is ExtLoader {
  using LibMarket for *;

  function market(bytes32 marketId) external view returns (Market memory) {
    return marketId.market();
  }

  function createMarket(Market memory _market) external returns (bytes32) {
    return _market.create();
  }

  function setActive(bytes32 marketId, bool active) external {
    marketId.setActive(active);
  }
}

contract LibMarketExtTest is Test {
  using LibMarketExt for *;

  LibMarketSubject internal subject;

  function setUp() public {
    subject = new LibMarketSubject();
  }

  function testFuzz_createMarket(
    address outboundToken,
    uint64 outboundUnits,
    uint32 minOutboundUnits,
    address inboundToken,
    uint64 inboundUnits,
    uint16 fees,
    uint16 tickSpacing,
    bool active
  ) public {
    vm.assume(outboundUnits > 0 && inboundUnits > 0);
    vm.assume(tickSpacing > 0);
    vm.assume(minOutboundUnits & 0x7fffffff == minOutboundUnits);
    vm.assume(minOutboundUnits > 0);

    Market memory market = Market({
      outboundToken: outboundToken,
      outboundUnits: outboundUnits,
      minOutboundUnits: minOutboundUnits,
      inboundToken: inboundToken,
      inboundUnits: inboundUnits,
      tickSpacing: tickSpacing,
      fees: fees,
      active: active
    });

    bytes32 marketId = subject.createMarket(market);

    if (!active) {
      subject.setActive(marketId, false);
    }

    market = address(subject).market(marketId);

    assertEq(market.outboundToken, outboundToken);
    assertEq(market.outboundUnits, outboundUnits);
    assertEq(market.minOutboundUnits, minOutboundUnits);
    assertEq(market.inboundToken, inboundToken);
    assertEq(market.inboundUnits, inboundUnits);
    assertEq(market.fees, fees);
    assertEq(market.active, active);
  }
}
