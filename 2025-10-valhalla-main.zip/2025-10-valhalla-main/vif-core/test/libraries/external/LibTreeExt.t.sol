// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibTreeExt} from "../../../src/libraries/external/LibTreeExt.sol";
import {LibTree} from "../../../src/libraries/tree/LibTree.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";
import {DynamicArrayLib} from "../../../lib/solady/src/utils/DynamicArrayLib.sol";
import {LibSort} from "../../../lib/solady/src/utils/LibSort.sol";

contract LibTreeSubject is ExtLoader {
  using LibTree for *;
  using DynamicArrayLib for DynamicArrayLib.DynamicArray;

  function setIndexActive(bytes32 marketId, uint24[] memory indicesSorted) external {
    LibTree.Tree storage tree = marketId.treeFor();

    for (uint256 i = 0; i < indicesSorted.length; i++) {
      tree.setIndexActive(indicesSorted[i]);
    }
  }
}

contract LibTreeExtTest is Test {
  using LibTreeExt for *;
  using LibTree for *;
  using DynamicArrayLib for DynamicArrayLib.DynamicArray;

  LibTreeSubject internal subject;

  function setUp() public {
    subject = new LibTreeSubject();
  }

  function _sortAndUniquify(uint24[] memory indices) internal pure {
    uint256[] memory indices256;
    /// @solidity memory-safe-assembly
    assembly {
      indices256 := indices
    }
    LibSort.sort(indices256);
    LibSort.uniquifySorted(indices256);
  }

  function _allActive(bytes32 marketId) internal view returns (uint256[] memory actives) {
    LibTreeExt.Tree memory tree = address(subject).treeFor(marketId);
    (LibTreeExt.Cursor memory cursor, bool found) = tree.first();
    DynamicArrayLib.DynamicArray memory indexes;
    while (found) {
      indexes.p(cursor.index());
      found = cursor.next(tree);
    }
    actives = indexes.data;
  }

  function _allActiveFromIndex(bytes32 marketId, uint24 index) internal view returns (uint256[] memory actives) {
    LibTreeExt.Tree memory tree = address(subject).treeFor(marketId);
    (LibTreeExt.Cursor memory cursor, bool found) = tree.firstAfter(index);
    DynamicArrayLib.DynamicArray memory indexes;
    while (found) {
      indexes.p(cursor.index());
      found = cursor.next(tree);
    }
    actives = indexes.data;
  }

  function testFuzz_setIndexActive(bytes32 marketId, uint24[] memory indices) public {
    _sortAndUniquify(indices);
    subject.setIndexActive(marketId, indices);
    uint256[] memory indices256;
    /// @solidity memory-safe-assembly
    assembly {
      indices256 := indices
    }
    uint256[] memory fromLibrary = _allActive(marketId);
    assertEq(fromLibrary, indices256);
  }

  function testFuzz_firstAfter(bytes32 marketId, uint24[] memory indices, uint256 indexOfIndex) public {
    vm.assume(indices.length > 0);

    _sortAndUniquify(indices);
    indexOfIndex = bound(indexOfIndex, 0, indices.length - 1);
    uint24 index = indices[indexOfIndex];

    subject.setIndexActive(marketId, indices);

    uint256[] memory fromContract;
    /// @solidity memory-safe-assembly
    assembly {
      fromContract := indices
    }
    fromContract = DynamicArrayLib.slice(fromContract, indexOfIndex);

    uint256[] memory fromLibrary = _allActiveFromIndex(marketId, index);

    assertEq(fromContract, fromLibrary);
  }

  struct FirstAfterTestCase {
    uint24[] ids;
    uint24 from;
    uint256[] expected;
  }

  function fixtureCases() public pure returns (FirstAfterTestCase[] memory cases) {
    cases = new FirstAfterTestCase[](4);

    // fist case, empty everything
    cases[0] = FirstAfterTestCase({ids: new uint24[](0), from: 0, expected: new uint256[](0)});

    // second case, one index below from
    cases[1] = FirstAfterTestCase({ids: new uint24[](1), from: 10, expected: new uint256[](0)});
    cases[1].ids[0] = 9;

    // third case, multiple indexes below and above from excluding from
    cases[2] = FirstAfterTestCase({ids: new uint24[](3), from: 10, expected: new uint256[](2)});
    cases[2].ids[0] = 9;
    cases[2].ids[1] = 11;
    cases[2].ids[2] = 12;
    cases[2].expected[0] = 11;
    cases[2].expected[1] = 12;

    // fourth case, multiple indexes below and above from including from
    cases[3] = FirstAfterTestCase({ids: new uint24[](3), from: 10, expected: new uint256[](2)});
    cases[3].ids[0] = 9;
    cases[3].ids[1] = 10;
    cases[3].ids[2] = 11;
    cases[3].expected[0] = 10;
    cases[3].expected[1] = 11;
  }

  function tableFirstAfter(FirstAfterTestCase memory cases) public {
    bytes32 marketId = keccak256("MARKET-1");
    subject.setIndexActive(marketId, cases.ids);

    uint256[] memory fromLibrary = _allActiveFromIndex(marketId, cases.from);

    assertEq(fromLibrary, cases.expected);
  }
}
