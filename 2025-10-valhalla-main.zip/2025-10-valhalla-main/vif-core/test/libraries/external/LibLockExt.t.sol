// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibLockExt} from "../../../src/libraries/external/LibLockExt.sol";
import {LibLock} from "../../../src/libraries/LibLock.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibLockSubject is ExtLoader {
  using LibLock for *;

  function lock() external {
    LibLock.lock();
  }

  function unlock() external {
    LibLock.unlock();
  }

  function checkLocked() external view {
    LibLock.checkLocked();
  }
}

contract LibLockExtTest is Test {
  using LibLockExt for *;

  LibLockSubject internal subject;

  function setUp() public {
    subject = new LibLockSubject();
  }

  function test_locked() public {
    subject.lock();
    assertTrue(address(subject).isLocked());
    subject.checkLocked();
  }

  function test_not_locked() public {
    assertFalse(address(subject).isLocked());
    vm.expectRevert(LibLock.NotLocked.selector);
    subject.checkLocked();
  }

  function test_unlock() public {
    subject.lock();
    assertTrue(address(subject).isLocked());
    subject.checkLocked();
    subject.unlock();
    assertFalse(address(subject).isLocked());
    vm.expectRevert(LibLock.NotLocked.selector);
    subject.checkLocked();
  }
}
