// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibDeltasExt} from "../../../src/libraries/external/LibDeltasExt.sol";
import {LibDeltas} from "../../../src/libraries/LibDeltas.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibDeltasSubject is ExtLoader {
  using LibDeltas for *;

  function applyDelta(address token, int256 delta) external {
    LibDeltas.applyDelta(token, delta);
  }

  function ensureSettled() external view {
    LibDeltas.ensureSettled();
  }
}

contract LibDeltasExtTest is Test {
  using LibDeltasExt for *;

  LibDeltasSubject internal subject;

  function setUp() public {
    subject = new LibDeltasSubject();
  }

  function testFuzz_applyDelta(address token, int256 delta) public {
    subject.applyDelta(token, delta);
    assertEq(address(subject).deltaOf(token), delta);
  }

  function _settledTest(bool settled) internal {
    if (settled) {
      subject.ensureSettled();
      assertEq(address(subject).deltasCount(), 0);
    } else {
      subject.applyDelta(address(1), 1);
      assertEq(address(subject).deltasCount(), 1);
      vm.expectRevert(LibDeltas.DeltasNotSettled.selector);
      subject.ensureSettled();
    }
  }

  function test_settled() public {
    _settledTest(true);
    _settledTest(false);
  }

  function testFuzz_deltasCount(uint256 deltas) public {
    deltas = bound(deltas, 0, 100);
    for (uint160 i = 0; i < deltas; i++) {
      subject.applyDelta(address(i), 1);
    }
    assertEq(address(subject).deltasCount(), deltas);
  }
}
