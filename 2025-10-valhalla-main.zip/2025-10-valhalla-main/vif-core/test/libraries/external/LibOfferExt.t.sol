// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibOfferExt} from "../../../src/libraries/external/LibOfferExt.sol";
import {LibOffer, OfferUnpacked} from "../../../src/libraries/LibOffer.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibOfferSubject is ExtLoader {
  using LibOffer for *;

  function offer(bytes32 marketId, uint40 offerId) external view returns (uint256) {
    return LibOffer.offer(marketId, offerId);
  }

  function offerOwner(bytes32 marketId, uint40 offerId) external view returns (address) {
    return LibOffer.offerOwner(marketId, offerId);
  }

  function setOffer(bytes32 marketId, uint40 offerId, uint256 _offer) external {
    LibOffer.setOffer(marketId, offerId, _offer);
  }

  function setOfferOwner(bytes32 marketId, uint40 offerId, address owner) external {
    LibOffer.setOfferOwner(marketId, offerId, owner);
  }
}

contract LibOfferExtTest is Test {
  using LibOfferExt for *;
  using LibOffer for *;

  LibOfferSubject internal subject;

  function setUp() public {
    subject = new LibOfferSubject();
  }

  function testFuzz_offerOwner(bytes32 marketId, uint40 offerId, address owner) public {
    subject.setOfferOwner(marketId, offerId, owner);
    assertEq(address(subject).offerOwner(marketId, offerId), owner);
  }

  function testFuzz_offerPacked(bytes32 marketId, uint40 offerId, uint256 offer) public {
    subject.setOffer(marketId, offerId, offer);
    assertEq(address(subject).offerPacked(marketId, offerId), offer);
  }

  function testFuzz_offer(
    bytes32 marketId,
    uint40 offerId,
    uint40 prev,
    uint40 next,
    uint32 expiry,
    uint48 gives,
    uint48 received,
    int24 tick,
    uint24 provision,
    bool isActive
  ) public {
    provision = uint24(bound(provision, 0, 0x7fffff));
    OfferUnpacked memory offer = OfferUnpacked({
      prev: prev,
      next: next,
      expiry: expiry,
      gives: gives,
      received: received,
      tick: tick,
      provision: provision,
      isActive: isActive
    });

    subject.setOffer(marketId, offerId, offer.pack());

    offer = address(subject).offer(marketId, offerId);

    assertEq(offer.prev, prev);
    assertEq(offer.next, next);
    assertEq(offer.expiry, expiry);
    assertEq(offer.gives, gives);
    assertEq(offer.received, received);
    assertEq(offer.tick, tick);
    assertEq(offer.provision, provision);
    assertEq(offer.isActive, isActive);
  }
}
