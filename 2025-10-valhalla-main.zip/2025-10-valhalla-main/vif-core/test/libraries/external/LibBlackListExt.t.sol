// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibBlackListExt} from "../../../src/libraries/external/LibBlackListExt.sol";
import {LibBlackList} from "../../../src/libraries/LibBlackList.sol";
import {ExtLoader} from "../../../src/integrations/ExtLoader.sol";

contract LibBlackListSubject is ExtLoader {
  using LibBlackList for *;

  function setBlacklisted(address user, bool value) external {
    LibBlackList.setBlacklisted(user, value);
  }

  function checkNotBlacklisted(address user) external view {
    LibBlackList.checkNotBlacklisted(user);
  }
}

contract LibBlackListExtTest is Test {
  using LibBlackListExt for *;

  LibBlackListSubject internal subject;

  function setUp() public {
    subject = new LibBlackListSubject();
  }

  function testFuzz_isBlacklisted(address user, bool value) public {
    subject.setBlacklisted(user, value);
    assertEq(address(subject).isBlacklisted(user), value);

    if (value) vm.expectRevert(LibBlackList.Blacklisted.selector);
    subject.checkNotBlacklisted(user);
  }
}
