// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibAuthorization} from "../../src/libraries/LibAuthorization.sol";
import {LibAuthorizationExt} from "../../src/libraries/external/LibAuthorizationExt.sol";

contract LibAuthorizationHarness {
  using LibAuthorization for address;

  function callAuthorized(address authorizer, address authorized) external view returns (bool) {
    return LibAuthorization.authorized(authorizer, authorized);
  }

  function callCheckAuthorization(address authorizer, address authorized) external view {
    LibAuthorization.checkAuthorization(authorizer, authorized);
  }

  function callValidateNonce(address authorizer, uint256 nonce) external {
    LibAuthorization.validateNonce(authorizer, nonce);
  }

  function callSetAuthorized(address authorizer, address authorized, bool value) external {
    LibAuthorization.setAuthorized(authorizer, authorized, value);
  }

  function extsload(bytes32 slot) external view returns (uint256 result) {
    /// @solidity memory-safe-assembly
    assembly {
      result := sload(slot)
    }
  }
}

contract LibAuthorizationTest is Test {
  using LibAuthorizationExt for address;

  LibAuthorizationHarness internal harness;
  address internal alice = address(0xA11CE);
  address internal bob = address(0xB0B);
  address internal carol = address(0xCAFE);

  function setUp() public {
    harness = new LibAuthorizationHarness();
  }

  function test_setAuthorized_and_authorized_read() public {
    assertFalse(harness.callAuthorized(alice, bob));
    assertFalse(address(harness).authorized(alice, bob));

    // Set authorization and check event
    vm.expectEmit(true, true, false, true);
    emit LibAuthorization.Authorized(alice, bob, true);

    harness.callSetAuthorized(alice, bob, true);

    assertTrue(harness.callAuthorized(alice, bob));
    assertTrue(address(harness).authorized(alice, bob));

    // Unset and verify
    vm.expectEmit(true, true, false, true);
    emit LibAuthorization.Authorized(alice, bob, false);
    harness.callSetAuthorized(alice, bob, false);
    assertFalse(harness.callAuthorized(alice, bob));
    assertFalse(address(harness).authorized(alice, bob));
  }

  function test_checkAuthorization_self_always_ok() public view {
    // When authorizer == authorized, should not read storage or revert
    LibAuthorization.checkAuthorization(alice, alice);
  }

  function test_checkAuthorization_reverts_when_not_authorized() public {
    vm.expectRevert(LibAuthorization.NotAuthorized.selector);
    harness.callCheckAuthorization(alice, bob);
    assertFalse(address(harness).authorized(alice, bob));
  }

  function test_checkAuthorization_succeeds_when_authorized() public {
    harness.callSetAuthorized(alice, bob, true);
    harness.callCheckAuthorization(alice, bob);
    assertTrue(address(harness).authorized(alice, bob));
  }

  function test_validateNonce_increments_and_emits() public {
    // First call expects nonce 0
    vm.expectEmit(true, false, false, true);
    emit LibAuthorization.NonceIncremented(alice, 1);
    harness.callValidateNonce(alice, 0);
    assertEq(address(harness).authorizerNonce(alice), 1);

    // Second call expects nonce 1
    vm.expectEmit(true, false, false, true);
    emit LibAuthorization.NonceIncremented(alice, 2);
    harness.callValidateNonce(alice, 1);
    assertEq(address(harness).authorizerNonce(alice), 2);
  }

  function test_validateNonce_reverts_on_wrong_nonce() public {
    // Wrong first nonce
    vm.expectRevert(LibAuthorization.InvalidNonce.selector);
    harness.callValidateNonce(alice, 1);
    assertEq(address(harness).authorizerNonce(alice), 0);

    // Correct first, then wrong second
    harness.callValidateNonce(alice, 0);
    assertEq(address(harness).authorizerNonce(alice), 1);

    vm.expectRevert(LibAuthorization.InvalidNonce.selector);
    harness.callValidateNonce(alice, 0);
    assertEq(address(harness).authorizerNonce(alice), 1);
  }

  function test_slotsShouldBeDifferent() public {
    address authorizer = address(0xdeadbeef);
    address notAuthorizer = address(0x123);
    address authorized = address(0x123);

    assertFalse(harness.callAuthorized(authorizer, authorized));
    assertFalse(harness.callAuthorized(notAuthorizer, authorized));

    harness.callSetAuthorized(authorizer, authorized, true);
    assertTrue(harness.callAuthorized(authorizer, authorized));
    assertFalse(harness.callAuthorized(notAuthorizer, authorized));

    assertTrue(address(harness).authorized(authorizer, authorized));
    assertFalse(address(harness).authorized(notAuthorizer, authorized));
  }
}
