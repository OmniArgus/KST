// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibProvision} from "../../src/libraries/LibProvision.sol";

contract LibProvisionSubject {
  using LibProvision for *;

  function provision() external view returns (uint24) {
    return LibProvision.provision();
  }

  function setProvision(uint24 _provision) external {
    LibProvision.setProvision(_provision);
  }

  function floor(uint24 _provision) external view returns (uint24) {
    return LibProvision.floor(_provision);
  }

  function ceil(uint24 _provision) external view returns (uint24) {
    return LibProvision.ceil(_provision);
  }

  function checkProvision(uint24 _provision) external pure {
    LibProvision.checkProvision(_provision);
  }
}

contract LibProvisionTest is Test {
  using LibProvision for *;

  LibProvisionSubject internal subject;

  function setUp() public {
    subject = new LibProvisionSubject();
  }

  function testFuzz_setProvision(uint24 _provision) public {
    vm.assume(_provision <= 0x7fffff);

    vm.expectEmit(true, true, true, true);
    emit LibProvision.SetProvision(_provision);
    subject.setProvision(_provision);

    assertEq(subject.provision(), _provision);
  }

  function test_checkProvision() public {
    // should not revert
    subject.checkProvision(0x7fffff);

    vm.expectRevert(LibProvision.ProvisionTooLarge.selector);
    subject.checkProvision(0x800000);
  }

  function testFuzz_floor(uint24 _globalProvision, uint24 _provision) public {
    vm.assume(_globalProvision <= 0x7fffff);
    vm.assume(_provision <= 0x7fffff);

    vm.expectEmit(true, true, true, true);
    emit LibProvision.SetProvision(_globalProvision);
    subject.setProvision(_globalProvision);

    uint24 result = subject.floor(_provision);
    // should be the max of both
    assertEq(_globalProvision > _provision ? _globalProvision : _provision, result);
  }

  function testFuzz_ceil(uint24 _globalProvision, uint24 _provision) public {
    vm.assume(_globalProvision <= 0x7fffff);
    vm.assume(_provision <= 0x7fffff);

    vm.expectEmit(true, true, true, true);
    emit LibProvision.SetProvision(_globalProvision);
    subject.setProvision(_globalProvision);

    uint24 result = subject.ceil(_provision);
    // should be the min of both
    assertEq(_globalProvision < _provision ? _globalProvision : _provision, result);
  }

  function testFuzz_setProvisionTooLarge(uint24 _provision) public {
    _provision = uint24(bound(_provision, 0x7fffff + 1, type(uint24).max));

    vm.expectRevert(LibProvision.ProvisionTooLarge.selector);
    subject.setProvision(_provision);
  }
}
