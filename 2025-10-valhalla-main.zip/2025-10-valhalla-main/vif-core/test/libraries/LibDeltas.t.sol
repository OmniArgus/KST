// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibDeltas} from "../../src/libraries/LibDeltas.sol";
import {LibDeltasExt} from "../../src/libraries/external/LibDeltasExt.sol";

contract DeltasSubject {
  using LibDeltas for *;

  function mutate(address token, int256 delta) external {
    LibDeltas.applyDelta(token, delta);
  }

  function settle() external view {
    LibDeltas.ensureSettled();
  }

  function exttload(bytes32 slot) external view returns (bytes32 value) {
    /// @solidity memory-safe-assembly
    assembly {
      value := tload(slot)
    }
  }

  function extsload(bytes32 slot) external view returns (bytes32 value) {
    /// @solidity memory-safe-assembly
    assembly {
      value := sload(slot)
    }
  }

  function exttstore(uint256 slot, uint256 value) external {
    /// @solidity memory-safe-assembly
    assembly {
      tstore(slot, value)
    }
  }
}

contract LibDeltasTest is Test {
  DeltasSubject internal subject;
  address internal tokenA = address(0xA);
  address internal tokenB = address(0xB);

  uint256 private constant DELTAS_SLOT = 0xcc263e4ff5555355de7add1bddab8dc0ce9bc67601caa5513579ca11cb397905;

  function setUp() public {
    subject = new DeltasSubject();
  }

  function _count() internal view returns (uint256) {
    return LibDeltasExt.deltasCount(address(subject));
  }

  function _delta(address token) internal view returns (int256) {
    return LibDeltasExt.deltaOf(address(subject), token);
  }

  function test_initially_settled_and_zero() public view {
    subject.settle();
  }

  function test_applyDelta_increments_count_and_read_value() public {
    assertEq(_count(), 0);
    assertEq(_delta(tokenA), 0);

    subject.mutate(tokenA, int256(5));

    assertEq(_count(), 1);
    assertEq(_delta(tokenA), 5);

    vm.expectRevert(LibDeltas.DeltasNotSettled.selector);
    subject.settle();
  }

  function test_zero_crossing_decrements_count_and_settle_ok() public {
    subject.mutate(tokenA, int256(5));
    assertEq(_count(), 1);

    subject.mutate(tokenA, int256(-5));
    assertEq(_count(), 0);
    assertEq(_delta(tokenA), 0);

    subject.settle();
  }

  function test_multi_token_counting_and_removals() public {
    assertEq(_count(), 0);

    subject.mutate(tokenA, int256(1));
    assertEq(_count(), 1);

    subject.mutate(tokenB, int256(2));
    assertEq(_count(), 2);

    subject.mutate(tokenA, int256(-1));
    assertEq(_count(), 1);
    assertEq(_delta(tokenA), 0);
    assertEq(_delta(tokenB), 2);

    subject.mutate(tokenB, int256(-2));
    assertEq(_count(), 0);

    subject.settle();
  }

  function test_adjust_without_crossing_zero_keeps_count() public {
    subject.mutate(tokenA, int256(10));
    assertEq(_count(), 1);

    subject.mutate(tokenA, int256(-3)); // still positive
    assertEq(_count(), 1);
    assertEq(_delta(tokenA), 7);
  }

  function test_negative_delta_reading() public {
    subject.mutate(tokenA, int256(-3));
    assertEq(_count(), 1);
    assertEq(_delta(tokenA), -3);
  }

  function test_overflow_positive_delta() public {
    subject.mutate(tokenA, int256(type(int256).max));
    assertEq(_count(), 1);
    assertEq(_delta(tokenA), type(int256).max);

    vm.expectRevert(LibDeltas.DeltaOverflow.selector);
    subject.mutate(tokenA, int256(1));

    assertEq(_count(), 1);
    assertEq(_delta(tokenA), type(int256).max);
  }

  function test_overflow_negative_delta() public {
    subject.mutate(tokenA, int256(type(int256).min));
    assertEq(_count(), 1);
    assertEq(_delta(tokenA), type(int256).min);

    vm.expectRevert(LibDeltas.DeltaOverflow.selector);
    subject.mutate(tokenA, int256(-1));

    assertEq(_count(), 1);
    assertEq(_delta(tokenA), type(int256).min);
  }

  function test_overflow_deltas_count() public {
    subject.exttstore(DELTAS_SLOT, type(uint256).max);
    assertEq(_count(), type(uint256).max);

    vm.expectRevert(LibDeltas.DeltaOverflow.selector);
    subject.mutate(tokenA, int256(1));

    assertEq(_count(), type(uint256).max);
    assertEq(_delta(tokenA), 0);
  }
}
