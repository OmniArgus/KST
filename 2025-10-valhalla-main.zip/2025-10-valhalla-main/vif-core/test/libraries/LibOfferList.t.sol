// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibOfferList, OfferListUnpacked} from "../../src/libraries/LibOfferList.sol";
import {OfferUnpacked, LibOffer} from "../../src/libraries/LibOffer.sol";
import {LibTick} from "../../src/libraries/LibTick.sol";
import {LibTree} from "../../src/libraries/tree/LibTree.sol";
import {LibTreeExt} from "../../src/libraries/external/LibTreeExt.sol";
import {ExtLoader} from "../../src/integrations/ExtLoader.sol";
import {DynamicArrayLib} from "lib/solady/src/utils/DynamicArrayLib.sol";

contract LibOfferListSubject is ExtLoader {
  using LibOfferList for *;
  using LibOffer for *;
  using LibTick for *;
  using LibTree for *;
  using DynamicArrayLib for *;

  function nextOfferId(bytes32 market) external returns (uint40) {
    return LibOffer.nextOfferId(market);
  }

  function offer(bytes32 market, uint40 offerId) external view returns (uint256) {
    return LibOffer.offer(market, offerId);
  }

  function offerList(bytes32 market, uint24 index) external view returns (uint256) {
    return LibOfferList.offerList(market, index);
  }

  function setOfferList(bytes32 market, uint24 index, uint256 _offerList) external {
    LibOfferList.setOfferList(market, index, _offerList);
  }

  function insert(bytes32 market, uint24 index, uint40 offerId, uint48 gives) external returns (uint40) {
    OfferUnpacked memory _offer;

    _offer.from(market.offer(offerId));
    _offer.gives = gives;
    if (_offer.isActive) revert("Offer is already active");

    _offer.tick = index.tick(1);
    _offer.isActive = true;

    _offer.prev = LibOfferList.insert(market, index, offerId, gives);
    market.setOffer(offerId, _offer.pack());
    return _offer.prev;
  }

  function unlink(bytes32 market, uint40 offerId) external {
    OfferUnpacked memory _offer;
    _offer.from(market.offer(offerId));

    LibOfferList.unlink(market, 1, _offer);
    market.setOffer(offerId, _offer.pack());
  }

  function allActive(bytes32 market) external view returns (uint256[] memory) {
    DynamicArrayLib.DynamicArray memory indexes;
    LibTreeExt.Tree memory tree = LibTreeExt.treeFor(address(this), market);
    (LibTreeExt.Cursor memory c, bool found) = LibTreeExt.first(tree);
    while (found) {
      indexes.p(LibTreeExt.index(c));
      found = LibTreeExt.next(c, tree);
    }
    return indexes.data;
  }

  function allOffers(bytes32 market, uint24 index) external view returns (uint256[] memory) {
    DynamicArrayLib.DynamicArray memory offers;
    OfferListUnpacked memory _offerList;
    _offerList.from(market.offerList(index));
    uint40 next = _offerList.head;
    OfferUnpacked memory _offer;
    while (next != 0) {
      offers.p(next);
      _offer.from(market.offer(next));
      next = _offer.next;
    }
    return offers.data;
  }
}

contract LibOfferListTest is Test {
  using LibOfferList for *;
  using LibOffer for *;
  using LibTick for *;

  LibOfferListSubject internal subject;

  function setUp() public {
    subject = new LibOfferListSubject();
  }

  function testFuzz_setNoClash(
    bytes32 market1,
    bytes32 market2,
    uint24 index1,
    uint24 index2,
    uint256 value1,
    uint256 value2
  ) public {
    vm.assume(market1 != market2 || index1 != index2);
    subject.setOfferList(market1, index1, value1);
    subject.setOfferList(market2, index2, value2);
    assertEq(subject.offerList(market1, index1), value1);
    assertEq(subject.offerList(market2, index2), value2);
  }

  function testFuzz_pack_unpack(uint40 head, uint40 tail, uint40 offerCount, uint64 totalGives, uint24 index)
    public
    pure
  {
    OfferListUnpacked memory offerList =
      OfferListUnpacked({head: head, tail: tail, offerCount: offerCount, totalGives: totalGives, index: index});

    uint256 packed = offerList.pack();
    OfferListUnpacked memory unpacked;

    unpacked.from(packed);
    assertEq(unpacked.head, head, "head");
    assertEq(unpacked.tail, tail, "tail");
    assertEq(unpacked.offerCount, offerCount, "offerCount");
    assertEq(unpacked.totalGives, totalGives, "totalGives");
  }

  function testFuzz_insertMultipleOffers(bytes32 market, uint24 index, uint40 offerCount) public {
    offerCount = uint40(bound(offerCount, 1, 100));
    for (uint256 i = 1; i <= offerCount; i++) {
      uint40 prev = subject.insert(market, index, uint40(i), 1e6);
      assertEq(prev, i - 1);
    }
    OfferListUnpacked memory offerList;
    offerList.from(subject.offerList(market, index));

    assertEq(offerList.head, 1);
    assertEq(offerList.tail, offerCount);
    assertEq(offerList.offerCount, offerCount);
    assertEq(offerList.totalGives, offerCount * 1e6);

    OfferUnpacked memory offer;
    uint256 nextId = 1;
    uint256 offerCounted;

    while (nextId != 0) {
      offerCounted++;
      offer.from(subject.offer(market, uint40(nextId)));
      assertEq(offer.isActive, true);
      assertEq(offer.tick, index.tick(1));
      assertEq(offer.gives, 1e6);
      if (offer.next > 0) assertEq(offer.next, nextId + 1);
      nextId = offer.next;
    }

    assertEq(offerCounted, offerList.offerCount);

    uint256[] memory allActive = subject.allActive(market);
    assertEq(allActive.length, 1);
    assertEq(allActive[0], index);
  }

  function test_cannotUnlinkOfferThatIsNotActive() public {
    bytes32 market = keccak256("MARKET");
    uint40 offerId = 1;
    vm.expectRevert(LibOfferList.CannotUnlink.selector);
    subject.unlink(market, offerId);
  }

  function testFuzz_insertManyAtDifferentIndexes(uint24 nIndexes, uint24 indexStart, uint24 indexEnd, uint40 nOffers)
    public
  {
    bytes32 market = keccak256("MARKET");
    vm.assume(indexStart < indexEnd);
    uint256 multiplier = indexEnd - indexStart;
    nIndexes = uint24(bound(nIndexes, 1, 50 < multiplier ? 50 : multiplier));
    nOffers = uint40(bound(nOffers, 1, 10));

    uint24[] memory indexes = new uint24[](nIndexes);
    for (uint256 i = 0; i < nIndexes; i++) {
      indexes[i] = uint24(indexStart + i * multiplier / nIndexes);
      for (uint256 j = 0; j < nOffers; j++) {
        uint40 next = subject.nextOfferId(market);
        subject.insert(market, indexes[i], next, 1e6);
      }
    }

    uint256[] memory allActive = subject.allActive(market);
    assertEq(allActive.length, nIndexes);

    OfferListUnpacked memory offerList;
    OfferUnpacked memory offer;

    for (uint256 i = 0; i < nIndexes; i++) {
      assertEq(allActive[i], indexes[i]);
      offerList.from(subject.offerList(market, indexes[i]));
      assertEq(offerList.offerCount, nOffers);
      assertEq(offerList.totalGives, nOffers * 1e6);

      uint256[] memory offers = subject.allOffers(market, indexes[i]);
      assertEq(offers.length, nOffers);

      for (uint256 j = 0; j < nOffers; j++) {
        uint40 offerId = uint40(offers[j]);
        offer.from(subject.offer(market, offerId));
        assertEq(offer.isActive, true);
        assertEq(offer.tick, indexes[i].tick(1));
        assertEq(offer.gives, 1e6);
      }
    }
  }

  function test_unlinkOffer() public {
    bytes32 market = keccak256("MARKET");
    uint40 offerId1 = 1;
    uint40 offerId2 = 2;
    uint40 offerId3 = 3;

    uint24 index = 1000;

    subject.insert(market, index, offerId1, 1e6);
    subject.insert(market, index, offerId2, 1e6);
    subject.insert(market, index, offerId3, 1e6);

    uint256[] memory indexes = subject.allActive(market);
    assertEq(indexes.length, 1);
    assertEq(indexes[0], index);

    uint256[] memory offers = subject.allOffers(market, index);
    assertEq(offers.length, 3);
    assertEq(offers[0], offerId1);
    assertEq(offers[1], offerId2);
    assertEq(offers[2], offerId3);

    OfferListUnpacked memory offerList;
    // check offer list fields
    offerList.from(subject.offerList(market, index));
    assertEq(offerList.offerCount, 3);
    assertEq(offerList.totalGives, 3e6);
    assertEq(offerList.head, offerId1);
    assertEq(offerList.tail, offerId3);

    OfferUnpacked memory offer;
    // check offer 1 fields
    offer.from(subject.offer(market, offerId1));
    assertEq(offer.isActive, true);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, 0);
    assertEq(offer.next, offerId2);

    // check offer 2 fields
    offer.from(subject.offer(market, offerId2));
    assertEq(offer.isActive, true);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, offerId1);
    assertEq(offer.next, offerId3);

    // check offer 3 fields
    offer.from(subject.offer(market, offerId3));
    assertEq(offer.isActive, true);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, offerId2);
    assertEq(offer.next, 0);

    // unlink offer 2
    subject.unlink(market, offerId2);

    indexes = subject.allActive(market);
    assertEq(indexes.length, 1);
    assertEq(indexes[0], index);

    offers = subject.allOffers(market, index);
    assertEq(offers.length, 2);
    assertEq(offers[0], offerId1);
    assertEq(offers[1], offerId3);

    // check offer list fields
    offerList.from(subject.offerList(market, index));
    assertEq(offerList.offerCount, 2);
    assertEq(offerList.totalGives, 2e6);
    assertEq(offerList.head, offerId1);
    assertEq(offerList.tail, offerId3);

    // check offer 1 fields
    offer.from(subject.offer(market, offerId1));
    assertEq(offer.isActive, true);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, 0);
    assertEq(offer.next, offerId3);

    // check offer 2 fields
    offer.from(subject.offer(market, offerId2));
    assertEq(offer.isActive, false);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);

    // check offer 3 fields
    offer.from(subject.offer(market, offerId3));
    assertEq(offer.isActive, true);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, offerId1);
    assertEq(offer.next, 0);

    subject.unlink(market, offerId1);
    subject.unlink(market, offerId3);

    indexes = subject.allActive(market);
    assertEq(indexes.length, 0);

    offers = subject.allOffers(market, index);
    assertEq(offers.length, 0);

    offerList.from(subject.offerList(market, index));
    assertEq(offerList.offerCount, 0);
    assertEq(offerList.totalGives, 0);
    assertEq(offerList.head, 0);
    assertEq(offerList.tail, 0);

    offer.from(subject.offer(market, offerId1));
    assertEq(offer.isActive, false);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);

    offer.from(subject.offer(market, offerId2));
    assertEq(offer.isActive, false);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);

    offer.from(subject.offer(market, offerId3));
    assertEq(offer.isActive, false);
    assertEq(offer.tick, index.tick(1));
    assertEq(offer.gives, 1e6);
    assertEq(offer.prev, 0);
    assertEq(offer.next, 0);
  }
}
