// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibOffer, OfferUnpacked} from "../../src/libraries/LibOffer.sol";

contract OfferSubject {
  using LibOffer for *;

  function offer(bytes32 marketId, uint40 offerId) external view returns (uint256) {
    return LibOffer.offer(marketId, offerId);
  }

  function offerOwner(bytes32 marketId, uint40 offerId) external view returns (address) {
    return LibOffer.offerOwner(marketId, offerId);
  }

  function setOffer(bytes32 marketId, uint40 offerId, uint256 _offer) external {
    LibOffer.setOffer(marketId, offerId, _offer);
  }

  function setOfferOwner(bytes32 marketId, uint40 offerId, address owner) external {
    LibOffer.setOfferOwner(marketId, offerId, owner);
  }

  function nextOfferId(bytes32 marketId) external returns (uint40) {
    return LibOffer.nextOfferId(marketId);
  }

  function setNext(bytes32 marketId, uint40 offerId, uint40 nextId) external {
    LibOffer.setNext(marketId, offerId, nextId);
  }

  function setPrev(bytes32 marketId, uint40 offerId, uint40 prevId) external {
    LibOffer.setPrev(marketId, offerId, prevId);
  }
}

contract LibOfferTest is Test {
  using LibOffer for *;

  OfferSubject internal subject;

  function setUp() public {
    subject = new OfferSubject();
  }

  function testFuzz_pack_unpack(
    uint40 prev,
    uint40 next,
    uint32 expiry,
    uint48 gives,
    uint48 received,
    int24 tick,
    uint24 provision,
    bool isActive
  ) public pure {
    provision = uint24(bound(provision, 0, 0x7fffff));

    OfferUnpacked memory offer = OfferUnpacked({
      prev: prev,
      next: next,
      expiry: expiry,
      gives: gives,
      received: received,
      tick: tick,
      provision: provision,
      isActive: isActive
    });

    uint256 packed = offer.pack();

    OfferUnpacked memory unpacked;
    unpacked.from(packed);

    assertEq(unpacked.prev, prev, "prev");
    assertEq(unpacked.next, next, "next");
    assertEq(unpacked.expiry, expiry, "expiry");
    assertEq(unpacked.gives, gives, "gives");
    assertEq(unpacked.received, received, "received");
    assertEq(unpacked.tick, tick, "tick");
    assertEq(unpacked.provision, provision, "provision");
    assertEq(unpacked.isActive, isActive, "isActive");
  }

  function testFuzz_setOffer(bytes32 marketId, uint40 offerId, uint256 offer) public {
    subject.setOffer(marketId, offerId, offer);
    assertEq(subject.offer(marketId, offerId), offer);
  }

  function testFuzz_setOfferOwner(bytes32 marketId, uint40 offerId, address owner) public {
    subject.setOfferOwner(marketId, offerId, owner);
    assertEq(subject.offerOwner(marketId, offerId), owner);
  }

  function testFuzz_nextOfferIdNoCollision(bytes32 market1, bytes32 market2, uint40 offerCount1, uint40 offerCount2)
    public
  {
    vm.assume(market1 != market2);

    offerCount1 = uint40(bound(offerCount1, 0, 100));
    offerCount2 = uint40(bound(offerCount2, 0, 100));

    for (uint40 i = 1; i <= offerCount1; i++) {
      uint40 next = subject.nextOfferId(market1);
      assertEq(next, i, "market 1 offer id");
    }
    for (uint40 i = 1; i <= offerCount2; i++) {
      uint40 next = subject.nextOfferId(market2);
      assertEq(next, i, "market 2 offer id");
    }
  }

  function testFuzz_nextOfferId(uint40 currOfferId) public {
    // bound to max-1 to avoid failures of overflow
    currOfferId = uint40(bound(currOfferId, 0, type(uint40).max - 1));
    bytes32 market = keccak256("MARKET");

    vm.record();
    subject.nextOfferId(market);

    // get the written slot
    (, bytes32[] memory writeSlots) = vm.accesses(address(subject));
    assertEq(writeSlots.length, 1, "should write 1 slot only");
    bytes32 slot = writeSlots[0];

    // set the slot to the current offer id
    vm.store(address(subject), slot, bytes32(uint256(currOfferId)));

    // expect the next offer id to be the current offer id + 1
    assertEq(subject.nextOfferId(market), currOfferId + 1, "next offer id should be the current offer id + 1");
  }

  function test_offerIdOverflow() public {
    bytes32 market = keccak256("MARKET");

    vm.record();
    subject.nextOfferId(market);

    // get the written slot
    (, bytes32[] memory writeSlots) = vm.accesses(address(subject));
    assertEq(writeSlots.length, 1, "should write 1 slot only");
    bytes32 slot = writeSlots[0];

    // set the lsot the the max value
    vm.store(address(subject), slot, bytes32(uint256(type(uint40).max)));

    // expect the error
    vm.expectRevert(LibOffer.OfferIdOverflow.selector);
    subject.nextOfferId(market);
  }

  function testFuzz_setNext(bytes32 market, uint40 offerId, uint40 nextId) public {
    subject.setNext(market, offerId, nextId);
    OfferUnpacked memory offer;
    offer.from(subject.offer(market, offerId));
    assertEq(offer.next, nextId, "next should be the next id");
  }

  function testFuzz_setPrev(bytes32 market, uint40 offerId, uint40 prevId) public {
    subject.setPrev(market, offerId, prevId);
    OfferUnpacked memory offer;
    offer.from(subject.offer(market, offerId));
    assertEq(offer.prev, prevId, "prev should be the prev id");
  }
}
