// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {FixedPointMathLib} from "lib/solady/src/utils/FixedPointMathLib.sol";

import {Test} from "forge-std/Test.sol";
import {LibFees} from "../../src/libraries/LibFees.sol";

contract LibFeesSubject {
  using LibFees for *;

  function addFees(address token, uint256 fees) external {
    token.addFees(fees);
  }

  function claimFees(address token, uint256 amount) external {
    token.claimFees(amount);
  }
}

contract LibFeesTest is Test {
  using LibFees for *;

  LibFeesSubject internal subject;

  uint256 private constant _FEES_SEED = 0x9af1d35a;
  uint256 private constant DAI_UNITS = 1e14;

  function setUp() public {
    subject = new LibFeesSubject();
  }

  function _slot(address token) internal pure returns (bytes32 slot) {
    /// @solidity memory-safe-assembly
    assembly {
      mstore(0x20, _FEES_SEED)
      mstore(0x0c, token)
      slot := keccak256(0x20, 0x20)
    }
  }

  function _fees(address token) internal view returns (uint256) {
    return uint256(vm.load(address(subject), _slot(token)));
  }

  // function _setFees(address token, uint256 fees) internal {
  //   vm.store(address(subject), _slot(token), bytes32(fees));
  // }

  function testFuzz_addFees(address token, uint256 fees) public {
    subject.addFees(token, fees);
    assertEq(_fees(token), fees);
  }

  function testFuzz_addFees_overflow(uint256 fees) public {
    vm.assume(fees > 0);

    address token = address(1);
    subject.addFees(token, type(uint256).max);

    vm.expectRevert(LibFees.FeesOverflow.selector);
    subject.addFees(token, fees);
  }

  function testFuzz_claimFees(uint256 feesAmount, uint256 withdrawAmount) public {
    withdrawAmount = bound(withdrawAmount, 0, feesAmount);
    address token = address(1);

    subject.addFees(token, feesAmount);
    assertEq(_fees(token), feesAmount);

    subject.claimFees(token, withdrawAmount);
    assertEq(_fees(token), feesAmount - withdrawAmount);
  }

  function testFuzz_claimMoreFeesThanAvailable(uint256 feesAmount, uint256 withdrawAmount) public {
    feesAmount = bound(feesAmount, 0, type(uint256).max - 1);
    withdrawAmount = bound(withdrawAmount, feesAmount + 1, type(uint256).max);
    address token = address(1);

    subject.addFees(token, feesAmount);
    assertEq(_fees(token), feesAmount);

    vm.expectRevert(LibFees.InsufficientFeesToWithdraw.selector);
    subject.claimFees(token, withdrawAmount);

    assertEq(_fees(token), feesAmount);
  }

  function testFuzz_excludeFeesExactIn(uint16 fees, uint64 fillVolume) public pure {
    uint64 netFees = fees.excludeFees(fillVolume, false);
    assertEq(netFees, FixedPointMathLib.mulDivUp(fillVolume, 1e6 - fees, 1e6));
    if (fillVolume > 0) {
      assertGt(netFees, 0);
    }
  }

  function testFuzz_excludeFeesExactOut(uint16 fees, uint64 fillVolume) public pure {
    uint64 netFees = fees.excludeFees(fillVolume, true);
    // should not affect the fill volume
    assertEq(netFees, fillVolume);
  }

  function testFuzz_computeFeesNoCeil(uint16 fees, uint256 gave) public pure {
    // amount should not be more than 128 bits
    gave = bound(gave, 0, type(uint128).max);

    uint256 feesAmount = fees.fees(gave, 0, true);

    assertEq(feesAmount, gave * fees / (1e6 - fees));
  }

  function testFuzz_computeFeesWithCeil(uint256 gave) public pure {
    gave = bound(gave, 0, type(uint128).max);
    uint256 fillVolume = gave + 1;

    uint256 feesAmount = type(uint16).max.fees(gave, fillVolume, false);

    assertLe(feesAmount, 1);
  }

  function testFuzz_compareIn(uint16 fees, uint256 gave, uint256 fillVolume) public pure {
    // assume DAI tokens
    fillVolume = bound(fillVolume, 0, type(uint64).max * DAI_UNITS);

    uint64 inUnits = uint64(fillVolume / DAI_UNITS);
    uint64 netFees = fees.excludeFees(inUnits, false);

    assertEq(netFees, FixedPointMathLib.mulDivUp(inUnits, 1e6 - fees, 1e6), "netFees");
    gave = bound(gave, 0, netFees) * DAI_UNITS;

    uint256 feesAmount = fees.fees(gave, fillVolume, false);
    assertLe(gave + feesAmount, fillVolume);
  }
}
