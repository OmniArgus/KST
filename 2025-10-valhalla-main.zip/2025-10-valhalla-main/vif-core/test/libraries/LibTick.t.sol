// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibTick} from "../../src/libraries/LibTick.sol";

contract LibTickSubject {
  function tickToPrice(int24 tick) external pure returns (uint256) {
    return LibTick.tickToPrice(tick);
  }

  function inboundFromOutbound(uint256 price, uint48 outbound, uint64 outboundUnit, uint64 inboundUnit)
    external
    pure
    returns (uint48)
  {
    return LibTick.inboundFromOutbound(price, outbound, outboundUnit, inboundUnit);
  }
}

contract LibTickTest is Test {
  using LibTick for *;

  LibTickSubject internal subject;

  function setUp() public {
    subject = new LibTickSubject();
  }

  function testFuzz_increasingPrice(int24 tick1, int24 tick2) public pure {
    vm.assume(tick1 != tick2);

    tick1 = int24(bound(tick1, -8_388_607, type(int24).max));
    tick2 = int24(bound(tick2, -8_388_607, type(int24).max));

    uint256 price1 = LibTick.tickToPrice(tick1);
    uint256 price2 = LibTick.tickToPrice(tick2);

    if (tick1 < tick2) {
      assertLe(price1, price2);
    } else {
      assertGe(price1, price2);
    }
  }

  function test_incorrectTick() public {
    vm.expectRevert(LibTick.TickOverflow.selector);
    subject.tickToPrice(type(int24).min);
  }

  function test_index() public pure {
    assertEq(LibTick.index(type(int24).min + 1, 1), 0);
    assertEq(LibTick.index(type(int24).max, 1), type(uint24).max - 1);
  }

  function test_tick() public pure {
    assertEq(LibTick.tick(0, 1), type(int24).min + 1);
    assertEq(LibTick.tick(type(uint24).max - 1, 1), type(int24).max);
  }

  function test_overflow() public {
    uint256 price = 2 << 128; // price of 2
    uint64 unit = 1;
    uint48 outbound = type(uint48).max;

    vm.expectRevert(LibTick.AmountOverflow.selector);
    subject.inboundFromOutbound(price, outbound, unit, unit);
  }

  struct IndexAndBackInput {
    int24 tick;
    uint16 tickSpacing;
  }

  function fixtureIndexAndBackInput() public pure returns (IndexAndBackInput[] memory inputs) {
    inputs = new IndexAndBackInput[](1);

    inputs[0] = IndexAndBackInput({tick: 4, tickSpacing: 5});
  }

  function testFuzz_tickSpacingIndex(IndexAndBackInput memory indexAndBackInput) public pure {
    int24 tick = indexAndBackInput.tick;
    uint16 tickSpacing = indexAndBackInput.tickSpacing;
    vm.assume(tickSpacing > 0);
    tick = int24(bound(tick, -8_388_607, type(int24).max));
    uint24 expectedIndex =
      uint24(uint256((int256(tick) / int256(uint256(tickSpacing))) + (type(int24).max / int256(uint256(tickSpacing)))));
    assertEq(LibTick.index(tick, tickSpacing), expectedIndex);
  }

  function testFuzz_indexAndBack(IndexAndBackInput memory indexAndBackInput) public pure {
    int24 tick = indexAndBackInput.tick;
    uint16 tickSpacing = indexAndBackInput.tickSpacing;
    vm.assume(tickSpacing > 0);
    tick = int24(
      bound(
        tick, int256(-8_388_607) / int256(uint256(tickSpacing)), int256(type(int24).max) / int256(uint256(tickSpacing))
      )
    );
    tick = tick.closestTick(tickSpacing);
    uint24 index = tick.index(tickSpacing);
    int24 resultingTick = LibTick.tick(index, tickSpacing);
    assertEq(resultingTick, tick);
  }
}
