// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibPausable} from "../../src/libraries/LibPausable.sol";

contract LibPausableSubject {
  using LibPausable for *;

  function setPaused(bool paused) external {
    LibPausable.setPaused(paused);
  }

  function checkNotPaused() external view {
    LibPausable.checkNotPaused();
  }
}

contract LibPausableTest is Test {
  using LibPausable for *;

  LibPausableSubject internal subject;

  function setUp() public {
    subject = new LibPausableSubject();
  }

  function test_isNotPaused() public view {
    subject.checkNotPaused();
  }

  function test_isPaused() public {
    vm.expectEmit(true, true, true, true);
    emit LibPausable.SetPaused(true);
    subject.setPaused(true);

    vm.expectRevert(LibPausable.Paused.selector);
    subject.checkNotPaused();
  }

  function test_setPaused_and_isPaused() public {
    vm.expectEmit(true, true, true, true);
    emit LibPausable.SetPaused(true);
    subject.setPaused(true);

    vm.expectRevert(LibPausable.Paused.selector);
    subject.checkNotPaused();

    vm.expectEmit(true, true, true, true);
    emit LibPausable.SetPaused(false);
    subject.setPaused(false);

    subject.checkNotPaused();
  }
}
