// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {LibBlackList} from "../../src/libraries/LibBlackList.sol";

contract LibBlackListSubject {
  using LibBlackList for *;

  function setBlacklisted(address user, bool value) external {
    LibBlackList.setBlacklisted(user, value);
  }

  function checkNotBlacklisted(address user) external view {
    LibBlackList.checkNotBlacklisted(user);
  }
}

contract LibBlackListTest is Test {
  using LibBlackList for *;

  LibBlackListSubject internal subject;

  function setUp() public {
    subject = new LibBlackListSubject();
  }

  function testFuzz_setBlacklisted(address user, bool value) public {
    vm.expectEmit(true, true, true, true);
    emit LibBlackList.SetBlacklisted(user, value);
    subject.setBlacklisted(user, value);

    if (value) vm.expectRevert(LibBlackList.Blacklisted.selector);
    subject.checkNotBlacklisted(user);
  }
}
